# Central Florida Bin Cleaning - Complete Deployment Package

This package contains the complete source code and automated deployment script for Ubuntu 24.04 LTS.

## 🚀 Quick Deployment

### Step 1: Upload to Your Server
```bash
# Upload this entire package to your Ubuntu server
scp -r cfbc-complete-deployment root@your-server-ip:/root/
```

### Step 2: Run the Deployment
```bash
# On your server
cd /root/cfbc-complete-deployment
chmod +x deploy-complete.sh
./deploy-complete.sh
```

### Step 3: Follow the Prompts
- Enter your domain name (or press Enter for IP)
- Wait 5-10 minutes for complete installation

## 📦 What's Included

### Complete Source Code
- ✅ Full React frontend with TypeScript
- ✅ Express.js backend API
- ✅ PostgreSQL database schema
- ✅ Authentication system
- ✅ All UI components and styling
- ✅ Business logic and workflows

### Automated Setup
- ✅ Ubuntu 24.04 system updates
- ✅ Node.js 20 installation
- ✅ PostgreSQL database setup
- ✅ Nginx web server configuration
- ✅ PM2 process manager
- ✅ Firewall configuration
- ✅ SSL certificate support
- ✅ Automatic backups
- ✅ Management scripts

## 🔧 What the Script Does

1. **System Setup**
   - Updates Ubuntu packages
   - Installs Node.js, PostgreSQL, Nginx
   - Configures firewall and security

2. **Database Configuration**
   - Creates production database
   - Sets up secure user credentials
   - Initializes application schema

3. **Application Installation**
   - Copies all source code
   - Installs dependencies
   - Builds production version
   - Configures environment variables

4. **Web Server Setup**
   - Configures Nginx reverse proxy
   - Sets up security headers
   - Enables gzip compression
   - Configures SSL support

5. **Process Management**
   - Sets up PM2 for application management
   - Configures auto-restart on crashes
   - Sets up boot-time startup
   - Creates management commands

## 🌐 After Deployment

### Access Your Application
- **URL**: `http://your-server-ip` or `http://your-domain.com`
- **Admin Panel**: Login with admin/admin123

### Default Accounts
- **Admin**: admin / admin123
- **Customer**: customer1 / customer123
- **Driver**: driver1 / driver123
- **Dispatcher**: dispatcher1 / dispatcher123

### Management Commands
```bash
cd /var/www/cfbc

./manage.sh start      # Start application
./manage.sh stop       # Stop application
./manage.sh restart    # Restart application
./manage.sh status     # Check status
./manage.sh logs       # View logs
./manage.sh build      # Rebuild application
./manage.sh db-setup   # Reset database
```

## ⚙️ Configuration

### Update API Keys
Edit `/var/www/cfbc/.env.production`:

```bash
# Email service (SendGrid)
SENDGRID_API_KEY=your-actual-key

# SMS service (Twilio)
TWILIO_ACCOUNT_SID=your-sid
TWILIO_AUTH_TOKEN=your-token
TWILIO_PHONE_NUMBER=your-phone

# Payment service (Stripe)
STRIPE_SECRET_KEY=your-secret-key
VITE_STRIPE_PUBLIC_KEY=your-public-key

# Authentication (Replit)
REPL_ID=your-repl-id
```

After updating, restart:
```bash
/var/www/cfbc/manage.sh restart
```

## 🔒 Security Features

- ✅ Dedicated application user (cfbc)
- ✅ PostgreSQL with secure credentials
- ✅ Nginx security headers
- ✅ UFW firewall configuration
- ✅ SSL certificate support
- ✅ Secure session management
- ✅ Environment variable protection

## 📊 Monitoring

### Check Application Status
```bash
/var/www/cfbc/manage.sh status
```

### View Real-time Logs
```bash
/var/www/cfbc/manage.sh logs
```

### Test Application Health
```bash
curl http://localhost:3000/health
```

## 🗄️ Backup System

### Automatic Backups
- Daily database backups to `/backups/`
- 7-day retention policy
- Compressed SQL dumps

### Manual Backup
```bash
sudo -u postgres pg_dump cfbc_production > backup.sql
```

## 🆘 Troubleshooting

### Application Not Starting
```bash
# Check logs
/var/www/cfbc/manage.sh logs

# Check system services
systemctl status nginx
systemctl status postgresql

# Rebuild if needed
/var/www/cfbc/manage.sh build
```

### Database Issues
```bash
# Reset database schema
/var/www/cfbc/manage.sh db-setup

# Check database connection
sudo -u postgres psql cfbc_production -c "\dt"
```

### Network Issues
```bash
# Check firewall
sudo ufw status

# Test internal connection
curl http://localhost:3000

# Test external connection
curl http://your-server-ip
```

## 🔄 Updates

### Update Application Code
```bash
# If you have Git repository
cd /var/www/cfbc
git pull
./manage.sh build
./manage.sh restart
```

### System Updates
```bash
sudo apt update && sudo apt upgrade
/var/www/cfbc/manage.sh restart
```

## 📋 System Requirements

- Ubuntu 24.04 LTS (recommended)
- 2GB RAM minimum (4GB recommended)
- 20GB disk space minimum
- Root or sudo access
- Internet connection for package installation

## 🎯 Features Included

### Frontend Features
- Modern React interface
- Multi-role dashboards
- Service request system
- Schedule management
- Payment integration ready
- Mobile responsive design

### Backend Features
- RESTful API architecture
- User authentication
- Database integration
- Session management
- Security middleware
- Error handling

### Business Features
- Customer management
- Service scheduling
- Driver assignments
- Invoice generation
- Contact management
- Admin reporting

This complete deployment package provides everything you need to run the Central Florida Bin Cleaning application in production on Ubuntu 24.04!