import { Navigation } from "@/components/navigation";
import { Footer } from "@/components/footer";
import { Card, CardContent } from "@/components/ui/card";
import { Leaf, Shield, Users, Award } from "lucide-react";
import truckImage from "@assets/CF-Truck2_1753726085461.jpg";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      {/* Hero Section */}
      <section className="bg-gradient-eco py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              About Central Florida Bin Cleaning
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're dedicated to providing professional, eco-friendly trash bin cleaning services 
              that keep your property clean and your bins sanitized.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">Our Story</h2>
              <p className="text-lg text-gray-600 mb-6">
                Central Florida Bin Cleaning was founded with a simple mission: to provide professional, 
                reliable, and eco-friendly trash bin cleaning services to homes and businesses throughout 
                Central Florida.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                We recognized that dirty, smelly trash bins were more than just an inconvenience – they 
                were a health hazard and an eyesore. Our team developed a comprehensive cleaning process 
                that not only removes dirt and odors but also sanitizes and deodorizes your bins.
              </p>
              <p className="text-lg text-gray-600">
                Today, we're proud to serve hundreds of satisfied customers across Orlando and the 
                surrounding areas, helping them maintain clean, healthy, and odor-free properties.
              </p>
            </div>
            <div className="relative">
              <img 
                src={truckImage} 
                alt="Central Florida Bin Cleaning Service Truck" 
                className="rounded-2xl shadow-xl w-full h-[400px] object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The principles that guide everything we do
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Leaf className="h-8 w-8 text-eco-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Eco-Friendly</h3>
                <p className="text-gray-600">
                  We use only environmentally safe cleaning products and methods that protect our planet.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Shield className="h-8 w-8 text-eco-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Reliable</h3>
                <p className="text-gray-600">
                  Count on us for consistent, dependable service that keeps your schedule on track.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Users className="h-8 w-8 text-eco-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Customer-Focused</h3>
                <p className="text-gray-600">
                  Your satisfaction is our priority. We go above and beyond to exceed expectations.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Award className="h-8 w-8 text-eco-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Professional</h3>
                <p className="text-gray-600">
                  Our trained team delivers high-quality service with professionalism and integrity.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-eco-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-8">Our Mission</h2>
            <div className="max-w-4xl mx-auto">
              <p className="text-xl text-gray-700 leading-relaxed mb-8">
                "To provide Central Florida with the highest quality, most reliable, and environmentally 
                responsible bin cleaning services while building lasting relationships with our customers 
                and contributing to healthier, cleaner communities."
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div>
                  <div className="text-3xl font-bold text-eco-green-600 mb-2">500+</div>
                  <div className="text-gray-600">Happy Customers</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-eco-green-600 mb-2">100%</div>
                  <div className="text-gray-600">Eco-Friendly Products</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-eco-green-600 mb-2">5★</div>
                  <div className="text-gray-600">Average Rating</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
