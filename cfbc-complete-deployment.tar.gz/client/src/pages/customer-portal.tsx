import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Logo } from "@/components/logo";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { User, Calendar, CreditCard, CalendarCheck, Eye, Plus, X, Clock, CheckCircle } from "lucide-react";

export default function CustomerPortal() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [showServiceRequestModal, setShowServiceRequestModal] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [serviceRequestForm, setServiceRequestForm] = useState({
    serviceType: "",
    serviceIds: [] as string[],
    address: "",
    notes: "",
    preferredDate: "",
    preferredTime: "",
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  // Fetch invoices
  const { data: invoices, isLoading: invoicesLoading } = useQuery({
    queryKey: ["/api/invoices"],
    enabled: isAuthenticated,
  });

  // Fetch service requests
  const { data: serviceRequests, isLoading: requestsLoading } = useQuery({
    queryKey: ["/api/service-requests"],
    enabled: isAuthenticated,
  });

  // Fetch available services
  const { data: services } = useQuery({
    queryKey: ["/api/services/active"],
    enabled: isAuthenticated,
  });

  // Fetch customer jobs for schedule view
  const { data: customerJobs } = useQuery({
    queryKey: ["/api/jobs"],
    enabled: isAuthenticated,
  });

  // Create service request mutation
  const createServiceRequest = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/service-requests", data);
    },
    onSuccess: () => {
      toast({
        title: "Service Requested",
        description: "Your service request has been submitted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/service-requests"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to submit service request. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Cancel service request mutation
  const cancelServiceRequest = useMutation({
    mutationFn: async (requestId: string) => {
      await apiRequest("DELETE", `/api/service-requests/${requestId}`);
    },
    onSuccess: () => {
      toast({
        title: "Request Cancelled",
        description: "Your service request has been cancelled successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/service-requests"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to cancel service request. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Pay invoice mutation
  const payInvoice = useMutation({
    mutationFn: async (invoiceId: string) => {
      await apiRequest("PATCH", `/api/invoices/${invoiceId}/pay`, {});
    },
    onSuccess: () => {
      toast({
        title: "Payment Processed",
        description: "Your payment has been processed successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/invoices"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to process payment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleRequestService = () => {
    setServiceRequestForm({
      serviceType: "",
      serviceIds: [],
      address: user?.address || "",
      notes: "",
      preferredDate: "",
      preferredTime: "",
    });
    setShowServiceRequestModal(true);
  };

  const handleSubmitServiceRequest = () => {
    if (!serviceRequestForm.serviceType || !serviceRequestForm.address) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    createServiceRequest.mutate({
      serviceType: serviceRequestForm.serviceType,
      serviceIds: serviceRequestForm.serviceIds,
      address: serviceRequestForm.address,
      notes: serviceRequestForm.notes,
      preferredDate: serviceRequestForm.preferredDate || null,
      preferredTime: serviceRequestForm.preferredTime || null,
    });
    setShowServiceRequestModal(false);
  };

  const handleViewSchedule = () => {
    setShowScheduleModal(true);
  };

  const handlePaymentMethods = () => {
    setShowPaymentModal(true);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-eco-green-500"></div>
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== 'customer') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Logo />
              <h1 className="text-xl font-bold text-gray-900">Customer Portal</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-gray-600">Welcome, {user?.firstName}</span>
              <Button onClick={handleLogout} variant="outline" size="sm">
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="h-5 w-5 mr-2" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  onClick={handleRequestService}
                  disabled={createServiceRequest.isPending}
                  className="w-full bg-eco-green-500 text-white hover:bg-eco-green-600"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  {createServiceRequest.isPending ? "Requesting..." : "Request Service"}
                </Button>
                <Button variant="outline" className="w-full" onClick={handleViewSchedule}>
                  <Calendar className="mr-2 h-4 w-4" />
                  View Schedule
                </Button>
                <Button variant="outline" className="w-full" onClick={handlePaymentMethods}>
                  <CreditCard className="mr-2 h-4 w-4" />
                  Payment Methods
                </Button>
              </CardContent>
            </Card>

            {/* Account Info */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Account Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-gray-600">Name</p>
                  <p className="font-medium">{user?.firstName} {user?.lastName}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Email</p>
                  <p className="font-medium">{user?.email}</p>
                </div>
                {user?.phone && (
                  <div>
                    <p className="text-sm text-gray-600">Phone</p>
                    <p className="font-medium">{user.phone}</p>
                  </div>
                )}
                {user?.address && (
                  <div>
                    <p className="text-sm text-gray-600">Address</p>
                    <p className="font-medium">{user.address}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          {/* Recent Invoices */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Recent Invoices</CardTitle>
              </CardHeader>
              <CardContent>
                {invoicesLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-eco-green-500 mx-auto"></div>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-gray-200">
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Invoice #</th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Date</th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Description</th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Amount</th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Status</th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {invoices && invoices.length > 0 ? (
                          invoices.map((invoice: any) => (
                            <tr key={invoice.id} className="border-b border-gray-100">
                              <td className="py-3 text-sm text-gray-900">{invoice.invoiceNumber}</td>
                              <td className="py-3 text-sm text-gray-600">
                                {new Date(invoice.createdAt).toLocaleDateString()}
                              </td>
                              <td className="py-3 text-sm text-gray-600">{invoice.description}</td>
                              <td className="py-3 text-sm text-gray-900 font-medium">
                                ${parseFloat(invoice.amount).toFixed(2)}
                              </td>
                              <td className="py-3">
                                <Badge 
                                  variant={invoice.status === 'paid' ? 'default' : 'secondary'}
                                  className={invoice.status === 'paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}
                                >
                                  {invoice.status}
                                </Badge>
                              </td>
                              <td className="py-3">
                                {invoice.status === 'pending' ? (
                                  <Button 
                                    size="sm"
                                    onClick={() => payInvoice.mutate(invoice.id)}
                                    disabled={payInvoice.isPending}
                                    className="bg-eco-green-500 text-white hover:bg-eco-green-600"
                                  >
                                    {payInvoice.isPending ? "Processing..." : "Pay Now"}
                                  </Button>
                                ) : (
                                  <Button variant="ghost" size="sm">
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                )}
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={6} className="py-8 text-center text-gray-500">
                              No invoices found
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Service Requests */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Service Requests</CardTitle>
              </CardHeader>
              <CardContent>
                {requestsLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-eco-green-500 mx-auto"></div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {serviceRequests && serviceRequests.length > 0 ? (
                      serviceRequests.map((request: any) => (
                        <div key={request.id} className="border border-gray-200 rounded-lg p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h4 className="font-medium text-gray-900">
                                {request.serviceType.charAt(0).toUpperCase() + request.serviceType.slice(1)} Service
                              </h4>
                              <p className="text-sm text-gray-600">{request.address}</p>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge 
                                variant="secondary"
                                className={request.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}
                              >
                                {request.status}
                              </Badge>
                              {request.status === 'pending' && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => cancelServiceRequest.mutate(request.id)}
                                  disabled={cancelServiceRequest.isPending}
                                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">
                            Requested: {new Date(request.createdAt).toLocaleDateString()}
                          </p>
                          {request.notes && (
                            <p className="text-sm text-gray-600">Notes: {request.notes}</p>
                          )}
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        No service requests found
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Service Request Modal */}
      <Dialog open={showServiceRequestModal} onOpenChange={setShowServiceRequestModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Request Service</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="serviceType">Service Type</Label>
                <Select 
                  value={serviceRequestForm.serviceType} 
                  onValueChange={(value) => setServiceRequestForm(prev => ({ ...prev, serviceType: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select service type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="residential">Residential</SelectItem>
                    <SelectItem value="commercial">Commercial</SelectItem>
                    <SelectItem value="one_time">One-time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="preferredDate">Preferred Date</Label>
                <Input
                  id="preferredDate"
                  type="date"
                  value={serviceRequestForm.preferredDate}
                  onChange={(e) => setServiceRequestForm(prev => ({ ...prev, preferredDate: e.target.value }))}
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="address">Service Address</Label>
              <Input
                id="address"
                value={serviceRequestForm.address}
                onChange={(e) => setServiceRequestForm(prev => ({ ...prev, address: e.target.value }))}
                placeholder="Enter service address"
              />
            </div>

            {services && services.length > 0 && (
              <div>
                <Label>Select Services</Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  {services.map((service: any) => (
                    <div key={service.id} className="flex items-center space-x-2 p-3 border rounded-lg">
                      <Checkbox
                        id={service.id}
                        checked={serviceRequestForm.serviceIds.includes(service.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setServiceRequestForm(prev => ({
                              ...prev,
                              serviceIds: [...prev.serviceIds, service.id]
                            }));
                          } else {
                            setServiceRequestForm(prev => ({
                              ...prev,
                              serviceIds: prev.serviceIds.filter(id => id !== service.id)
                            }));
                          }
                        }}
                      />
                      <div className="flex-1">
                        <Label htmlFor={service.id} className="text-sm font-medium">
                          {service.name}
                        </Label>
                        <p className="text-xs text-gray-600">${service.price}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div>
              <Label htmlFor="preferredTime">Preferred Time</Label>
              <Select 
                value={serviceRequestForm.preferredTime} 
                onValueChange={(value) => setServiceRequestForm(prev => ({ ...prev, preferredTime: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select preferred time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="morning">Morning (8:00 AM - 12:00 PM)</SelectItem>
                  <SelectItem value="afternoon">Afternoon (12:00 PM - 5:00 PM)</SelectItem>
                  <SelectItem value="evening">Evening (5:00 PM - 8:00 PM)</SelectItem>
                  <SelectItem value="flexible">Flexible</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="notes">Additional Notes</Label>
              <Textarea
                id="notes"
                value={serviceRequestForm.notes}
                onChange={(e) => setServiceRequestForm(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="Any specific instructions or requirements"
                rows={3}
              />
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowServiceRequestModal(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleSubmitServiceRequest}
                disabled={createServiceRequest.isPending}
                className="bg-eco-green-500 text-white hover:bg-eco-green-600"
              >
                {createServiceRequest.isPending ? "Submitting..." : "Submit Request"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Schedule Modal */}
      <Dialog open={showScheduleModal} onOpenChange={setShowScheduleModal}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Your Service Schedule</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {customerJobs && customerJobs.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 text-sm font-medium text-gray-700">Service Date</th>
                      <th className="text-left py-3 text-sm font-medium text-gray-700">Service Type</th>
                      <th className="text-left py-3 text-sm font-medium text-gray-700">Address</th>
                      <th className="text-left py-3 text-sm font-medium text-gray-700">Status</th>
                      <th className="text-left py-3 text-sm font-medium text-gray-700">Driver</th>
                    </tr>
                  </thead>
                  <tbody>
                    {customerJobs.map((job: any) => (
                      <tr key={job.id} className="border-b border-gray-100">
                        <td className="py-3 text-sm text-gray-900">
                          {job.scheduledDate ? new Date(job.scheduledDate).toLocaleDateString() : 'TBD'}
                        </td>
                        <td className="py-3 text-sm text-gray-600 capitalize">{job.serviceType}</td>
                        <td className="py-3 text-sm text-gray-600">{job.address}</td>
                        <td className="py-3">
                          <Badge 
                            variant="secondary"
                            className={
                              job.status === 'completed' ? 'bg-green-100 text-green-800' :
                              job.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                              job.status === 'assigned' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-gray-100 text-gray-800'
                            }
                          >
                            <Clock className="w-3 h-3 mr-1" />
                            {job.status.replace('_', ' ')}
                          </Badge>
                        </td>
                        <td className="py-3 text-sm text-gray-600">
                          {job.driver ? `${job.driver.firstName} ${job.driver.lastName}` : 'Not assigned'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">No scheduled services</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Request a service to see your schedule here.
                </p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Methods Modal */}
      <Dialog open={showPaymentModal} onOpenChange={setShowPaymentModal}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Payment Methods</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-center py-8">
              <CreditCard className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">Payment Integration</h3>
              <p className="mt-1 text-sm text-gray-500">
                Secure payment processing with Stripe will be available here once configured.
              </p>
              <div className="mt-4 space-y-2">
                <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Credit & Debit Cards</span>
                </div>
                <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Bank Transfers</span>
                </div>
                <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Digital Wallets</span>
                </div>
              </div>
            </div>
            <div className="text-center">
              <Button 
                onClick={() => setShowPaymentModal(false)}
                className="bg-eco-green-500 text-white hover:bg-eco-green-600"
              >
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
