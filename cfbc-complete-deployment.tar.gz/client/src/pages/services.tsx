import { Navigation } from "@/components/navigation";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Home, Building, CalendarDays, Check, Clock, DollarSign, Star } from "lucide-react";

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      {/* Hero Section */}
      <section className="bg-gradient-eco py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Our Cleaning Services
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional, eco-friendly bin cleaning solutions for residential and commercial properties
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Residential Service */}
            <Card className="hover:shadow-xl transition-shadow relative">
              <Badge className="absolute top-4 right-4 bg-eco-green-500">Most Popular</Badge>
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mb-6">
                  <Home className="h-8 w-8 text-eco-green-600" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">Residential Cleaning</h3>
                <p className="text-gray-600 mb-6">
                  Regular cleaning and sanitization of your home trash bins. Keep your property clean and odor-free with our reliable residential service.
                </p>
                
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">What's Included:</h4>
                  <ul className="space-y-2">
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      High-pressure washing and sanitizing
                    </li>
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Eco-friendly cleaning products
                    </li>
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Complete deodorization
                    </li>
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Inside and outside cleaning
                    </li>
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Weekly, bi-weekly, or monthly service
                    </li>
                  </ul>
                </div>

                <div className="mb-6 p-4 bg-eco-green-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-gray-900">Starting at</span>
                    <span className="text-2xl font-bold text-eco-green-600">$25</span>
                  </div>
                  <div className="text-sm text-gray-600">per bin, per service</div>
                </div>

                <Link href="/contact">
                  <Button className="w-full bg-eco-green-500 text-white hover:bg-eco-green-600">
                    Get Quote
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Commercial Service */}
            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mb-6">
                  <Building className="h-8 w-8 text-eco-green-600" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">Commercial Cleaning</h3>
                <p className="text-gray-600 mb-6">
                  Professional cleaning services for businesses, restaurants, and commercial properties. Maintain a clean image for your business.
                </p>
                
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">What's Included:</h4>
                  <ul className="space-y-2">
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Flexible scheduling options
                    </li>
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Multiple bin sizes supported
                    </li>
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Volume discounts available
                    </li>
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Customized service plans
                    </li>
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Priority scheduling
                    </li>
                  </ul>
                </div>

                <div className="mb-6 p-4 bg-eco-green-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-gray-900">Starting at</span>
                    <span className="text-2xl font-bold text-eco-green-600">$40</span>
                  </div>
                  <div className="text-sm text-gray-600">per bin, per service</div>
                </div>

                <Link href="/contact">
                  <Button className="w-full bg-eco-green-500 text-white hover:bg-eco-green-600">
                    Get Quote
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* One-Time Service */}
            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mb-6">
                  <CalendarDays className="h-8 w-8 text-eco-green-600" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">One-Time Cleaning</h3>
                <p className="text-gray-600 mb-6">
                  Deep cleaning service for bins that haven't been maintained or for special cleaning needs. Perfect for new customers.
                </p>
                
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">What's Included:</h4>
                  <ul className="space-y-2">
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Deep sanitization and cleaning
                    </li>
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Same-day service available
                    </li>
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      No long-term commitment
                    </li>
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Perfect for move-ins/move-outs
                    </li>
                    <li className="flex items-center text-gray-600">
                      <Check className="h-4 w-4 text-eco-green-500 mr-3 flex-shrink-0" />
                      Try before you subscribe
                    </li>
                  </ul>
                </div>

                <div className="mb-6 p-4 bg-eco-green-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-gray-900">Starting at</span>
                    <span className="text-2xl font-bold text-eco-green-600">$35</span>
                  </div>
                  <div className="text-sm text-gray-600">per bin, one-time</div>
                </div>

                <Link href="/contact">
                  <Button className="w-full bg-eco-green-500 text-white hover:bg-eco-green-600">
                    Book Now
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Service Features */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Why Choose Us?</h2>
            <p className="text-xl text-gray-600">The benefits that set us apart from the competition</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Clock className="h-8 w-8 text-eco-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Reliable Scheduling</h3>
              <p className="text-gray-600">
                We stick to our schedule and notify you before each service. Count on us to be there when we say we will.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Star className="h-8 w-8 text-eco-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Quality Guarantee</h3>
              <p className="text-gray-600">
                Not satisfied with our service? We'll come back and make it right at no extra charge. Your satisfaction is guaranteed.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <DollarSign className="h-8 w-8 text-eco-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Competitive Pricing</h3>
              <p className="text-gray-600">
                Fair, transparent pricing with no hidden fees. Get the best value for professional bin cleaning services.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-eco-green-50">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Join hundreds of satisfied customers who trust us to keep their bins clean and sanitized.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button className="bg-eco-green-500 text-white hover:bg-eco-green-600 px-8 py-4 text-lg h-auto">
                Schedule Service Today
              </Button>
            </Link>
            <Button 
              variant="outline" 
              className="border-2 border-eco-green-500 text-eco-green-600 hover:bg-eco-green-50 px-8 py-4 text-lg h-auto"
              onClick={() => window.location.href = "tel:8633293195"}
            >
              Call (863) 329-3195
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
