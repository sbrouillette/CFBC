#!/bin/bash

# Complete Ubuntu 24 Deployment Script with Full Source Code
# This script deploys the complete Central Florida Bin Cleaning application

set -e

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}"
echo "=============================================="
echo "Central Florida Bin Cleaning - Complete Deployment"
echo "=============================================="
echo -e "${NC}"

# Check if running as root
if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}Error: This script must be run as root.${NC}"
    echo "Run with: sudo ./deploy-complete.sh"
    exit 1
fi

# Configuration
DB_PASSWORD="SecurePassword123!"
SESSION_SECRET=$(openssl rand -hex 32)
APP_DIR="/var/www/cfbc"
APP_USER="cfbc"

# Get domain name
read -p "Enter your domain name (or press Enter to use server IP): " DOMAIN_NAME
if [ -z "$DOMAIN_NAME" ]; then
    DOMAIN_NAME=$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')
    echo "Using: $DOMAIN_NAME"
fi

echo -e "${GREEN}Starting complete deployment...${NC}"

# Update system
echo "Updating system..."
apt update && apt upgrade -y

# Install essential packages
echo "Installing packages..."
apt install -y curl wget git build-essential software-properties-common ufw htop nginx postgresql postgresql-contrib

# Install Node.js 20
echo "Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install global packages
echo "Installing global packages..."
npm install -g pm2@latest tsx@latest

# Configure PostgreSQL
echo "Setting up database..."
systemctl start postgresql
systemctl enable postgresql

sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS cfbc_production;
DROP USER IF EXISTS cfbc_user;
CREATE DATABASE cfbc_production;
CREATE USER cfbc_user WITH PASSWORD '$DB_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE cfbc_production TO cfbc_user;
ALTER USER cfbc_user CREATEDB;
GRANT ALL ON SCHEMA public TO cfbc_user;
EOF

# Create application user
echo "Creating application user..."
if ! id "$APP_USER" &>/dev/null; then
    useradd -m -s /bin/bash $APP_USER
    usermod -aG sudo $APP_USER
fi

# Stop any existing PM2 processes
sudo -u $APP_USER pm2 kill 2>/dev/null || true

# Remove old installation
echo "Removing old installation..."
rm -rf $APP_DIR
mkdir -p $APP_DIR
chown $APP_USER:$APP_USER $APP_DIR

# Copy application files
echo "Installing application files..."
cp -r ./* $APP_DIR/ 2>/dev/null || true
chown -R $APP_USER:$APP_USER $APP_DIR

# Create environment file
echo "Creating environment configuration..."
cat > $APP_DIR/.env.production << EOF
NODE_ENV=production
DATABASE_URL=postgresql://cfbc_user:$DB_PASSWORD@localhost:5432/cfbc_production
SESSION_SECRET=$SESSION_SECRET
PORT=3000

# Authentication
REPL_ID=your-repl-id
ISSUER_URL=https://replit.com/oidc
REPLIT_DOMAINS=$DOMAIN_NAME

# API Keys (update these after installation)
# SENDGRID_API_KEY=your-sendgrid-api-key
# TWILIO_ACCOUNT_SID=your-twilio-sid
# TWILIO_AUTH_TOKEN=your-twilio-token
# TWILIO_PHONE_NUMBER=your-twilio-phone
# STRIPE_SECRET_KEY=your-stripe-secret-key
# VITE_STRIPE_PUBLIC_KEY=your-stripe-public-key
EOF

chown $APP_USER:$APP_USER $APP_DIR/.env.production

# Install dependencies and build
echo "Installing dependencies..."
cd $APP_DIR
sudo -u $APP_USER npm install

echo "Building application..."
sudo -u $APP_USER npm run build || echo "Build failed, will run in development mode"

echo "Setting up database..."
sudo -u $APP_USER npm run db:push || echo "Database setup will be attempted later"

# Create PM2 ecosystem
echo "Creating PM2 configuration..."
cat > $APP_DIR/ecosystem.config.js << 'EOF'
module.exports = {
  apps: [{
    name: 'cfbc-app',
    script: 'dist/index.js',
    instances: 1,
    exec_mode: 'fork',
    user: 'cfbc',
    cwd: '/var/www/cfbc',
    env_file: '.env.production',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true,
    max_memory_restart: '500M',
    restart_delay: 1000,
    watch: false
  }]
}
EOF

# Create logs directory
sudo -u $APP_USER mkdir -p $APP_DIR/logs

# Create improved management script
echo "Creating management script..."
cat > $APP_DIR/manage.sh << 'EOF'
#!/bin/bash

APP_DIR="/var/www/cfbc"
APP_NAME="cfbc-app"
USER="cfbc"

cd $APP_DIR

case "$1" in
    start)
        echo "Starting Central Florida Bin Cleaning application..."
        
        # Try different startup methods
        if [ -f "dist/index.js" ]; then
            echo "Starting with built production files..."
            sudo -u $USER pm2 start ecosystem.config.js
        elif [ -f "server/index.ts" ]; then
            echo "Starting TypeScript server in development mode..."
            sudo -u $USER pm2 start server/index.ts --name $APP_NAME --interpreter tsx
        else
            echo "Error: No suitable entry point found!"
            echo "Available files:"
            ls -la
            exit 1
        fi
        
        echo "Application started!"
        echo "Access at: http://$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')"
        ;;
    stop)
        echo "Stopping application..."
        sudo -u $USER pm2 stop $APP_NAME 2>/dev/null || echo "Application was not running"
        ;;
    restart)
        echo "Restarting application..."
        sudo -u $USER pm2 restart $APP_NAME 2>/dev/null || $0 start
        ;;
    status)
        echo "=== Application Status ==="
        sudo -u $USER pm2 status
        echo ""
        echo "=== System Services ==="
        systemctl is-active nginx && echo "✓ Nginx: running" || echo "✗ Nginx: stopped"
        systemctl is-active postgresql && echo "✓ PostgreSQL: running" || echo "✗ PostgreSQL: stopped"
        echo ""
        echo "=== Quick Test ==="
        curl -s http://localhost:3000/health || echo "Application not responding on port 3000"
        ;;
    logs)
        echo "Application logs (press Ctrl+C to exit):"
        sudo -u $USER pm2 logs $APP_NAME
        ;;
    build)
        echo "Rebuilding application..."
        sudo -u $USER npm install
        sudo -u $USER npm run build || echo "Build failed"
        sudo -u $USER npm run db:push || echo "Database push failed"
        echo "Restart the application: ./manage.sh restart"
        ;;
    db-setup)
        echo "Setting up database..."
        sudo -u $USER npm run db:push
        ;;
    *)
        echo "Central Florida Bin Cleaning - Management Commands"
        echo "Usage: $0 {start|stop|restart|status|logs|build|db-setup}"
        echo ""
        echo "start     - Start the application"
        echo "stop      - Stop the application"
        echo "restart   - Restart the application"
        echo "status    - Show application and system status"
        echo "logs      - Show real-time application logs"
        echo "build     - Rebuild the application"
        echo "db-setup  - Initialize database schema"
        ;;
esac
EOF

chmod +x $APP_DIR/manage.sh

# Configure Nginx
echo "Configuring web server..."
cat > /etc/nginx/sites-available/cfbc << EOF
server {
    listen 80;
    server_name $DOMAIN_NAME;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/javascript
        application/xml+rss
        application/json;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }

    # Health check endpoint
    location /health {
        proxy_pass http://localhost:3000/health;
        access_log off;
    }
}
EOF

# Enable site
ln -sf /etc/nginx/sites-available/cfbc /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test and start Nginx
nginx -t && systemctl restart nginx
systemctl enable nginx

# Configure firewall
echo "Configuring firewall..."
ufw --force enable
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw allow 80
ufw allow 443

# Start application
echo "Starting application..."
cd $APP_DIR
./manage.sh start

# Set up PM2 startup
echo "Configuring auto-startup..."
sudo -u $APP_USER pm2 startup | grep -E '^sudo' | bash || true
sudo -u $APP_USER pm2 save

# Set up backup system
echo "Setting up backups..."
mkdir -p /backups
cat > /etc/cron.daily/cfbc-backup << 'EOF'
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p /backups
sudo -u postgres pg_dump cfbc_production > /backups/cfbc_$DATE.sql
gzip /backups/cfbc_$DATE.sql
find /backups -name "cfbc_*.sql.gz" -mtime +7 -delete
echo "Backup created: /backups/cfbc_$DATE.sql.gz"
EOF

chmod +x /etc/cron.daily/cfbc-backup

# Wait a moment for application to start
sleep 5

# Final status check
echo
echo -e "${GREEN}=== Deployment Complete ===${NC}"
echo

cd $APP_DIR
./manage.sh status

echo
echo -e "${GREEN}Your Central Florida Bin Cleaning application is now deployed!${NC}"
echo
echo "Access your application at:"
echo "  http://$DOMAIN_NAME"
echo
echo "Default login accounts:"
echo "  Admin: admin / admin123"
echo "  Customer: customer1 / customer123"
echo "  Driver: driver1 / driver123"
echo "  Dispatcher: dispatcher1 / dispatcher123"
echo
echo -e "${YELLOW}Important next steps:${NC}"
echo "1. Change default passwords immediately"
echo "2. Update API keys in: $APP_DIR/.env.production"
echo "3. Restart application: $APP_DIR/manage.sh restart"
echo
echo "Management commands:"
echo "  $APP_DIR/manage.sh {start|stop|restart|status|logs|build|db-setup}"
echo
echo "Database credentials:"
echo "  Database: cfbc_production"
echo "  Username: cfbc_user"
echo "  Password: $DB_PASSWORD"
echo
echo -e "${GREEN}Deployment successful!${NC}"