# Central Florida Bin Cleaning - Full Stack Application

## Overview

This is a comprehensive full-stack web application for Central Florida Bin Cleaning, a professional trash bin cleaning service. The application features a modern React frontend with TypeScript, an Express.js backend API, PostgreSQL database with Drizzle ORM, and Replit authentication integration. The system supports multiple user roles (customers, drivers, dispatchers, admins) with role-based portals and functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Shadcn/UI components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom eco-friendly green color palette
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and building

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Style**: RESTful API endpoints
- **Authentication**: Replit Auth with OpenID Connect (OIDC)
- **Session Management**: Express sessions with PostgreSQL storage
- **Database Integration**: Drizzle ORM for type-safe database operations

### Database Architecture
- **Database**: PostgreSQL (configured for Neon serverless)
- **ORM**: Drizzle ORM with Drizzle Kit for migrations
- **Schema Location**: Shared schema in `/shared/schema.ts`
- **Migration Strategy**: Push-based migrations via `drizzle-kit push`

## Key Components

### User Management System
- **Multi-role Architecture**: Supports customer, driver, dispatcher, and admin roles
- **Replit Auth Integration**: Uses Replit's OIDC for authentication
- **Session Management**: PostgreSQL-backed sessions with configurable TTL
- **Role-based Access Control**: Different portal interfaces per user role

### Business Logic Components
- **Service Requests**: Customer-initiated cleaning requests
- **Job Management**: Driver assignment and job tracking system
- **Invoice System**: Billing and payment tracking
- **Contact System**: Public contact form for lead generation

### Frontend Portal System
- **Customer Portal**: Service requests, invoice viewing, scheduling
- **Driver Portal**: Job assignments, status updates, route management
- **Dispatcher Portal**: Job assignment, driver management, scheduling
- **Admin Portal**: User management, system oversight, analytics

### Shared Components
- **UI Library**: Comprehensive Shadcn/UI component system
- **Schema Validation**: Shared Zod schemas between frontend and backend
- **Type Safety**: Full TypeScript integration across the stack

## Data Flow

### Authentication Flow
1. User initiates login via `/api/login` endpoint
2. Redirects to Replit OIDC provider
3. Callback processes tokens and creates/updates user record
4. Session established with PostgreSQL storage
5. Frontend receives user data via `/api/auth/user`

### Service Request Flow
1. Customer submits service request through portal
2. Request validated using shared Zod schema
3. Backend creates record linking to customer ID
4. Dispatcher can view and assign to drivers
5. Driver receives assignment and updates status
6. System generates invoice upon completion

### Job Management Flow
1. Service requests converted to jobs by dispatcher
2. Jobs assigned to drivers with priority levels
3. Driver portal shows assigned jobs with location data
4. Status updates flow back through API
5. Completion triggers invoice generation

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Headless UI components
- **openid-client**: OIDC authentication
- **express-session**: Session management

### Development Dependencies
- **vite**: Frontend build tool with HMR
- **tsx**: TypeScript execution for development
- **esbuild**: Production backend bundling
- **tailwindcss**: Utility-first CSS framework

### Replit-Specific Integrations
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay
- **@replit/vite-plugin-cartographer**: Development tooling
- **Replit Auth**: Integrated authentication system

## Deployment Strategy

### Development Environment
- **Frontend**: Vite dev server with HMR on client directory
- **Backend**: tsx for TypeScript execution with nodemon-like behavior
- **Database**: Neon PostgreSQL with connection pooling
- **Sessions**: PostgreSQL table-based session storage

### Production Build Process
1. **Frontend Build**: Vite builds React app to `dist/public`
2. **Backend Build**: esbuild bundles server code to `dist/index.js`
3. **Database**: Drizzle migrations applied via push command
4. **Static Assets**: Frontend served by Express in production

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **SESSION_SECRET**: Session encryption key (required)
- **REPL_ID**: Replit environment identifier
- **ISSUER_URL**: OIDC provider URL (defaults to Replit)
- **REPLIT_DOMAINS**: Allowed domains for authentication

### Production Considerations
- Backend serves static frontend files in production
- Database connection pooling via Neon serverless
- Session storage in PostgreSQL for scalability
- HTTPS required for authentication cookies
- Environment-specific OIDC configuration

## Recent Changes

### January 28, 2025
- Enhanced customer portal with comprehensive service request functionality
- Added service selection modal with pricing and preferred scheduling options
- Implemented working View Schedule feature showing customer jobs with status tracking
- Added Payment Methods modal ready for Stripe integration
- Fixed job selection and route creation functionality in admin portal
- Created comprehensive Ubuntu VPS deployment guide with automated installation script
- Added management scripts for production deployment and maintenance
- Created Ubuntu 24.04 LTS specific deployment guide with automated installer
- Fixed deployment issues with PM2 installation and build failures
- Added beginner-friendly step-by-step deployment instructions
- Successfully deployed application to Ubuntu VPS with working Express server
- Resolved permission conflicts and npm build failures through alternative deployment approach
- Application now accessible and operational with basic functionality and landing page
- Deployed complete management system with multi-role authentication and database integration
- Added customer, driver, dispatcher, and admin portals with role-based access control
- Implemented PostgreSQL session management and RESTful API endpoints