import sgMail from '@sendgrid/mail';
import { storage } from './storage';

// Types for notifications
interface NotificationData {
  customerId: string;
  type: 'job_scheduled' | 'job_completed' | 'driver_en_route' | 'service_requested';
  jobId?: string;
  message: string;
  subject?: string;
}

interface SMSConfig {
  accountSid: string;
  authToken: string;
  phoneNumber: string;
}

interface EmailConfig {
  apiKey: string;
  fromEmail: string;
  fromName: string;
}

// Initialize Twilio client
let twilioClient: any = null;

function getTwilioClient() {
  if (!twilioClient) {
    try {
      const twilio = require('twilio');
      const accountSid = process.env.TWILIO_ACCOUNT_SID;
      const authToken = process.env.TWILIO_AUTH_TOKEN;
      
      if (accountSid && authToken) {
        twilioClient = twilio(accountSid, authToken);
      }
    } catch (error) {
      console.log('Twilio not configured or not available');
    }
  }
  return twilioClient;
}

// Initialize SendGrid
if (process.env.SENDGRID_API_KEY) {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
}

export class NotificationService {
  private async getNotificationSettings(): Promise<{
    emailEnabled: boolean;
    smsEnabled: boolean;
    emailConfig?: EmailConfig;
    smsConfig?: SMSConfig;
  }> {
    try {
      const configs = await storage.getSystemConfigByKeys([
        'notifications_email_enabled',
        'notifications_sms_enabled',
        'sendgrid_api_key',
        'email_from_address',
        'email_from_name',
        'twilio_account_sid',
        'twilio_auth_token',
        'twilio_phone_number'
      ]);

      const emailEnabled = configs.find(c => c.configKey === 'notifications_email_enabled')?.configValue === 'true';
      const smsEnabled = configs.find(c => c.configKey === 'notifications_sms_enabled')?.configValue === 'true';

      const emailConfig: EmailConfig | undefined = emailEnabled ? {
        apiKey: configs.find(c => c.configKey === 'sendgrid_api_key')?.configValue || '',
        fromEmail: configs.find(c => c.configKey === 'email_from_address')?.configValue || 'noreply@cfbincleaning.com',
        fromName: configs.find(c => c.configKey === 'email_from_name')?.configValue || 'Central Florida Bin Cleaning'
      } : undefined;

      const smsConfig: SMSConfig | undefined = smsEnabled ? {
        accountSid: configs.find(c => c.configKey === 'twilio_account_sid')?.configValue || '',
        authToken: configs.find(c => c.configKey === 'twilio_auth_token')?.configValue || '',
        phoneNumber: configs.find(c => c.configKey === 'twilio_phone_number')?.configValue || ''
      } : undefined;

      return { emailEnabled, smsEnabled, emailConfig, smsConfig };
    } catch (error) {
      console.error('Error fetching notification settings:', error);
      return { emailEnabled: false, smsEnabled: false };
    }
  }

  async sendNotification(data: NotificationData): Promise<void> {
    try {
      const customer = await storage.getUser(data.customerId);
      if (!customer) {
        console.log(`Customer ${data.customerId} not found for notification`);
        return;
      }

      const settings = await this.getNotificationSettings();

      // Send email notification
      if (settings.emailEnabled && settings.emailConfig && customer.email) {
        await this.sendEmailNotification(customer.email, data, settings.emailConfig);
      }

      // Send SMS notification
      if (settings.smsEnabled && settings.smsConfig && customer.phone) {
        await this.sendSMSNotification(customer.phone, data, settings.smsConfig);
      }

    } catch (error) {
      console.error('Error sending notification:', error);
    }
  }

  private async sendEmailNotification(email: string, data: NotificationData, config: EmailConfig): Promise<void> {
    try {
      if (!config.apiKey) {
        console.log('SendGrid API key not configured');
        return;
      }

      sgMail.setApiKey(config.apiKey);

      const msg = {
        to: email,
        from: {
          email: config.fromEmail,
          name: config.fromName
        },
        subject: data.subject || this.getEmailSubject(data.type),
        html: this.getEmailTemplate(data)
      };

      await sgMail.send(msg);
      console.log(`Email notification sent to ${email} for ${data.type}`);
    } catch (error) {
      console.error('Error sending email:', error);
    }
  }

  private async sendSMSNotification(phoneNumber: string, data: NotificationData, config: SMSConfig): Promise<void> {
    try {
      const client = getTwilioClient();
      if (!client || !config.phoneNumber) {
        console.log('Twilio not configured properly');
        return;
      }

      await client.messages.create({
        body: this.getSMSMessage(data),
        from: config.phoneNumber,
        to: phoneNumber
      });

      console.log(`SMS notification sent to ${phoneNumber} for ${data.type}`);
    } catch (error) {
      console.error('Error sending SMS:', error);
    }
  }

  private getEmailSubject(type: NotificationData['type']): string {
    switch (type) {
      case 'job_scheduled':
        return 'Service Scheduled - Central Florida Bin Cleaning';
      case 'job_completed':
        return 'Service Completed - Central Florida Bin Cleaning';
      case 'driver_en_route':
        return 'Driver En Route - Central Florida Bin Cleaning';
      case 'service_requested':
        return 'Service Request Received - Central Florida Bin Cleaning';
      default:
        return 'Update from Central Florida Bin Cleaning';
    }
  }

  private getEmailTemplate(data: NotificationData): string {
    const baseTemplate = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #22c55e; color: white; padding: 20px; text-align: center;">
          <h1>Central Florida Bin Cleaning</h1>
        </div>
        <div style="padding: 30px; background-color: #f9f9f9;">
          <p style="font-size: 16px; line-height: 1.6;">${data.message}</p>
          ${data.jobId ? `<p style="color: #666; font-size: 14px;">Job ID: ${data.jobId}</p>` : ''}
          <div style="margin-top: 30px; padding: 20px; background-color: white; border-radius: 8px;">
            <p style="margin: 0; color: #666;">Questions? Contact us at (863) 329-3195</p>
          </div>
        </div>
        <div style="background-color: #22c55e; color: white; padding: 15px; text-align: center; font-size: 14px;">
          Thank you for choosing Central Florida Bin Cleaning!
        </div>
      </div>
    `;
    return baseTemplate;
  }

  private getSMSMessage(data: NotificationData): string {
    let message = `Central Florida Bin Cleaning: ${data.message}`;
    if (data.jobId) {
      message += ` (Job: ${data.jobId.slice(0, 8)})`;
    }
    message += ' Questions? Call (863) 329-3195';
    return message;
  }

  // Helper methods for different notification types
  async notifyJobScheduled(customerId: string, jobId: string, scheduledDate: Date): Promise<void> {
    await this.sendNotification({
      customerId,
      type: 'job_scheduled',
      jobId,
      message: `Your bin cleaning service has been scheduled for ${scheduledDate.toLocaleDateString()} at ${scheduledDate.toLocaleTimeString()}. We'll send you another notification when our driver is on the way!`,
      subject: 'Service Scheduled - Central Florida Bin Cleaning'
    });
  }

  async notifyJobCompleted(customerId: string, jobId: string): Promise<void> {
    await this.sendNotification({
      customerId,
      type: 'job_completed',
      jobId,
      message: 'Your bin cleaning service has been completed! Your bins are now fresh and clean. Thank you for choosing our eco-friendly cleaning service.',
      subject: 'Service Completed - Central Florida Bin Cleaning'
    });
  }

  async notifyDriverEnRoute(customerId: string, jobId: string, driverName: string, estimatedArrival?: string): Promise<void> {
    let message = `Great news! ${driverName} is on the way to clean your bins.`;
    if (estimatedArrival) {
      message += ` Estimated arrival: ${estimatedArrival}.`;
    }
    message += ' Please ensure your bins are accessible.';

    await this.sendNotification({
      customerId,
      type: 'driver_en_route',
      jobId,
      message,
      subject: 'Driver En Route - Central Florida Bin Cleaning'
    });
  }

  async notifyServiceRequested(customerId: string, serviceType: string): Promise<void> {
    await this.sendNotification({
      customerId,
      type: 'service_requested',
      message: `We've received your ${serviceType} service request. Our team will review it and get back to you within 24 hours to schedule your bin cleaning service.`,
      subject: 'Service Request Received - Central Florida Bin Cleaning'
    });
  }
}

export const notificationService = new NotificationService();