import { storage } from "./storage";

export async function seedDemoUsers() {
  try {
    // Check if admin user already exists
    const existingAdmin = await storage.getUserByUsername("admin");
    if (existingAdmin) {
      console.log("Demo users already exist, skipping seed");
      return;
    }

    // Create demo users
    const demoUsers = [
      {
        username: "admin",
        password: "admin123",
        firstName: "Admin",
        lastName: "User",
        email: "admin@example.com",
        role: "super_admin" as const, // Make admin a super admin
      },
      {
        username: "customer1",
        password: "customer123",
        firstName: "John",
        lastName: "Doe",
        email: "john@example.com",
        role: "customer" as const,
      },
      {
        username: "driver1",
        password: "driver123",
        firstName: "Jane",
        lastName: "Smith",
        email: "jane@example.com",
        role: "driver" as const,
      },
      {
        username: "dispatcher1",
        password: "dispatcher123",
        firstName: "Bob",
        lastName: "Johnson",
        email: "bob@example.com",
        role: "dispatcher" as const,
      },
    ];

    for (const userData of demoUsers) {
      await storage.createUser(userData);
      console.log(`Created demo user: ${userData.username}`);
    }

    console.log("Demo users created successfully!");
  } catch (error) {
    console.error("Error seeding demo users:", error);
  }
}

export async function seedDemoServices() {
  try {
    // Check if services already exist
    const existingServices = await storage.getAllServices();
    if (existingServices.length > 0) {
      console.log("Demo services already exist, skipping service seed");
      return;
    }

    // Create demo services
    const demoServices = [
      {
        name: "Standard Bin Cleaning",
        serviceType: "residential" as const,
        basePrice: "25.00",
        description: "Basic cleaning service for residential trash bins",
        isActive: true,
      },
      {
        name: "Premium Bin Cleaning",
        serviceType: "residential" as const,
        basePrice: "35.00",
        description: "Deep cleaning with sanitization and deodorization",
        isActive: true,
      },
      {
        name: "Commercial Bin Service",
        serviceType: "commercial" as const,
        basePrice: "45.00",
        description: "Professional cleaning for commercial waste containers",
        isActive: true,
      },
      {
        name: "Multi-Bin Package",
        serviceType: "residential" as const,
        basePrice: "40.00",
        description: "Cleaning service for multiple bins (2-3 bins)",
        isActive: true,
      },
      {
        name: "One-Time Deep Clean",
        serviceType: "residential" as const,
        basePrice: "50.00",
        description: "Intensive one-time cleaning service",
        isActive: true,
      },
    ];

    for (const serviceData of demoServices) {
      await storage.createService(serviceData);
      console.log(`Created demo service: ${serviceData.name}`);
    }

    console.log("Demo services created successfully!");
  } catch (error) {
    console.error("Error seeding demo services:", error);
  }
}