import {
  users,
  jobs,
  invoices,
  serviceRequests,
  contactMessages,
  systemConfig,
  services,
  invoiceServices,
  routes,
  type User,
  type UpsertUser,
  type RegisterData,
  type Job,
  type InsertJob,
  type Invoice,
  type InsertInvoice,
  type ServiceRequest,
  type InsertServiceRequest,
  type ContactMessage,
  type InsertContactMessage,
  type SystemConfig,
  type InsertSystemConfig,
  type Service,
  type InsertService,
  type InvoiceService,
  type InsertInvoiceService,
  type Route,
  type InsertRoute,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, inArray } from "drizzle-orm";
import bcrypt from "bcryptjs";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(userData: RegisterData): Promise<User>;
  authenticateUser(username: string, password: string): Promise<User | null>;
  upsertUser(user: UpsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  getUsersByRole(role: string): Promise<User[]>;
  updateUser(id: string, data: Partial<User>): Promise<void>;
  updateUserStatus(id: string, isActive: boolean): Promise<void>;
  
  // Job operations
  createJob(job: InsertJob): Promise<Job>;
  getJob(id: string): Promise<Job | undefined>;
  getAllJobs(): Promise<Job[]>;
  getJobsByCustomer(customerId: string): Promise<Job[]>;
  getJobsByDriver(driverId: string): Promise<Job[]>;
  getJobsByStatus(status: string): Promise<Job[]>;
  getJobsByDriverAndStatuses(driverId: string, statuses: string[]): Promise<Job[]>;
  getUnassignedJobsByStatuses(statuses: string[]): Promise<Job[]>;
  updateJobStatus(id: string, status: string, completedAt?: Date): Promise<void>;
  updateJob(id: string, data: Partial<Job>): Promise<void>;
  assignJobToDriver(jobId: string, driverId: string, assignedBy: string): Promise<void>;
  getUnassignedJobs(): Promise<Job[]>;
  getJobsByRoute(routeId: string): Promise<Job[]>;
  
  // Invoice operations
  createInvoice(invoice: InsertInvoice): Promise<Invoice>;
  getInvoice(id: string): Promise<Invoice | undefined>;
  getInvoicesByCustomer(customerId: string): Promise<Invoice[]>;
  updateInvoiceStatus(id: string, status: string, paidAt?: Date): Promise<void>;
  generateInvoiceNumber(): Promise<string>;
  
  // Service request operations
  createServiceRequest(request: InsertServiceRequest): Promise<ServiceRequest>;
  getServiceRequest(id: string): Promise<ServiceRequest | undefined>;
  getServiceRequestsByCustomer(customerId: string): Promise<ServiceRequest[]>;
  getPendingServiceRequests(): Promise<ServiceRequest[]>;
  updateServiceRequestStatus(id: string, status: string): Promise<void>;
  deleteServiceRequest(id: string): Promise<void>;
  
  // Contact message operations
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getContactMessages(): Promise<ContactMessage[]>;
  updateContactMessageStatus(id: string, status: string): Promise<void>;
  
  // System configuration operations
  createSystemConfig(config: InsertSystemConfig): Promise<SystemConfig>;
  getSystemConfig(key: string): Promise<SystemConfig | undefined>;
  getAllSystemConfigs(): Promise<SystemConfig[]>;
  updateSystemConfig(key: string, value: string, updatedBy: string): Promise<void>;
  deleteSystemConfig(key: string): Promise<void>;
  
  // Service operations
  createService(service: InsertService): Promise<Service>;
  getService(id: string): Promise<Service | undefined>;
  getAllServices(): Promise<Service[]>;
  getActiveServices(): Promise<Service[]>;
  updateService(id: string, data: Partial<Service>): Promise<void>;
  updateServiceStatus(id: string, isActive: boolean): Promise<void>;
  deleteService(id: string): Promise<void>;
  
  // Invoice service operations
  createInvoiceService(invoiceService: InsertInvoiceService): Promise<InvoiceService>;
  getInvoiceServices(invoiceId: string): Promise<InvoiceService[]>;
  deleteInvoiceService(id: string): Promise<void>;
  
  // Route operations
  createRoute(route: InsertRoute): Promise<Route>;
  getRoute(id: string): Promise<Route | undefined>;
  getRoutesByDriver(driverId: string): Promise<Route[]>;
  getRoutesByDate(date: Date): Promise<Route[]>;
  updateRoute(id: string, data: Partial<Route>): Promise<void>;
  updateRouteStatus(id: string, status: string): Promise<void>;
  deleteRoute(id: string): Promise<void>;
  optimizeRoute(jobIds: string[], startLat?: number, startLng?: number, endLat?: number, endLng?: number): Promise<string[]>;
  assignJobsToRoute(routeId: string, jobIds: string[]): Promise<void>;
  getJobsByRoute(routeId: string): Promise<Job[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(userData: RegisterData): Promise<User> {
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        password: hashedPassword,
      })
      .returning();
    return user;
  }

  async authenticateUser(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    if (!user || !user.isActive) {
      return null;
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return null;
    }

    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getUsersByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role as any));
  }

  async updateUser(id: string, data: Partial<User>): Promise<void> {
    const { password, ...updateData } = data;
    
    if (password) {
      const hashedPassword = await bcrypt.hash(password, 10);
      await db
        .update(users)
        .set({ ...updateData, password: hashedPassword, updatedAt: new Date() })
        .where(eq(users.id, id));
    } else {
      await db
        .update(users)
        .set({ ...updateData, updatedAt: new Date() })
        .where(eq(users.id, id));
    }
  }

  async updateUserStatus(id: string, isActive: boolean): Promise<void> {
    await db
      .update(users)
      .set({ isActive, updatedAt: new Date() })
      .where(eq(users.id, id));
  }

  // Job operations
  async createJob(jobData: InsertJob): Promise<Job> {
    const [job] = await db.insert(jobs).values(jobData).returning();
    return job;
  }

  async getJob(id: string): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job;
  }

  async getAllJobs(): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .orderBy(desc(jobs.createdAt));
  }

  async getJobsByCustomer(customerId: string): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .where(eq(jobs.customerId, customerId))
      .orderBy(desc(jobs.createdAt));
  }

  async getJobsByDriver(driverId: string): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .where(eq(jobs.driverId, driverId))
      .orderBy(desc(jobs.scheduledDate));
  }

  async getJobsByStatus(status: string): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .where(eq(jobs.status, status as any))
      .orderBy(desc(jobs.createdAt));
  }

  async updateJobStatus(id: string, status: string, completedAt?: Date): Promise<void> {
    const updateData: any = { status, updatedAt: new Date() };
    if (completedAt) {
      updateData.completedAt = completedAt;
    }
    await db.update(jobs).set(updateData).where(eq(jobs.id, id));
  }

  async assignJobToDriver(jobId: string, driverId: string, assignedBy: string): Promise<void> {
    await db
      .update(jobs)
      .set({
        driverId,
        assignedBy,
        status: 'assigned',
        updatedAt: new Date(),
      })
      .where(eq(jobs.id, jobId));
  }

  async getUnassignedJobs(): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .where(and(eq(jobs.status, 'pending'), sql`${jobs.driverId} IS NULL`))
      .orderBy(desc(jobs.priority), desc(jobs.createdAt));
  }

  async getJobsByDriverAndStatuses(driverId: string, statuses: string[]): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .where(and(
        eq(jobs.driverId, driverId),
        inArray(jobs.status, statuses as any[])
      ))
      .orderBy(desc(jobs.scheduledDate));
  }

  async getUnassignedJobsByStatuses(statuses: string[]): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .where(and(
        sql`${jobs.driverId} IS NULL`,
        inArray(jobs.status, statuses as any[])
      ))
      .orderBy(desc(jobs.priority), desc(jobs.createdAt));
  }

  async updateJob(id: string, data: Partial<Job>): Promise<void> {
    await db
      .update(jobs)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(jobs.id, id));
  }

  async getJobsByRoute(routeId: string): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .where(eq(jobs.routeId, routeId))
      .orderBy(jobs.routeOrder);
  }

  async getSystemConfigByKeys(keys: string[]): Promise<SystemConfig[]> {
    return await db
      .select()
      .from(systemConfig)
      .where(sql`${systemConfig.configKey} = ANY(${keys})`);
  }

  async getServicesByIds(serviceIds: string[]): Promise<Service[]> {
    return await db
      .select()
      .from(services)
      .where(sql`${services.id} = ANY(${serviceIds})`);
  }

  async createInvoiceService(data: InsertInvoiceService): Promise<InvoiceService> {
    const [invoiceService] = await db
      .insert(invoiceServices)
      .values(data)
      .returning();
    return invoiceService;
  }

  // Invoice operations
  async generateInvoiceNumber(): Promise<string> {
    const year = new Date().getFullYear();
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(invoices)
      .where(sql`EXTRACT(YEAR FROM created_at) = ${year}`);
    
    const count = result[0]?.count || 0;
    return `${year}-${String(count + 1).padStart(3, '0')}`;
  }

  async createInvoice(invoiceData: InsertInvoice): Promise<Invoice> {
    const [invoice] = await db.insert(invoices).values(invoiceData).returning();
    return invoice;
  }

  async getInvoice(id: string): Promise<Invoice | undefined> {
    const [invoice] = await db.select().from(invoices).where(eq(invoices.id, id));
    return invoice;
  }

  async getInvoicesByCustomer(customerId: string): Promise<Invoice[]> {
    return await db
      .select()
      .from(invoices)
      .where(eq(invoices.customerId, customerId))
      .orderBy(desc(invoices.createdAt));
  }

  async updateInvoiceStatus(id: string, status: string, paidAt?: Date): Promise<void> {
    const updateData: any = { status, updatedAt: new Date() };
    if (paidAt) {
      updateData.paidAt = paidAt;
    }
    await db.update(invoices).set(updateData).where(eq(invoices.id, id));
  }

  // Service request operations
  async createServiceRequest(requestData: InsertServiceRequest): Promise<ServiceRequest> {
    const [request] = await db.insert(serviceRequests).values(requestData).returning();
    return request;
  }

  async getServiceRequest(id: string): Promise<ServiceRequest | undefined> {
    const [request] = await db.select().from(serviceRequests).where(eq(serviceRequests.id, id));
    return request;
  }

  async getServiceRequestsByCustomer(customerId: string): Promise<ServiceRequest[]> {
    return await db
      .select()
      .from(serviceRequests)
      .where(eq(serviceRequests.customerId, customerId))
      .orderBy(desc(serviceRequests.createdAt));
  }

  async getPendingServiceRequests(): Promise<ServiceRequest[]> {
    return await db
      .select()
      .from(serviceRequests)
      .where(eq(serviceRequests.status, 'pending'))
      .orderBy(desc(serviceRequests.createdAt));
  }

  async updateServiceRequestStatus(id: string, status: string): Promise<void> {
    await db
      .update(serviceRequests)
      .set({ status })
      .where(eq(serviceRequests.id, id));
  }

  async deleteServiceRequest(id: string): Promise<void> {
    await db.delete(serviceRequests).where(eq(serviceRequests.id, id));
  }

  // Contact message operations
  async createContactMessage(messageData: InsertContactMessage): Promise<ContactMessage> {
    const [message] = await db.insert(contactMessages).values(messageData).returning();
    return message;
  }

  async getContactMessages(): Promise<ContactMessage[]> {
    return await db
      .select()
      .from(contactMessages)
      .orderBy(desc(contactMessages.createdAt));
  }

  async updateContactMessageStatus(id: string, status: string): Promise<void> {
    await db
      .update(contactMessages)
      .set({ status })
      .where(eq(contactMessages.id, id));
  }

  // System configuration operations
  async createSystemConfig(configData: InsertSystemConfig): Promise<SystemConfig> {
    const [config] = await db.insert(systemConfig).values({
      ...configData,
      updatedAt: new Date(),
    }).returning();
    return config;
  }

  async getSystemConfig(key: string): Promise<SystemConfig | undefined> {
    const [config] = await db
      .select()
      .from(systemConfig)
      .where(eq(systemConfig.configKey, key));
    return config;
  }

  async getAllSystemConfigs(): Promise<SystemConfig[]> {
    return await db
      .select()
      .from(systemConfig)
      .orderBy(systemConfig.configKey);
  }

  async updateSystemConfig(key: string, value: string, updatedBy: string): Promise<void> {
    await db
      .update(systemConfig)
      .set({ 
        configValue: value, 
        updatedBy,
        updatedAt: new Date(),
      })
      .where(eq(systemConfig.configKey, key));
  }

  async deleteSystemConfig(key: string): Promise<void> {
    await db.delete(systemConfig).where(eq(systemConfig.configKey, key));
  }

  // Service operations
  async createService(serviceData: InsertService): Promise<Service> {
    const [service] = await db.insert(services).values({
      ...serviceData,
      updatedAt: new Date(),
    }).returning();
    return service;
  }

  async getService(id: string): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service;
  }

  async getAllServices(): Promise<Service[]> {
    return await db
      .select()
      .from(services)
      .orderBy(services.serviceType, services.name);
  }

  async getActiveServices(): Promise<Service[]> {
    return await db
      .select()
      .from(services)
      .where(eq(services.isActive, true))
      .orderBy(services.serviceType, services.name);
  }

  async updateService(id: string, data: Partial<Service>): Promise<void> {
    await db
      .update(services)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(services.id, id));
  }

  async updateServiceStatus(id: string, isActive: boolean): Promise<void> {
    await db
      .update(services)
      .set({ isActive, updatedAt: new Date() })
      .where(eq(services.id, id));
  }

  async deleteService(id: string): Promise<void> {
    await db.delete(services).where(eq(services.id, id));
  }

  // Invoice service operations
  async createInvoiceService(invoiceServiceData: InsertInvoiceService): Promise<InvoiceService> {
    const [invoiceService] = await db.insert(invoiceServices).values(invoiceServiceData).returning();
    return invoiceService;
  }

  async getInvoiceServices(invoiceId: string): Promise<InvoiceService[]> {
    return await db
      .select()
      .from(invoiceServices)
      .where(eq(invoiceServices.invoiceId, invoiceId))
      .orderBy(invoiceServices.createdAt);
  }

  async deleteInvoiceService(id: string): Promise<void> {
    await db.delete(invoiceServices).where(eq(invoiceServices.id, id));
  }

  // Route operations
  async createRoute(routeData: InsertRoute): Promise<Route> {
    const [route] = await db.insert(routes).values({
      ...routeData,
      updatedAt: new Date(),
    }).returning();
    return route;
  }

  async getRoute(id: string): Promise<Route | undefined> {
    const [route] = await db.select().from(routes).where(eq(routes.id, id));
    return route;
  }

  async getRoutesByDriver(driverId: string): Promise<Route[]> {
    return await db
      .select()
      .from(routes)
      .where(eq(routes.driverId, driverId))
      .orderBy(desc(routes.scheduledDate));
  }

  async getRoutesByDate(date: Date): Promise<Route[]> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    return await db
      .select()
      .from(routes)
      .where(and(
        sql`${routes.scheduledDate} >= ${startOfDay}`,
        sql`${routes.scheduledDate} <= ${endOfDay}`
      ))
      .orderBy(routes.scheduledDate);
  }

  async updateRoute(id: string, data: Partial<Route>): Promise<void> {
    await db
      .update(routes)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(routes.id, id));
  }

  async updateRouteStatus(id: string, status: string): Promise<void> {
    await db
      .update(routes)
      .set({ status, updatedAt: new Date() })
      .where(eq(routes.id, id));
  }

  async deleteRoute(id: string): Promise<void> {
    // First, unassign jobs from this route
    await db
      .update(jobs)
      .set({ routeId: null, routeOrder: null })
      .where(eq(jobs.routeId, id));
    
    // Then delete the route
    await db.delete(routes).where(eq(routes.id, id));
  }

  async assignJobsToRoute(routeId: string, jobIds: string[]): Promise<void> {
    // Update jobs to assign them to the route
    for (let i = 0; i < jobIds.length; i++) {
      await db
        .update(jobs)
        .set({ 
          routeId, 
          routeOrder: String(i + 1),
          updatedAt: new Date()
        })
        .where(eq(jobs.id, jobIds[i]));
    }
  }

  async getJobsByRoute(routeId: string): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .where(eq(jobs.routeId, routeId))
      .orderBy(sql`CAST(${jobs.routeOrder} AS INTEGER) ASC`);
  }

  // Simple route optimization using nearest neighbor algorithm
  async optimizeRoute(
    jobIds: string[], 
    startLat: number = 28.5383, // Default to Orlando, FL
    startLng: number = -81.3792,
    endLat?: number,
    endLng?: number
  ): Promise<string[]> {
    if (jobIds.length <= 1) return jobIds;

    // Get job locations
    const jobLocations = await db
      .select({
        id: jobs.id,
        latitude: jobs.latitude,
        longitude: jobs.longitude,
        address: jobs.address,
      })
      .from(jobs)
      .where(sql`${jobs.id} = ANY(${jobIds})`);

    // Filter out jobs without location data
    const validJobs = jobLocations.filter(job => 
      job.latitude && job.longitude
    );

    if (validJobs.length <= 1) return jobIds;

    // Simple nearest neighbor optimization
    const optimized: string[] = [];
    const remaining = [...validJobs];
    let currentLat = startLat;
    let currentLng = startLng;

    while (remaining.length > 0) {
      let nearestIndex = 0;
      let nearestDistance = this.calculateDistance(
        currentLat, 
        currentLng, 
        parseFloat(remaining[0].latitude!), 
        parseFloat(remaining[0].longitude!)
      );

      // Find nearest job
      for (let i = 1; i < remaining.length; i++) {
        const distance = this.calculateDistance(
          currentLat, 
          currentLng, 
          parseFloat(remaining[i].latitude!), 
          parseFloat(remaining[i].longitude!)
        );
        if (distance < nearestDistance) {
          nearestDistance = distance;
          nearestIndex = i;
        }
      }

      const nearestJob = remaining.splice(nearestIndex, 1)[0];
      optimized.push(nearestJob.id);
      currentLat = parseFloat(nearestJob.latitude!);
      currentLng = parseFloat(nearestJob.longitude!);
    }

    // Add any jobs without location data at the end
    const missingJobs = jobIds.filter(id => 
      !validJobs.some(job => job.id === id)
    );
    optimized.push(...missingJobs);

    return optimized;
  }

  // Calculate distance between two points using Haversine formula
  private calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 3959; // Earth's radius in miles
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }
}

export const storage = new DatabaseStorage();
