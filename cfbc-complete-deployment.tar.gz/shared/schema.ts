import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  decimal,
  pgEnum,
  boolean,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User roles enum
export const userRoleEnum = pgEnum('user_role', ['customer', 'driver', 'dispatcher', 'admin', 'super_admin']);

// Job status enum
export const jobStatusEnum = pgEnum('job_status', ['pending', 'assigned', 'in_progress', 'completed', 'cancelled']);

// Job priority enum
export const jobPriorityEnum = pgEnum('job_priority', ['low', 'normal', 'high', 'urgent']);

// Invoice status enum
export const invoiceStatusEnum = pgEnum('invoice_status', ['pending', 'paid', 'overdue', 'cancelled']);

// Service type enum
export const serviceTypeEnum = pgEnum('service_type', ['residential', 'commercial', 'one_time']);

// Users table  
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username").unique().notNull(),
  password: varchar("password").notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: userRoleEnum("role").default('customer'),
  phone: varchar("phone"),
  address: text("address"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Services table
export const services = pgTable("services", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  basePrice: decimal("base_price", { precision: 10, scale: 2 }).notNull(),
  serviceType: serviceTypeEnum("service_type").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Routes table
export const routes = pgTable("routes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  driverId: varchar("driver_id").notNull().references(() => users.id),
  routeName: varchar("route_name").notNull(),
  scheduledDate: timestamp("scheduled_date").notNull(),
  startLocation: text("start_location"),
  startLatitude: decimal("start_latitude", { precision: 10, scale: 8 }),
  startLongitude: decimal("start_longitude", { precision: 11, scale: 8 }),
  endLocation: text("end_location"),
  endLatitude: decimal("end_latitude", { precision: 10, scale: 8 }),
  endLongitude: decimal("end_longitude", { precision: 11, scale: 8 }),
  status: varchar("status").default('planned'), // planned, in_progress, completed, cancelled
  totalDistance: decimal("total_distance", { precision: 10, scale: 2 }), // in miles
  estimatedDuration: varchar("estimated_duration"), // in minutes
  actualDuration: varchar("actual_duration"), // in minutes
  optimizedOrder: jsonb("optimized_order"), // array of job IDs in optimized order
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Jobs table
export const jobs = pgTable("jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").notNull().references(() => users.id),
  driverId: varchar("driver_id").references(() => users.id),
  assignedBy: varchar("assigned_by").references(() => users.id),
  serviceType: serviceTypeEnum("service_type").notNull(),
  status: jobStatusEnum("status").default('pending'),
  priority: jobPriorityEnum("priority").default('normal'),
  scheduledDate: timestamp("scheduled_date"),
  completedAt: timestamp("completed_at"),
  address: text("address").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  notes: text("notes"),
  estimatedPrice: decimal("estimated_price", { precision: 10, scale: 2 }),
  numberOfBins: varchar("number_of_bins").default('1'),
  estimatedDuration: varchar("estimated_duration").default('30'), // minutes
  routeId: varchar("route_id").references(() => routes.id),
  routeOrder: varchar("route_order"), // position in route sequence
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Invoices table
export const invoices = pgTable("invoices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").notNull().references(() => users.id),
  jobId: varchar("job_id").references(() => jobs.id),
  invoiceNumber: varchar("invoice_number").unique().notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  status: invoiceStatusEnum("status").default('pending'),
  dueDate: timestamp("due_date"),
  paidAt: timestamp("paid_at"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Invoice Services junction table
export const invoiceServices = pgTable("invoice_services", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  invoiceId: varchar("invoice_id").notNull().references(() => invoices.id),
  serviceId: varchar("service_id").notNull().references(() => services.id),
  quantity: varchar("quantity").default('1'),
  unitPrice: decimal("unit_price", { precision: 10, scale: 2 }).notNull(),
  totalPrice: decimal("total_price", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Service requests table
export const serviceRequests = pgTable("service_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  customerId: varchar("customer_id").notNull().references(() => users.id),
  serviceType: serviceTypeEnum("service_type").notNull(),
  preferredDate: timestamp("preferred_date"),
  address: text("address").notNull(),
  phone: varchar("phone"),
  notes: text("notes"),
  status: varchar("status").default('pending'),
  createdAt: timestamp("created_at").defaultNow(),
});

// Contact messages table
export const contactMessages = pgTable("contact_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  firstName: varchar("first_name").notNull(),
  lastName: varchar("last_name").notNull(),
  email: varchar("email").notNull(),
  phone: varchar("phone"),
  serviceType: varchar("service_type"),
  message: text("message").notNull(),
  status: varchar("status").default('new'),
  createdAt: timestamp("created_at").defaultNow(),
});

// System Configuration table for Super Admin settings
export const systemConfig = pgTable("system_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  configKey: varchar("config_key").unique().notNull(),
  configValue: text("config_value"),
  description: text("description"),
  isEncrypted: boolean("is_encrypted").default(false),
  updatedBy: varchar("updated_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  jobs: many(jobs, { relationName: "customer_jobs" }),
  assignedJobs: many(jobs, { relationName: "driver_jobs" }),
  invoices: many(invoices),
  serviceRequests: many(serviceRequests),
}));

export const jobsRelations = relations(jobs, ({ one }) => ({
  customer: one(users, {
    fields: [jobs.customerId],
    references: [users.id],
    relationName: "customer_jobs",
  }),
  driver: one(users, {
    fields: [jobs.driverId],
    references: [users.id],
    relationName: "driver_jobs",
  }),
  assignedByUser: one(users, {
    fields: [jobs.assignedBy],
    references: [users.id],
  }),
  route: one(routes, {
    fields: [jobs.routeId],
    references: [routes.id],
  }),
  invoice: one(invoices, {
    fields: [jobs.id],
    references: [invoices.jobId],
  }),
}));

export const invoicesRelations = relations(invoices, ({ one }) => ({
  customer: one(users, {
    fields: [invoices.customerId],
    references: [users.id],
  }),
  job: one(jobs, {
    fields: [invoices.jobId],
    references: [jobs.id],
  }),
}));

export const serviceRequestsRelations = relations(serviceRequests, ({ one }) => ({
  customer: one(users, {
    fields: [serviceRequests.customerId],
    references: [users.id],
  }),
}));

export const routesRelations = relations(routes, ({ one, many }) => ({
  driver: one(users, {
    fields: [routes.driverId],
    references: [users.id],
  }),
  createdByUser: one(users, {
    fields: [routes.createdBy],
    references: [users.id],
  }),
  jobs: many(jobs),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInvoiceSchema = createInsertSchema(invoices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertServiceRequestSchema = createInsertSchema(serviceRequests).omit({
  id: true,
  createdAt: true,
});

export const insertContactMessageSchema = createInsertSchema(contactMessages).omit({
  id: true,
  createdAt: true,
});

export const insertSystemConfigSchema = createInsertSchema(systemConfig).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertServiceSchema = createInsertSchema(services).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInvoiceServiceSchema = createInsertSchema(invoiceServices).omit({
  id: true,
  createdAt: true,
});

export const insertRouteSchema = createInsertSchema(routes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Login schema
export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  email: z.string().email("Invalid email address").optional(),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  role: z.enum(['customer', 'driver', 'dispatcher', 'admin', 'super_admin']).default('customer'),
});

// Types
export type UpsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type LoginData = z.infer<typeof loginSchema>;
export type RegisterData = z.infer<typeof registerSchema>;
export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;
export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type ServiceRequest = typeof serviceRequests.$inferSelect;
export type InsertServiceRequest = z.infer<typeof insertServiceRequestSchema>;
export type ContactMessage = typeof contactMessages.$inferSelect;
export type InsertContactMessage = z.infer<typeof insertContactMessageSchema>;
export type SystemConfig = typeof systemConfig.$inferSelect;
export type InsertSystemConfig = z.infer<typeof insertSystemConfigSchema>;
export type Service = typeof services.$inferSelect;
export type InsertService = z.infer<typeof insertServiceSchema>;
export type InvoiceService = typeof invoiceServices.$inferSelect;
export type InsertInvoiceService = z.infer<typeof insertInvoiceServiceSchema>;
export type Route = typeof routes.$inferSelect;
export type InsertRoute = z.infer<typeof insertRouteSchema>;
