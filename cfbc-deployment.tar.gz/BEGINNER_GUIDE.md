# Ubuntu VPS Deployment - Complete Beginner Guide

This guide will help you deploy the Central Florida Bin Cleaning application step-by-step, even if you're new to servers.

## What You Need Before Starting

- Ubuntu VPS server (20.04 or 22.04)
- SSH access to your server
- Basic terminal knowledge
- Domain name (optional - you can use your server's IP address)

## Option 1: Root User (Easiest)

If you're logged in as `root` or have root access:

### Step 1: Download Files
Upload the deployment files to your server using one of these methods:

**Method A: Using SCP (from your computer)**
```bash
scp cfbc-deployment.tar.gz root@your-server-ip:/root/
```

**Method B: Using wget (if hosted online)**
```bash
wget https://your-website.com/cfbc-deployment.tar.gz
```

**Method C: Using an FTP client like FileZilla**
- Connect to your server
- Upload `cfbc-deployment.tar.gz` to `/root/`

### Step 2: Extract and Run
```bash
cd /root
tar -xzf cfbc-deployment.tar.gz
cd cfbc-deployment
chmod +x install-root.sh
./install-root.sh
```

### Step 3: Follow the Prompts
The script will ask you:
- Domain name (enter your domain or press Enter for IP)
- Database password (press Enter for auto-generated)
- Git repository (optional, press Enter to skip)
- SSL certificate setup (recommended if using domain)

## Option 2: Regular User with Sudo

If you're logged in as a regular user (not root):

### Step 1: Upload Files
```bash
# Upload to your home directory
scp cfbc-deployment.tar.gz username@your-server-ip:/home/username/
```

### Step 2: Extract and Run
```bash
cd ~
tar -xzf cfbc-deployment.tar.gz
cd cfbc-deployment
chmod +x install.sh
./install.sh
```

### Step 3: Choose Automated Installation
When prompted, choose "y" for automated deployment.

## What Happens During Installation

The script will automatically:

1. **Update your server** with latest packages
2. **Install Node.js 20** for running the application
3. **Install PostgreSQL** for the database
4. **Install Nginx** for the web server
5. **Create database** with secure credentials
6. **Build the application** from source code
7. **Configure web server** with security settings
8. **Start the application** using PM2 process manager
9. **Setup SSL certificate** (if you chose this option)
10. **Create management tools** for easy maintenance

## After Installation

### 1. Test Your Application
Open your web browser and go to:
- `http://your-domain.com` (if you used a domain)
- `http://your-server-ip` (if you used IP address)

### 2. Configure API Keys (Important!)
Edit the configuration file:
```bash
nano /var/www/cfbc/.env.production
```

Update these lines with your actual API keys:
```bash
# Email service (get from SendGrid.com)
SENDGRID_API_KEY=your-actual-sendgrid-key

# SMS service (get from Twilio.com)
TWILIO_ACCOUNT_SID=your-actual-twilio-sid
TWILIO_AUTH_TOKEN=your-actual-twilio-token
TWILIO_PHONE_NUMBER=your-actual-twilio-phone

# Payment service (get from Stripe.com)
STRIPE_SECRET_KEY=your-actual-stripe-secret-key
VITE_STRIPE_PUBLIC_KEY=your-actual-stripe-public-key

# Authentication (get from Replit)
REPL_ID=your-actual-repl-id
```

Save the file (Ctrl+X, then Y, then Enter).

### 3. Restart the Application
```bash
/var/www/cfbc/manage.sh restart
```

### 4. Change Default Passwords
Log in with these default accounts and change the passwords:
- **Admin:** username `admin`, password `admin123`
- **Customer:** username `customer1`, password `customer123`
- **Driver:** username `driver1`, password `driver123`
- **Dispatcher:** username `dispatcher1`, password `dispatcher123`

## Managing Your Application

### Check if Everything is Running
```bash
/var/www/cfbc/manage.sh status
```

### View Application Logs
```bash
/var/www/cfbc/manage.sh logs
```

### Restart Application
```bash
/var/www/cfbc/manage.sh restart
```

### Backup Database
```bash
/var/www/cfbc/manage.sh backup
```

### Update Application (if you have git repository)
```bash
/var/www/cfbc/manage.sh update
```

## Getting Your API Keys

### SendGrid (for sending emails)
1. Go to https://sendgrid.com
2. Create a free account
3. Go to Settings → API Keys
4. Create a new API key
5. Copy the key and add it to your .env.production file

### Twilio (for sending SMS)
1. Go to https://twilio.com
2. Create a free account
3. Go to Console Dashboard
4. Copy your Account SID and Auth Token
5. Buy a phone number from Twilio
6. Add all three to your .env.production file

### Stripe (for processing payments)
1. Go to https://stripe.com
2. Create an account
3. Go to Developers → API Keys
4. Copy both the Publishable key and Secret key
5. Add them to your .env.production file

## Troubleshooting

### Application Not Loading?
```bash
# Check application status
/var/www/cfbc/manage.sh status

# Check application logs
/var/www/cfbc/manage.sh logs

# Check if web server is running
sudo systemctl status nginx

# Check if database is running
sudo systemctl status postgresql
```

### Can't Connect to Server?
```bash
# Check firewall settings
sudo ufw status

# Make sure ports are open
sudo ufw allow 80
sudo ufw allow 443
```

### Database Connection Issues?
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Restart PostgreSQL if needed
sudo systemctl restart postgresql
```

### SSL Certificate Issues?
```bash
# Check certificate status
sudo certbot certificates

# Renew certificates
sudo certbot renew
```

## Security Checklist

- [ ] Change all default passwords
- [ ] Add your actual API keys
- [ ] Enable firewall (done automatically)
- [ ] Set up SSL certificate (optional but recommended)
- [ ] Regular backups (set up automatically)
- [ ] Keep server updated: `sudo apt update && sudo apt upgrade`

## Need Help?

1. **Check the logs first:** `/var/www/cfbc/manage.sh logs`
2. **Read the detailed guide:** `cat DEPLOYMENT_GUIDE.md`
3. **Check service status:** Use the troubleshooting commands above
4. **Search online:** Copy any error messages and search for solutions

## Common Error Solutions

### "Permission denied"
Make sure you're running commands with the right user:
- If logged in as root: use `./install-root.sh`
- If logged in as regular user: use `./install.sh`

### "Command not found"
Make sure the script is executable:
```bash
chmod +x install.sh
chmod +x install-root.sh
```

### "Port already in use"
Another service might be using port 80 or 3000:
```bash
sudo netstat -tlnp | grep :80
sudo netstat -tlnp | grep :3000
```

Your application should now be running successfully! The deployment takes care of everything automatically, and you have all the tools you need to manage it.