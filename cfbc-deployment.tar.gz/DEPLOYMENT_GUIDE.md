# Central Florida Bin Cleaning - Ubuntu VPS Deployment Guide

## Prerequisites

- Ubuntu 20.04 or 22.04 VPS server
- Root or sudo access
- Domain name (optional but recommended)
- Basic terminal knowledge

## Option 1: Automated Installation (Recommended)

### Quick Start with Auto-Install Script

1. **Download and run the installation script:**
   ```bash
   wget https://raw.githubusercontent.com/your-repo/central-florida-bin-cleaning/main/deploy.sh
   chmod +x deploy.sh
   sudo ./deploy.sh
   ```

2. **Follow the prompts to configure:**
   - Domain name (or use IP address)
   - Database credentials
   - SSL certificate setup
   - Environment variables

3. **Access your application:**
   - HTTP: `http://your-domain-or-ip:3000`
   - HTTPS: `https://your-domain` (if SSL configured)

---

## Option 2: Manual Step-by-Step Installation

### Step 1: Update System and Install Dependencies

```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install essential packages
sudo apt install -y curl wget git build-essential software-properties-common
```

### Step 2: Install Node.js 20

```bash
# Install Node.js 20 using NodeSource repository
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installation
node --version
npm --version
```

### Step 3: Install and Configure PostgreSQL

```bash
# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Start and enable PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Create database and user
sudo -u postgres psql -c "CREATE DATABASE cfbc_production;"
sudo -u postgres psql -c "CREATE USER cfbc_user WITH PASSWORD 'your_secure_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE cfbc_production TO cfbc_user;"
sudo -u postgres psql -c "ALTER USER cfbc_user CREATEDB;"
```

### Step 4: Install and Configure Nginx

```bash
# Install Nginx
sudo apt install -y nginx

# Start and enable Nginx
sudo systemctl start nginx
sudo systemctl enable nginx

# Allow Nginx through firewall
sudo ufw allow 'Nginx Full'
sudo ufw allow OpenSSH
sudo ufw --force enable
```

### Step 5: Clone and Setup Application

```bash
# Create application directory
sudo mkdir -p /var/www/cfbc
sudo chown $USER:$USER /var/www/cfbc

# Clone repository (replace with your actual repository)
cd /var/www/cfbc
git clone https://github.com/your-username/central-florida-bin-cleaning.git .

# Install dependencies
npm install

# Create production environment file
cat > .env.production << EOF
NODE_ENV=production
DATABASE_URL=postgresql://cfbc_user:your_secure_password@localhost:5432/cfbc_production
SESSION_SECRET=$(openssl rand -hex 32)
REPL_ID=your-repl-id
ISSUER_URL=https://replit.com/oidc
REPLIT_DOMAINS=your-domain.com
PORT=3000
EOF
```

### Step 6: Build Application

```bash
# Build the application
npm run build

# Run database migrations
npm run db:push
```

### Step 7: Setup PM2 Process Manager

```bash
# Install PM2 globally
sudo npm install -y pm2@latest

# Create PM2 ecosystem file
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'cfbc-app',
    script: 'dist/index.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'development'
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000
    }
  }]
}
EOF

# Start application with PM2
pm2 start ecosystem.config.js --env production

# Setup PM2 to start on boot
pm2 startup
pm2 save
```

### Step 8: Configure Nginx Reverse Proxy

```bash
# Create Nginx configuration
sudo tee /etc/nginx/sites-available/cfbc << EOF
server {
    listen 80;
    server_name your-domain.com www.your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# Enable the site
sudo ln -s /etc/nginx/sites-available/cfbc /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default

# Test and reload Nginx
sudo nginx -t
sudo systemctl reload nginx
```

### Step 9: Setup SSL Certificate (Optional but Recommended)

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Obtain SSL certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Setup automatic renewal
sudo crontab -e
# Add this line:
# 0 12 * * * /usr/bin/certbot renew --quiet
```

### Step 10: Configure Firewall

```bash
# Configure UFW firewall
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw --force enable
```

## Configuration

### Environment Variables

Edit `/var/www/cfbc/.env.production` and configure:

```bash
# Database
DATABASE_URL=postgresql://cfbc_user:password@localhost:5432/cfbc_production

# Session Security
SESSION_SECRET=your-random-32-character-string

# Replit Auth (if using)
REPL_ID=your-repl-id
ISSUER_URL=https://replit.com/oidc
REPLIT_DOMAINS=your-domain.com

# Email (SendGrid)
SENDGRID_API_KEY=your-sendgrid-api-key

# SMS (Twilio)
TWILIO_ACCOUNT_SID=your-twilio-sid
TWILIO_AUTH_TOKEN=your-twilio-token
TWILIO_PHONE_NUMBER=your-twilio-phone

# Stripe (for payments)
STRIPE_SECRET_KEY=your-stripe-secret-key
VITE_STRIPE_PUBLIC_KEY=your-stripe-public-key
```

### Database Setup

```bash
# Run migrations
cd /var/www/cfbc
npm run db:push

# Seed initial data (optional)
npm run seed
```

## Management Commands

### Application Management

```bash
# Restart application
pm2 restart cfbc-app

# View logs
pm2 logs cfbc-app

# Monitor application
pm2 monit

# Stop application
pm2 stop cfbc-app

# Start application
pm2 start cfbc-app
```

### Database Management

```bash
# Backup database
sudo -u postgres pg_dump cfbc_production > backup.sql

# Restore database
sudo -u postgres psql cfbc_production < backup.sql

# Access database
sudo -u postgres psql cfbc_production
```

### Nginx Management

```bash
# Test configuration
sudo nginx -t

# Reload configuration
sudo systemctl reload nginx

# Restart Nginx
sudo systemctl restart nginx

# View logs
sudo tail -f /var/log/nginx/error.log
```

## Troubleshooting

### Check Application Status

```bash
# Check PM2 status
pm2 status

# Check application logs
pm2 logs cfbc-app --lines 100

# Check system resources
htop
df -h
```

### Check Services

```bash
# Check Nginx status
sudo systemctl status nginx

# Check PostgreSQL status
sudo systemctl status postgresql

# Check if port 3000 is in use
sudo netstat -tlnp | grep :3000
```

### Common Issues

1. **Application won't start:**
   - Check environment variables in `.env.production`
   - Verify database connection
   - Check PM2 logs: `pm2 logs cfbc-app`

2. **502 Bad Gateway:**
   - Check if application is running: `pm2 status`
   - Verify Nginx configuration: `sudo nginx -t`
   - Check firewall settings: `sudo ufw status`

3. **Database connection errors:**
   - Verify PostgreSQL is running: `sudo systemctl status postgresql`
   - Check database credentials
   - Ensure database exists

4. **SSL certificate issues:**
   - Renew certificate: `sudo certbot renew`
   - Check certificate status: `sudo certbot certificates`

## Security Best Practices

1. **Regular Updates:**
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

2. **Backup Strategy:**
   ```bash
   # Create backup script
   cat > /home/ubuntu/backup.sh << EOF
   #!/bin/bash
   DATE=$(date +%Y%m%d_%H%M%S)
   sudo -u postgres pg_dump cfbc_production > /backups/cfbc_\$DATE.sql
   find /backups -name "cfbc_*.sql" -mtime +7 -delete
   EOF
   
   chmod +x /home/ubuntu/backup.sh
   
   # Add to crontab for daily backups
   echo "0 2 * * * /home/ubuntu/backup.sh" | crontab -
   ```

3. **Monitor Logs:**
   ```bash
   # Setup log rotation
   sudo tee /etc/logrotate.d/cfbc << EOF
   /var/www/cfbc/logs/*.log {
     daily
     rotate 30
     compress
     delaycompress
     missingok
     notifempty
     create 644 ubuntu ubuntu
   }
   EOF
   ```

## Support

For issues or questions:
- Check the application logs: `pm2 logs cfbc-app`
- Review Nginx logs: `sudo tail -f /var/log/nginx/error.log`
- Monitor system resources: `htop` and `df -h`

Remember to replace placeholder values (domain names, passwords, API keys) with your actual values.