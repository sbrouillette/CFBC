# Central Florida Bin Cleaning - Deployment Package

This package contains everything you need to deploy the Central Florida Bin Cleaning application to your Ubuntu VPS server.

## 🚀 Quick Start (Super Easy)

1. **Upload this package to your Ubuntu server**
2. **Extract the files:**
   ```bash
   tar -xzf cfbc-deployment.tar.gz
   cd cfbc-deployment
   ```
3. **Run the installer:**
   ```bash
   ./install.sh
   ```
4. **Follow the prompts** and you're done!

## 📦 What's Included

- **`install.sh`** - Interactive installer script (start here!)
- **`deploy.sh`** - Automated deployment script
- **`SIMPLE_DEPLOYMENT.md`** - Step-by-step guide for beginners
- **`DEPLOYMENT_GUIDE.md`** - Complete technical documentation
- **`README_DEPLOYMENT.md`** - Quick reference guide

## 📋 Prerequisites

- Ubuntu 20.04 or 22.04 VPS server
- SSH access with sudo privileges
- Domain name (optional, can use IP address)

## 🔧 After Deployment

1. **Access your application** at `http://your-domain.com`
2. **Update API keys** in `/var/www/cfbc/.env.production`
3. **Change default passwords** for security

## 🆘 Need Help?

- **Start here:** Run `./install.sh` for interactive setup
- **Beginners:** Read `SIMPLE_DEPLOYMENT.md`
- **Advanced:** Read `DEPLOYMENT_GUIDE.md`
- **Quick reference:** Read `README_DEPLOYMENT.md`

## 🔐 Default Login Accounts

- **Admin:** admin / admin123
- **Customer:** customer1 / customer123
- **Driver:** driver1 / driver123
- **Dispatcher:** dispatcher1 / dispatcher123

**⚠️ Important:** Change these passwords immediately in production!

## 💡 Management Commands

After deployment:
```bash
cd /var/www/cfbc
./manage.sh status    # Check application status
./manage.sh logs      # View logs
./manage.sh restart   # Restart application
./manage.sh backup    # Backup database
```

For questions or issues, check the logs and documentation files included in this package.