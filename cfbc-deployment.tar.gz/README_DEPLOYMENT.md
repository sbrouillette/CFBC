# Quick Deployment to Ubuntu VPS

## 🚀 One-Command Deployment

**For the fastest setup, run this single command on your Ubuntu VPS:**

```bash
curl -sSL https://raw.githubusercontent.com/your-username/central-florida-bin-cleaning/main/deploy.sh | bash
```

## 📋 What You'll Need

- Ubuntu 20.04 or 22.04 VPS
- Root/sudo access
- Domain name (optional)
- Git repository URL

## ⚡ Quick Start Steps

1. **Connect to your VPS:**
   ```bash
   ssh your-username@your-server-ip
   ```

2. **Download the script:**
   ```bash
   wget https://raw.githubusercontent.com/your-username/central-florida-bin-cleaning/main/deploy.sh
   chmod +x deploy.sh
   ```

3. **Run the deployment:**
   ```bash
   ./deploy.sh
   ```

4. **Follow the prompts** to configure:
   - Your domain name
   - Database settings
   - SSL certificate

5. **Access your app** at `http://your-domain.com`

## 🔧 Post-Deployment Configuration

After deployment, update these API keys in `/var/www/cfbc/.env.production`:

```bash
# Required for email notifications
SENDGRID_API_KEY=your-sendgrid-key

# Required for SMS notifications  
TWILIO_ACCOUNT_SID=your-twilio-sid
TWILIO_AUTH_TOKEN=your-twilio-token
TWILIO_PHONE_NUMBER=your-twilio-phone

# Required for payments
STRIPE_SECRET_KEY=your-stripe-secret-key
VITE_STRIPE_PUBLIC_KEY=your-stripe-public-key

# Required for authentication
REPL_ID=your-repl-id
```

Then restart the application:
```bash
cd /var/www/cfbc && ./manage.sh restart
```

## 🛠️ Management Commands

```bash
cd /var/www/cfbc

# Application control
./manage.sh start     # Start the application
./manage.sh stop      # Stop the application  
./manage.sh restart   # Restart the application
./manage.sh status    # Check application status
./manage.sh logs      # View application logs

# Maintenance
./manage.sh backup    # Backup database
./manage.sh update    # Update application from git
```

## 🔍 Troubleshooting

**Application not starting?**
```bash
./manage.sh logs
```

**Check all services:**
```bash
sudo systemctl status nginx postgresql
pm2 status
```

**Database issues?**
```bash
sudo systemctl status postgresql
sudo -u postgres psql cfbc_production
```

For detailed instructions, see [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)

## 🆘 Need Help?

- Check logs: `./manage.sh logs`
- Check status: `./manage.sh status`  
- Review the full deployment guide for troubleshooting steps

## 🔐 Default Login Credentials

After deployment, use these demo accounts:

- **Super Admin:** admin / admin123
- **Customer:** customer1 / customer123
- **Driver:** driver1 / driver123
- **Dispatcher:** dispatcher1 / dispatcher123

**Important:** Change these passwords immediately in production!