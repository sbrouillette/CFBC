# Simple Ubuntu VPS Deployment Guide for Beginners

This guide will help you deploy the Central Florida Bin Cleaning application to your Ubuntu VPS server in simple steps.

## What You Need

- Ubuntu VPS server (20.04 or 22.04)
- SSH access to your server
- Basic terminal knowledge
- Domain name (optional, can use IP address)

## Step 1: Connect to Your Server

Open your terminal (or PuTTY on Windows) and connect to your server:

```bash
ssh your-username@your-server-ip-address
```

Enter your password when prompted.

## Step 2: Download the Application Files

Upload the `cfbc-deployment.tar.gz` file to your server. You can do this several ways:

### Option A: Using SCP (from your local computer)
```bash
scp cfbc-deployment.tar.gz your-username@your-server-ip:/home/your-username/
```

### Option B: Using wget (if you uploaded to a web server)
```bash
wget https://your-website.com/cfbc-deployment.tar.gz
```

### Option C: Using SFTP client like FileZilla
Upload the file to your home directory.

## Step 3: Extract the Files

Once the file is on your server:

```bash
cd ~
tar -xzf cfbc-deployment.tar.gz
cd cfbc-deployment
```

## Step 4: Make the Script Executable

```bash
chmod +x deploy.sh
```

## Step 5: Run the Deployment Script

```bash
sudo ./deploy.sh
```

The script will ask you several questions:

1. **Domain name**: Enter your domain (like `example.com`) or press Enter to use your IP address
2. **Database password**: Press Enter to auto-generate a secure password
3. **Application directory**: Press Enter to use default `/var/www/cfbc`
4. **Git repository**: Enter your GitHub repository URL (if you have one)

## Step 6: Wait for Installation

The script will automatically:
- Update your server
- Install Node.js, PostgreSQL, and Nginx
- Set up the database
- Configure the web server
- Build and start your application

This usually takes 5-15 minutes depending on your server speed.

## Step 7: Configure API Keys (Important!)

After installation, you need to add your API keys:

```bash
sudo nano /var/www/cfbc/.env.production
```

Update these values with your actual keys:

```bash
# For email notifications (get from SendGrid.com)
SENDGRID_API_KEY=your-actual-sendgrid-key

# For SMS notifications (get from Twilio.com)
TWILIO_ACCOUNT_SID=your-actual-twilio-sid
TWILIO_AUTH_TOKEN=your-actual-twilio-token
TWILIO_PHONE_NUMBER=your-actual-twilio-phone

# For payments (get from Stripe.com)
STRIPE_SECRET_KEY=your-actual-stripe-secret-key
VITE_STRIPE_PUBLIC_KEY=your-actual-stripe-public-key

# For authentication (get from Replit)
REPL_ID=your-actual-repl-id
```

Save the file (Ctrl+X, then Y, then Enter).

## Step 8: Restart the Application

```bash
cd /var/www/cfbc
./manage.sh restart
```

## Step 9: Test Your Application

Open your web browser and go to:
- `http://your-domain.com` (if you used a domain)
- `http://your-server-ip-address` (if you used IP address)

## Step 10: Set Up SSL (Optional but Recommended)

If you used a domain name, you can get a free SSL certificate:

```bash
sudo certbot --nginx -d your-domain.com
```

Follow the prompts. After this, you can access your site with `https://your-domain.com`

## Default Login Accounts

Your application comes with these test accounts:

- **Admin**: username `admin`, password `admin123`
- **Customer**: username `customer1`, password `customer123`
- **Driver**: username `driver1`, password `driver123`
- **Dispatcher**: username `dispatcher1`, password `dispatcher123`

**Important**: Change these passwords immediately in production!

## Common Management Commands

```bash
cd /var/www/cfbc

# Start the application
./manage.sh start

# Stop the application
./manage.sh stop

# Restart the application
./manage.sh restart

# View application logs
./manage.sh logs

# Check application status
./manage.sh status

# Backup database
./manage.sh backup

# Update application from git
./manage.sh update
```

## Troubleshooting

### Application not loading?
```bash
cd /var/www/cfbc
./manage.sh status
./manage.sh logs
```

### Check if services are running:
```bash
sudo systemctl status nginx
sudo systemctl status postgresql
```

### Restart all services:
```bash
sudo systemctl restart nginx
sudo systemctl restart postgresql
cd /var/www/cfbc && ./manage.sh restart
```

### Check firewall:
```bash
sudo ufw status
```

If the firewall is blocking traffic:
```bash
sudo ufw allow 80
sudo ufw allow 443
```

## Getting API Keys

### SendGrid (for emails):
1. Go to https://sendgrid.com
2. Create a free account
3. Go to Settings > API Keys
4. Create a new API key
5. Copy the key to your .env.production file

### Twilio (for SMS):
1. Go to https://twilio.com
2. Create a free account
3. Go to Console Dashboard
4. Copy Account SID, Auth Token, and buy a phone number
5. Add these to your .env.production file

### Stripe (for payments):
1. Go to https://stripe.com
2. Create an account
3. Go to Developers > API Keys
4. Copy the publishable key and secret key
5. Add these to your .env.production file

## Need Help?

If you run into issues:

1. Check the logs: `cd /var/www/cfbc && ./manage.sh logs`
2. Check the detailed guide: `cat DEPLOYMENT_GUIDE.md`
3. Make sure all services are running with the commands above

## Security Notes

- Change default passwords immediately
- Keep your server updated: `sudo apt update && sudo apt upgrade`
- Regular backups are automatically set up to run daily
- Monitor your application logs regularly

Your application should now be running successfully!