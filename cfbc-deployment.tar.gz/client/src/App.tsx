import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import About from "@/pages/about";
import Contact from "@/pages/contact";
import Services from "@/pages/services";
import Login from "@/pages/login";
import CustomerPortal from "@/pages/customer-portal";
import DriverPortal from "@/pages/driver-portal";
import DispatcherPortal from "@/pages/dispatcher-portal";
import AdminPortal from "@/pages/admin-portal";

function Router() {
  const { user, isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-eco-green-500"></div>
      </div>
    );
  }

  return (
    <Switch>
      {/* Public routes */}
      <Route path="/" component={Home} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/services" component={Services} />
      <Route path="/login" component={Login} />
      
      {/* Protected portal routes */}
      {isAuthenticated && user?.role === 'customer' && (
        <Route path="/portal" component={CustomerPortal} />
      )}
      {isAuthenticated && user?.role === 'driver' && (
        <Route path="/portal" component={DriverPortal} />
      )}
      {isAuthenticated && user?.role === 'dispatcher' && (
        <Route path="/portal" component={DispatcherPortal} />
      )}
      {isAuthenticated && (user?.role === 'admin' || user?.role === 'super_admin') && (
        <Route path="/portal" component={AdminPortal} />
      )}
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
