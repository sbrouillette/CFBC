import { useState, useEffect } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { MapPin, Route as RouteIcon, Clock, Truck, Plus, Eye, Play, Pause, CheckCircle, Navigation, OptimizeIcon as Optimize } from 'lucide-react';
import type { Route, Job, User } from '@shared/schema';
import RouteMap from './RouteMap';

const routeSchema = z.object({
  driverId: z.string().min(1, 'Driver is required'),
  routeName: z.string().min(1, 'Route name is required'),
  scheduledDate: z.string().min(1, 'Scheduled date is required'),
  startLocation: z.string().optional(),
  endLocation: z.string().optional(),
  jobIds: z.array(z.string()).optional(),
});

type RouteFormData = z.infer<typeof routeSchema>;

interface RouteWithJobs extends Route {
  jobs?: Job[];
}

interface RouteManagementProps {
  userRole: string;
  currentUserId: string;
  hideCreateButton?: boolean;
}

export default function RouteManagement({ userRole, currentUserId, hideCreateButton = false }: RouteManagementProps) {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [selectedRoute, setSelectedRoute] = useState<RouteWithJobs | null>(null);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<RouteFormData>({
    resolver: zodResolver(routeSchema),
    defaultValues: {
      driverId: userRole === 'driver' ? currentUserId : '',
      routeName: '',
      scheduledDate: selectedDate,
      startLocation: '',
      endLocation: '',
      jobIds: [],
    },
  });

  const { data: routes = [], isLoading: loadingRoutes } = useQuery<Route[]>({
    queryKey: ['/api/routes', selectedDate],
    queryFn: () => apiRequest('GET', `/api/routes?date=${selectedDate}`),
  });

  const { data: drivers = [] } = useQuery<User[]>({
    queryKey: ['/api/users', 'driver'],
    queryFn: () => apiRequest('GET', '/api/users?role=driver'),
    enabled: userRole !== 'driver',
  });

  const [watchDriverId, setWatchDriverId] = useState<string>('');
  const selectedDriverId = form.watch('driverId');

  useEffect(() => {
    setWatchDriverId(selectedDriverId || '');
  }, [selectedDriverId]);

  const { data: availableJobs = [] } = useQuery<Job[]>({
    queryKey: ['/api/jobs', 'available', watchDriverId],
    queryFn: () => {
      if (watchDriverId) {
        // Get assigned jobs for the selected driver
        return apiRequest('GET', `/api/jobs?driverId=${watchDriverId}&status=assigned,pending`);
      } else {
        // Get unassigned jobs if no driver selected
        return apiRequest('GET', '/api/jobs?status=pending&unassigned=true');
      }
    },
    enabled: !hideCreateButton,
  });

  const createRouteMutation = useMutation({
    mutationFn: async (data: RouteFormData & { jobIds?: string[] }) => {
      // Geocode start and end locations if provided
      let startCoords = {};
      let endCoords = {};
      
      if (data.startLocation) {
        try {
          const startGeo = await apiRequest('POST', '/api/geocode', { address: data.startLocation });
          startCoords = { 
            startLatitude: startGeo.latitude.toString(), 
            startLongitude: startGeo.longitude.toString() 
          };
        } catch (error) {
          console.warn('Failed to geocode start location:', error);
        }
      }
      
      if (data.endLocation) {
        try {
          const endGeo = await apiRequest('POST', '/api/geocode', { address: data.endLocation });
          endCoords = { 
            endLatitude: endGeo.latitude.toString(), 
            endLongitude: endGeo.longitude.toString() 
          };
        } catch (error) {
          console.warn('Failed to geocode end location:', error);
        }
      }

      return await apiRequest('POST', '/api/routes', {
        ...data,
        scheduledDate: new Date(data.scheduledDate).toISOString(),
        ...startCoords,
        ...endCoords,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/routes'] });
      setShowCreateDialog(false);
      form.reset();
      toast({
        title: 'Success',
        description: 'Route created successfully with optimized order',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: `Failed to create route: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  const updateRouteStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      return await apiRequest('PUT', `/api/routes/${id}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/routes'] });
      toast({
        title: 'Success',
        description: 'Route status updated successfully',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: `Failed to update route status: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  const optimizeRouteMutation = useMutation({
    mutationFn: async ({ routeId, jobIds }: { routeId: string; jobIds: string[] }) => {
      return await apiRequest('PUT', `/api/routes/${routeId}/optimize`, { jobIds });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/routes'] });
      toast({
        title: 'Success',
        description: 'Route optimized successfully',
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: `Failed to optimize route: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  const handleCreateRoute = (data: RouteFormData) => {
    createRouteMutation.mutate(data);
  };

  const handleStatusUpdate = (routeId: string, status: string) => {
    updateRouteStatusMutation.mutate({ id: routeId, status });
  };

  const handleViewDetails = async (route: Route) => {
    try {
      const routeWithJobs = await apiRequest('GET', `/api/routes/${route.id}`);
      setSelectedRoute(routeWithJobs);
      setShowDetailsDialog(true);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load route details',
        variant: 'destructive',
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'planned': return 'secondary';
      case 'in_progress': return 'default';
      case 'completed': return 'default';
      case 'cancelled': return 'destructive';
      default: return 'secondary';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'planned': return Clock;
      case 'in_progress': return Truck;
      case 'completed': return CheckCircle;
      case 'cancelled': return RouteIcon;
      default: return Clock;
    }
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RouteIcon className="h-5 w-5" />
            Route Management
          </CardTitle>
          <CardDescription>
            Manage optimized delivery routes and schedules
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <Label htmlFor="date-filter">Date:</Label>
              <Input
                id="date-filter"
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-auto"
              />
            </div>
            {!hideCreateButton && (
              <Button onClick={() => setShowCreateDialog(true)} className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Create Route
              </Button>
            )}
          </div>

          {loadingRoutes ? (
            <div className="animate-pulse">Loading routes...</div>
          ) : (
            <div className="grid gap-4">
              {Array.isArray(routes) && routes.length > 0 ? routes.map((route: Route) => {
                const StatusIcon = getStatusIcon(route.status);
                return (
                  <div
                    key={route.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <StatusIcon className="h-4 w-4" />
                        <h3 className="font-medium">{route.routeName}</h3>
                        <Badge variant={getStatusColor(route.status)}>
                          {route.status}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground space-y-1">
                        <p>Driver: {Array.isArray(drivers) ? drivers.find(d => d.id === route.driverId)?.firstName : ''} {Array.isArray(drivers) ? drivers.find(d => d.id === route.driverId)?.lastName : ''}</p>
                        {route.startLocation && (
                          <p className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            Start: {route.startLocation}
                          </p>
                        )}
                        {route.totalDistance && (
                          <p>Distance: {route.totalDistance} miles</p>
                        )}
                        {route.estimatedDuration && (
                          <p>Est. Duration: {route.estimatedDuration} minutes</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewDetails(route)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      {userRole !== 'driver' && route.status === 'planned' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleStatusUpdate(route.id, 'in_progress')}
                          disabled={updateRouteStatusMutation.isPending}
                        >
                          <Play className="h-4 w-4" />
                        </Button>
                      )}
                      {route.status === 'in_progress' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleStatusUpdate(route.id, 'completed')}
                          disabled={updateRouteStatusMutation.isPending}
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                );
              }) : (
                <div className="text-center py-8 text-muted-foreground">
                  No routes found for the selected date.
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Route Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Create New Route</DialogTitle>
            <DialogDescription>
              Create an optimized route with automatic job ordering
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleCreateRoute)} className="space-y-4">
              <FormField
                control={form.control}
                name="routeName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Route Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Downtown Route" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {userRole !== 'driver' && (
                <FormField
                  control={form.control}
                  name="driverId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Driver</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select driver" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {Array.isArray(drivers) && drivers.map((driver: User) => (
                            <SelectItem key={driver.id} value={driver.id}>
                              {driver.firstName} {driver.lastName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              <FormField
                control={form.control}
                name="scheduledDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Scheduled Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="startLocation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Location (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., 123 Main St, Orlando, FL" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="endLocation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>End Location (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., 456 Oak Ave, Orlando, FL" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Job Selection */}
              {Array.isArray(availableJobs) && availableJobs.length > 0 && (
                <FormField
                  control={form.control}
                  name="jobIds"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>
                        Jobs to Include in Route ({availableJobs.length} available)
                      </FormLabel>
                      <FormControl>
                        <div className="max-h-40 overflow-y-auto border rounded-md p-2 space-y-2">
                          {availableJobs.map((job: Job) => (
                            <div key={job.id} className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                id={`job-${job.id}`}
                                checked={field.value?.includes(job.id) || false}
                                onChange={(e) => {
                                  const currentValues = field.value || [];
                                  if (e.target.checked) {
                                    field.onChange([...currentValues, job.id]);
                                  } else {
                                    field.onChange(currentValues.filter((id: string) => id !== job.id));
                                  }
                                }}
                              />
                              <label htmlFor={`job-${job.id}`} className="text-sm flex-1 cursor-pointer">
                                <span className="font-medium">{job.customerName}</span>
                                <span className="text-muted-foreground"> - {job.serviceAddress}</span>
                                <span className="text-xs text-muted-foreground block">
                                  Status: {job.status} | Service: {job.serviceType}
                                </span>
                              </label>
                            </div>
                          ))}
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowCreateDialog(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={createRouteMutation.isPending}
                >
                  Create Route
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Route Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedRoute?.routeName}</DialogTitle>
            <DialogDescription>
              Route details and job assignments
            </DialogDescription>
          </DialogHeader>

          {selectedRoute && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Status</Label>
                  <div className="mt-1">
                    <Badge variant={getStatusColor(selectedRoute.status)}>
                      {selectedRoute.status}
                    </Badge>
                  </div>
                </div>
                <div>
                  <Label>Scheduled Date</Label>
                  <p className="mt-1 text-sm">
                    {new Date(selectedRoute.scheduledDate).toLocaleDateString()}
                  </p>
                </div>
                {selectedRoute.totalDistance && (
                  <div>
                    <Label>Total Distance</Label>
                    <p className="mt-1 text-sm">{selectedRoute.totalDistance} miles</p>
                  </div>
                )}
                {selectedRoute.estimatedDuration && (
                  <div>
                    <Label>Estimated Duration</Label>
                    <p className="mt-1 text-sm">{selectedRoute.estimatedDuration} minutes</p>
                  </div>
                )}
              </div>

              {/* Route Map */}
              {selectedRoute.jobs && selectedRoute.jobs.length > 0 && (
                <RouteMap route={selectedRoute} jobs={selectedRoute.jobs} />
              )}

              {selectedRoute.jobs && selectedRoute.jobs.length > 0 && (
                <div>
                  <Label>Jobs in Route ({selectedRoute.jobs.length})</Label>
                  <div className="mt-2 space-y-2 max-h-60 overflow-y-auto">
                    {selectedRoute.jobs.map((job: Job, index: number) => (
                      <div
                        key={job.id}
                        className="flex items-center gap-2 p-2 border rounded"
                      >
                        <Badge variant="outline">{index + 1}</Badge>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{job.address}</p>
                          <p className="text-xs text-muted-foreground">
                            {job.serviceType} • {job.numberOfBins} bin(s)
                          </p>
                        </div>
                        <Badge variant="secondary">{job.status}</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button onClick={() => setShowDetailsDialog(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}