import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Navigation, Clock } from 'lucide-react';
import type { Route, Job } from '@shared/schema';

interface RouteMapProps {
  route: Route;
  jobs: Job[];
}

interface MapPoint {
  id: string;
  lat: number;
  lng: number;
  address: string;
  status: string;
  order?: number;
  type: 'start' | 'job' | 'end';
}

export default function RouteMap({ route, jobs }: RouteMapProps) {
  const mapPoints = useMemo(() => {
    const points: MapPoint[] = [];

    // Add start point if exists
    if (route.startLatitude && route.startLongitude) {
      points.push({
        id: 'start',
        lat: parseFloat(route.startLatitude),
        lng: parseFloat(route.startLongitude),
        address: route.startLocation || 'Start Location',
        status: 'start',
        type: 'start',
      });
    }

    // Add job points
    jobs.forEach((job, index) => {
      if (job.latitude && job.longitude) {
        points.push({
          id: job.id,
          lat: parseFloat(job.latitude),
          lng: parseFloat(job.longitude),
          address: job.address,
          status: job.status,
          order: index + 1,
          type: 'job',
        });
      }
    });

    // Add end point if exists
    if (route.endLatitude && route.endLongitude) {
      points.push({
        id: 'end',
        lat: parseFloat(route.endLatitude),
        lng: parseFloat(route.endLongitude),
        address: route.endLocation || 'End Location',
        status: 'end',
        type: 'end',
      });
    }

    return points;
  }, [route, jobs]);

  // Calculate bounds for the map view
  const bounds = useMemo(() => {
    if (mapPoints.length === 0) return null;

    const lats = mapPoints.map(p => p.lat);
    const lngs = mapPoints.map(p => p.lng);

    return {
      north: Math.max(...lats),
      south: Math.min(...lats),
      east: Math.max(...lngs),
      west: Math.min(...lngs),
      center: {
        lat: lats.reduce((a, b) => a + b, 0) / lats.length,
        lng: lngs.reduce((a, b) => a + b, 0) / lngs.length,
      }
    };
  }, [mapPoints]);

  // Convert lat/lng to SVG coordinates
  const getPointPosition = (point: MapPoint) => {
    if (!bounds) return { x: 0, y: 0 };

    const padding = 20;
    const width = 400 - padding * 2;
    const height = 300 - padding * 2;

    const latRange = bounds.north - bounds.south || 0.01;
    const lngRange = bounds.east - bounds.west || 0.01;

    const x = padding + ((point.lng - bounds.west) / lngRange) * width;
    const y = padding + ((bounds.north - point.lat) / latRange) * height;

    return { x, y };
  };

  const getPointColor = (point: MapPoint) => {
    if (point.type === 'start') return '#10b981'; // green
    if (point.type === 'end') return '#ef4444'; // red
    
    switch (point.status) {
      case 'completed': return '#10b981'; // green
      case 'in_progress': return '#f59e0b'; // amber
      case 'assigned': return '#3b82f6'; // blue
      default: return '#6b7280'; // gray
    }
  };

  if (mapPoints.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Route Map
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            No location data available for this route
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Navigation className="h-5 w-5" />
          Route Map
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* SVG Map */}
          <div className="border rounded-lg bg-slate-50 p-4">
            <svg width="400" height="300" className="w-full h-auto">
              {/* Grid lines */}
              <defs>
                <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                  <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#e2e8f0" strokeWidth="1"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />

              {/* Route lines */}
              {mapPoints.length > 1 && (
                <g>
                  {mapPoints.slice(0, -1).map((point, index) => {
                    const currentPos = getPointPosition(point);
                    const nextPos = getPointPosition(mapPoints[index + 1]);
                    return (
                      <line
                        key={`line-${point.id}`}
                        x1={currentPos.x}
                        y1={currentPos.y}
                        x2={nextPos.x}
                        y2={nextPos.y}
                        stroke="#3b82f6"
                        strokeWidth="2"
                        strokeDasharray="5,5"
                      />
                    );
                  })}
                </g>
              )}

              {/* Route points */}
              {mapPoints.map((point, index) => {
                const pos = getPointPosition(point);
                const color = getPointColor(point);
                
                return (
                  <g key={point.id}>
                    <circle
                      cx={pos.x}
                      cy={pos.y}
                      r="8"
                      fill={color}
                      stroke="white"
                      strokeWidth="2"
                    />
                    {point.type === 'job' && point.order && (
                      <text
                        x={pos.x}
                        y={pos.y + 3}
                        textAnchor="middle"
                        className="text-xs font-bold fill-white"
                      >
                        {point.order}
                      </text>
                    )}
                    {point.type === 'start' && (
                      <text
                        x={pos.x}
                        y={pos.y + 3}
                        textAnchor="middle"
                        className="text-xs font-bold fill-white"
                      >
                        S
                      </text>
                    )}
                    {point.type === 'end' && (
                      <text
                        x={pos.x}
                        y={pos.y + 3}
                        textAnchor="middle"
                        className="text-xs font-bold fill-white"
                      >
                        E
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Legend */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium mb-2">Legend</h4>
              <div className="space-y-1 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <span>Start / Completed</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                  <span>In Progress</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                  <span>Assigned</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <span>End Location</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium mb-2">Route Info</h4>
              <div className="space-y-1 text-sm">
                <div className="flex items-center gap-2">
                  <MapPin className="h-3 w-3" />
                  <span>{mapPoints.filter(p => p.type === 'job').length} stops</span>
                </div>
                {route.totalDistance && (
                  <div className="flex items-center gap-2">
                    <Navigation className="h-3 w-3" />
                    <span>{route.totalDistance} miles</span>
                  </div>
                )}
                {route.estimatedDuration && (
                  <div className="flex items-center gap-2">
                    <Clock className="h-3 w-3" />
                    <span>{route.estimatedDuration} mins</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Route Points List */}
          <div>
            <h4 className="font-medium mb-2">Route Points</h4>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {mapPoints.map((point, index) => (
                <div key={point.id} className="flex items-center justify-between p-2 border rounded text-sm">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: getPointColor(point) }}
                    ></div>
                    <span className="font-medium">
                      {point.type === 'start' && 'Start: '}
                      {point.type === 'end' && 'End: '}
                      {point.type === 'job' && `${point.order}. `}
                      {point.address}
                    </span>
                  </div>
                  {point.type === 'job' && (
                    <Badge variant="outline" className="text-xs">
                      {point.status}
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}