import { Trash2 } from "lucide-react";

export function Logo() {
  return (
    <div className="w-10 h-10 bg-eco-green-500 rounded-lg flex items-center justify-center">
      <Trash2 className="h-6 w-6 text-white" />
    </div>
  );
}
