import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Logo } from "./logo";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export function Navigation() {
  const [location, navigate] = useLocation();
  const { isAuthenticated, user } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const queryClient = useQueryClient();

  const isActiveLink = (path: string) => {
    return location === path;
  };

  const handlePortalLogin = () => {
    navigate('/login');
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      navigate('/');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/">
            <span className="flex items-center space-x-3 cursor-pointer">
              <Logo />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Central Florida</h1>
                <p className="text-sm text-eco-green-600 font-medium">Bin Cleaning</p>
              </div>
            </span>
          </Link>
          
          {/* Desktop Navigation Menu */}
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/">
              <span className={`${
                isActiveLink('/') 
                  ? 'text-eco-green-600 font-medium border-b-2 border-eco-green-500 pb-1' 
                  : 'text-gray-600 hover:text-eco-green-600'
              } transition-colors cursor-pointer`}>
                Home
              </span>
            </Link>
            <Link href="/about">
              <span className={`${
                isActiveLink('/about') 
                  ? 'text-eco-green-600 font-medium border-b-2 border-eco-green-500 pb-1' 
                  : 'text-gray-600 hover:text-eco-green-600'
              } transition-colors cursor-pointer`}>
                About
              </span>
            </Link>
            <Link href="/services">
              <span className={`${
                isActiveLink('/services') 
                  ? 'text-eco-green-600 font-medium border-b-2 border-eco-green-500 pb-1' 
                  : 'text-gray-600 hover:text-eco-green-600'
              } transition-colors cursor-pointer`}>
                Services
              </span>
            </Link>
            <Link href="/contact">
              <span className={`${
                isActiveLink('/contact') 
                  ? 'text-eco-green-600 font-medium border-b-2 border-eco-green-500 pb-1' 
                  : 'text-gray-600 hover:text-eco-green-600'
              } transition-colors cursor-pointer`}>
                Contact
              </span>
            </Link>
            
            {isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <Link href="/portal">
                  <span className="text-eco-green-600 hover:text-eco-green-700 font-medium cursor-pointer">
                    {user?.role?.charAt(0).toUpperCase() + user?.role?.slice(1)} Portal
                  </span>
                </Link>
                <Button 
                  onClick={handleLogout}
                  variant="outline"
                  size="sm"
                >
                  Logout
                </Button>
              </div>
            ) : (
              <Button 
                onClick={handlePortalLogin}
                className="bg-eco-green-500 text-white hover:bg-eco-green-600"
              >
                Portal Login
              </Button>
            )}
          </div>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-600 hover:text-eco-green-600"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-4">
              <Link href="/">
                <span 
                  className={`${
                    isActiveLink('/') ? 'text-eco-green-600 font-medium' : 'text-gray-600'
                  } block py-2 cursor-pointer`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Home
                </span>
              </Link>
              <Link href="/about">
                <span 
                  className={`${
                    isActiveLink('/about') ? 'text-eco-green-600 font-medium' : 'text-gray-600'
                  } block py-2 cursor-pointer`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  About
                </span>
              </Link>
              <Link href="/services">
                <span 
                  className={`${
                    isActiveLink('/services') ? 'text-eco-green-600 font-medium' : 'text-gray-600'
                  } block py-2 cursor-pointer`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Services
                </span>
              </Link>
              <Link href="/contact">
                <span 
                  className={`${
                    isActiveLink('/contact') ? 'text-eco-green-600 font-medium' : 'text-gray-600'
                  } block py-2 cursor-pointer`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Contact
                </span>
              </Link>
              
              {isAuthenticated ? (
                <div className="pt-2 border-t border-gray-200 space-y-2">
                  <Link href="/portal">
                    <span 
                      className="block py-2 text-eco-green-600 font-medium cursor-pointer"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      {user?.role?.charAt(0).toUpperCase() + user?.role?.slice(1)} Portal
                    </span>
                  </Link>
                  <Button 
                    onClick={() => {
                      handleLogout();
                      setIsMobileMenuOpen(false);
                    }}
                    variant="outline"
                    size="sm"
                    className="w-full"
                  >
                    Logout
                  </Button>
                </div>
              ) : (
                <div className="pt-2 border-t border-gray-200">
                  <Button 
                    onClick={() => {
                      handlePortalLogin();
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full bg-eco-green-500 text-white hover:bg-eco-green-600"
                  >
                    Portal Login
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
