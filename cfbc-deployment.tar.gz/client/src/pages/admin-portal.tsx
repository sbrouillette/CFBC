import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Logo } from "@/components/logo";
import ServicesSettings from "@/components/ServicesSettings";
import RouteManagement from "@/components/RouteManagement";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { 
  Settings, 
  Users, 
  Calendar, 
  DollarSign, 
  BarChart3, 
  Plus, 
  Edit, 
  Trash2, 
  Eye,
  MessageSquare,
  UserCheck,
  UserX,
  Clock,
  CheckCircle,
  AlertCircle,
  XCircle,
  Truck,
  MapPin,
  Save,
  RefreshCw,
  Database,
  FileText,
  Download,
  Upload,
  CreditCard,
  ExternalLink,
  Building,
  Bell,
  Shield,
  Route as RouteIcon
} from "lucide-react";

export default function AdminPortal() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("users");
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [showCreateUserModal, setShowCreateUserModal] = useState(false);
  const [showEditUserModal, setShowEditUserModal] = useState(false);
  const [showCreateJobModal, setShowCreateJobModal] = useState(false);
  const [showEditJobModal, setShowEditJobModal] = useState(false);
  const [showCreateRouteModal, setShowCreateRouteModal] = useState(false);
  const [showSystemUpdateModal, setShowSystemUpdateModal] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [editingJob, setEditingJob] = useState<any>(null);
  const [selectedJobs, setSelectedJobs] = useState<string[]>([]);
  const [newRoute, setNewRoute] = useState({
    name: "",
    description: "",
    driverId: "",
    optimized: true
  });
  const [updateProgress, setUpdateProgress] = useState<string[]>([]);
  const [newUser, setNewUser] = useState({
    username: "",
    password: "",
    email: "",
    firstName: "",
    lastName: "",
    phone: "",
    role: "customer" as const
  });
  const [newJob, setNewJob] = useState({
    customerId: "",
    serviceType: "residential" as const,
    serviceIds: [] as string[],
    address: "",
    notes: "",
    priority: "normal" as const,
    scheduledDate: "",
    createInvoice: false
  });
  const [systemSettings, setSystemSettings] = useState({
    companyName: "Central Florida Bin Cleaning",
    phone: "(863) 329-3195",
    address: "Central Florida",
    businessHours: "Monday - Friday: 8:00 AM - 6:00 PM",
    serviceRadius: "50",
    defaultPricing: {
      residential: "25.00",
      commercial: "45.00",
      oneTime: "35.00"
    },
    notifications: {
      emailAlerts: true,
      smsAlerts: false,
      jobReminders: true
    },
    sms: {
      twilioSid: "",
      twilioToken: "",
      twilioPhone: ""
    },
    email: {
      sendgridKey: "",
      fromEmail: "",
      fromName: "Central Florida Bin Cleaning"
    },
    reminders: {
      daysBefore: "1",
      timeOfDay: "09:00"
    }
  });

  const [stripeConfig, setStripeConfig] = useState({
    publishableKey: "",
    secretKey: "",
    webhookSecret: ""
  });

  const [showStripeConfigModal, setShowStripeConfigModal] = useState(false);
  const [showCompanyInfoModal, setShowCompanyInfoModal] = useState(false);
  const [showPricingModal, setShowPricingModal] = useState(false);
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  const [showSMSModal, setShowSMSModal] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [showRemindersModal, setShowRemindersModal] = useState(false);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  // System Update Mutation
  const systemUpdate = useMutation({
    mutationFn: async (updateType: string) => {
      await apiRequest("POST", `/api/admin/system-update`, { updateType });
    },
    onSuccess: (_, updateType) => {
      setUpdateProgress((prev: string[]) => [...prev, `✓ ${updateType} completed successfully`]);
      toast({
        title: "Update Completed",
        description: `${updateType} has been completed successfully.`,
      });
    },
    onError: (error, updateType) => {
      setUpdateProgress((prev: string[]) => [...prev, `✗ ${updateType} failed: ${error.message}`]);
      toast({
        title: "Update Failed",
        description: `${updateType} failed. Please check the logs.`,
        variant: "destructive",
      });
    },
  });

  const handleSystemUpdate = async (updateType: string, description: string) => {
    setUpdateProgress((prev: string[]) => [...prev, `Starting ${description}...`]);
    await systemUpdate.mutateAsync(updateType);
  };

  // System configuration mutations (Super Admin only)
  const createSystemConfig = useMutation({
    mutationFn: async (config: any) => {
      await apiRequest("POST", "/api/system/config", config);
    },
    onSuccess: () => {
      toast({
        title: "Configuration Saved",
        description: "System configuration has been saved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/system/config"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save configuration. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateSystemConfig = useMutation({
    mutationFn: async ({ key, configValue }: { key: string; configValue: string }) => {
      await apiRequest("PUT", `/api/system/config/${key}`, { configValue });
    },
    onSuccess: () => {
      toast({
        title: "Configuration Updated",
        description: "System configuration has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/system/config"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update configuration. Please try again.",
        variant: "destructive",
      });
    },
  });

  const loadSampleData = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/admin/load-sample-data");
    },
    onSuccess: (data) => {
      toast({
        title: "Sample Data Loaded",
        description: `Created ${data.jobsCreated} jobs and ${data.routesCreated} routes with Central Florida locations.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/routes"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to load sample data. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Fetch all users
  const { data: allUsers, isLoading: usersLoading } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const response = await fetch("/api/users", {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch users");
      return response.json();
    },
    enabled: isAuthenticated,
  });

  // Fetch contact messages
  const { data: contactMessages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ["/api/contact-messages"],
    enabled: isAuthenticated,
  });

  // Fetch system configuration (Super Admin only)
  const { data: systemConfig = [] } = useQuery({
    queryKey: ["/api/system/config"],
    enabled: isAuthenticated && user?.role === 'super_admin',
  });

  // Fetch all jobs for overview
  const { data: allJobs } = useQuery({
    queryKey: ["/api/jobs", { all: true }],
    queryFn: async () => {
      const response = await fetch("/api/jobs", {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch jobs");
      return response.json();
    },
    enabled: isAuthenticated,
  });

  // Fetch all services for service selection
  const { data: allServices = [] } = useQuery({
    queryKey: ["/api/services"],
    enabled: isAuthenticated && (user?.role === 'admin' || user?.role === 'super_admin' || user?.role === 'dispatcher')
  });

  // Update user status mutation
  const updateUserStatus = useMutation({
    mutationFn: async ({ userId, isActive }: { userId: string; isActive: boolean }) => {
      await apiRequest("PATCH", `/api/users/${userId}/status`, { isActive });
    },
    onSuccess: () => {
      toast({
        title: "User Updated",
        description: "User status has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update user status. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update job status mutation
  const updateJobStatus = useMutation({
    mutationFn: async ({ jobId, status }: { jobId: string; status: string }) => {
      await apiRequest("PATCH", `/api/jobs/${jobId}/status`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Job Updated",
        description: "Job status has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update job status. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Assign job to driver mutation
  const assignJob = useMutation({
    mutationFn: async ({ jobId, driverId }: { jobId: string; driverId: string }) => {
      await apiRequest("PATCH", `/api/jobs/${jobId}/assign`, { driverId });
    },
    onSuccess: () => {
      toast({
        title: "Job Assigned",
        description: "Job has been assigned to driver successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to assign job. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create user mutation
  const createUser = useMutation({
    mutationFn: async (userData: typeof newUser) => {
      await apiRequest("POST", "/api/users", userData);
    },
    onSuccess: () => {
      toast({
        title: "User Created",
        description: "User has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setShowCreateUserModal(false);
      setNewUser({
        username: "",
        password: "",
        email: "",
        firstName: "",
        lastName: "",
        phone: "",
        role: "customer"
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create user. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update user mutation
  const updateUser = useMutation({
    mutationFn: async ({ userId, userData }: { userId: string; userData: any }) => {
      await apiRequest("PATCH", `/api/users/${userId}`, userData);
    },
    onSuccess: () => {
      toast({
        title: "User Updated",
        description: "User has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setShowEditUserModal(false);
      setEditingUser(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update user. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create job mutation
  const createJob = useMutation({
    mutationFn: async (jobData: typeof newJob) => {
      await apiRequest("POST", "/api/jobs", jobData);
    },
    onSuccess: () => {
      toast({
        title: "Job Created",
        description: "Job has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      setShowCreateJobModal(false);
      setNewJob({
        customerId: "",
        serviceType: "residential",
        serviceIds: [],
        address: "",
        notes: "",
        priority: "normal",
        scheduledDate: "",
        createInvoice: false
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create job. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Edit job mutation
  const editJob = useMutation({
    mutationFn: async (jobData: any) => {
      await apiRequest("PATCH", `/api/jobs/${jobData.id}`, jobData);
    },
    onSuccess: () => {
      toast({
        title: "Job Updated",
        description: "Job has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      setShowEditJobModal(false);
      setEditingJob(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update job. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create route mutation
  const createRoute = useMutation({
    mutationFn: async (routeData: any) => {
      await apiRequest("POST", "/api/routes", routeData);
    },
    onSuccess: () => {
      toast({
        title: "Route Created",
        description: "Route has been created successfully with selected jobs.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/routes"] });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      setShowCreateRouteModal(false);
      setSelectedJobs([]);
      setNewRoute({
        name: "",
        description: "",
        driverId: "",
        optimized: true
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create route. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleUserStatusToggle = (userId: string, currentStatus: boolean) => {
    updateUserStatus.mutate({ userId, isActive: !currentStatus });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-eco-green-500"></div>
      </div>
    );
  }

  if (!isAuthenticated || (user?.role !== 'admin' && user?.role !== 'super_admin')) {
    return null;
  }

  const usersByRole = {
    customer: allUsers?.filter((u: any) => u.role === 'customer') || [],
    driver: allUsers?.filter((u: any) => u.role === 'driver') || [],
    dispatcher: allUsers?.filter((u: any) => u.role === 'dispatcher') || [],
    admin: allUsers?.filter((u: any) => u.role === 'admin') || [],
    super_admin: allUsers?.filter((u: any) => u.role === 'super_admin') || [],
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Logo />
              <h1 className="text-xl font-bold text-gray-900">Administrator Portal</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-gray-600">Welcome, {user?.firstName}</span>
              <Button onClick={handleLogout} variant="outline" size="sm">
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className={`grid w-full ${user?.role === 'super_admin' ? 'grid-cols-7' : 'grid-cols-6'}`}>
            <TabsTrigger value="users" className="flex items-center">
              <Users className="h-4 w-4 mr-2" />
              Users
            </TabsTrigger>
            <TabsTrigger value="jobs" className="flex items-center">
              <Calendar className="h-4 w-4 mr-2" />
              Jobs
            </TabsTrigger>
            <TabsTrigger value="routes" className="flex items-center">
              <MapPin className="h-4 w-4 mr-2" />
              Routes
            </TabsTrigger>
            <TabsTrigger value="messages" className="flex items-center">
              <MessageSquare className="h-4 w-4 mr-2" />
              Messages
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center">
              <BarChart3 className="h-4 w-4 mr-2" />
              Reports
            </TabsTrigger>
            {user?.role === 'super_admin' && (
              <TabsTrigger value="services" className="flex items-center">
                <Truck className="h-4 w-4 mr-2" />
                Services
              </TabsTrigger>
            )}
            <TabsTrigger value="settings" className="flex items-center">
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </TabsTrigger>
          </TabsList>

          {/* User Management Tab */}
          <TabsContent value="users">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* User Stats */}
              <div className="lg:col-span-1 space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">User Overview</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Customers</span>
                      <span className="font-semibold text-eco-green-600">{usersByRole.customer.length}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Drivers</span>
                      <span className="font-semibold text-blue-600">{usersByRole.driver.length}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Dispatchers</span>
                      <span className="font-semibold text-orange-600">{usersByRole.dispatcher.length}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Admins</span>
                      <span className="font-semibold text-purple-600">{usersByRole.admin.length}</span>
                    </div>
                    {user?.role === 'super_admin' && (
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Super Admins</span>
                        <span className="font-semibold text-red-600">{usersByRole.super_admin?.length || 0}</span>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Button 
                  className="w-full bg-eco-green-500 text-white hover:bg-eco-green-600"
                  onClick={() => setShowCreateUserModal(true)}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add User
                </Button>
              </div>

              {/* User List */}
              <div className="lg:col-span-3">
                <Card>
                  <CardHeader>
                    <CardTitle>User Management</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {usersLoading ? (
                      <div className="text-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-eco-green-500 mx-auto"></div>
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead>
                            <tr className="border-b border-gray-200">
                              <th className="text-left py-3 text-sm font-medium text-gray-700">Name</th>
                              <th className="text-left py-3 text-sm font-medium text-gray-700">Email</th>
                              <th className="text-left py-3 text-sm font-medium text-gray-700">Role</th>
                              <th className="text-left py-3 text-sm font-medium text-gray-700">Status</th>
                              <th className="text-left py-3 text-sm font-medium text-gray-700">Created</th>
                              <th className="text-left py-3 text-sm font-medium text-gray-700">Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {allUsers && allUsers.length > 0 ? (
                              allUsers.map((user: any) => (
                                <tr key={user.id} className="border-b border-gray-100">
                                  <td className="py-3 text-sm text-gray-900">
                                    {user.firstName} {user.lastName}
                                  </td>
                                  <td className="py-3 text-sm text-gray-600">{user.email}</td>
                                  <td className="py-3 text-sm text-gray-600 capitalize">{user.role}</td>
                                  <td className="py-3">
                                    <Badge 
                                      variant={user.isActive ? "default" : "secondary"}
                                      className={user.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}
                                    >
                                      {user.isActive ? 'Active' : 'Inactive'}
                                    </Badge>
                                  </td>
                                  <td className="py-3 text-sm text-gray-600">
                                    {new Date(user.createdAt).toLocaleDateString()}
                                  </td>
                                  <td className="py-3">
                                    <div className="flex items-center space-x-2">
                                      {(user.role === 'super_admin' && user?.role !== 'super_admin') ? (
                                        <Badge variant="secondary" className="bg-red-100 text-red-800">
                                          Super Admin
                                        </Badge>
                                      ) : (
                                        <Select
                                          value={user.role}
                                          onValueChange={(role) => updateUser.mutate({ 
                                            userId: user.id, 
                                            userData: { ...user, role } 
                                          })}
                                          disabled={user.role === 'super_admin' && user?.role !== 'super_admin'}
                                        >
                                          <SelectTrigger className="w-24">
                                            <SelectValue />
                                          </SelectTrigger>
                                          <SelectContent>
                                            <SelectItem value="customer">Customer</SelectItem>
                                            <SelectItem value="driver">Driver</SelectItem>
                                            <SelectItem value="dispatcher">Dispatcher</SelectItem>
                                            <SelectItem value="admin">Admin</SelectItem>
                                            {user?.role === 'super_admin' && (
                                              <SelectItem value="super_admin">Super Admin</SelectItem>
                                            )}
                                          </SelectContent>
                                        </Select>
                                      )}
                                      <Button 
                                        variant="ghost" 
                                        size="sm"
                                        onClick={() => {
                                          setEditingUser(user);
                                          setShowEditUserModal(true);
                                        }}
                                      >
                                        <Edit className="h-4 w-4" />
                                      </Button>
                                      <Button 
                                        variant="ghost" 
                                        size="sm"
                                        onClick={() => handleUserStatusToggle(user.id, user.isActive)}
                                        disabled={updateUserStatus.isPending}
                                      >
                                        {user.isActive ? (
                                          <UserX className="h-4 w-4 text-red-500" />
                                        ) : (
                                          <UserCheck className="h-4 w-4 text-green-500" />
                                        )}
                                      </Button>
                                    </div>
                                  </td>
                                </tr>
                              ))
                            ) : (
                              <tr>
                                <td colSpan={6} className="py-8 text-center text-gray-500">
                                  No users found
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Jobs Management Tab */}
          <TabsContent value="jobs">
            <div className="space-y-6">
              {/* Job Statistics */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Pending Jobs</p>
                        <p className="text-2xl font-bold text-orange-600">
                          {allJobs?.filter((job: any) => job.status === 'pending').length || 0}
                        </p>
                      </div>
                      <Clock className="h-8 w-8 text-orange-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">In Progress</p>
                        <p className="text-2xl font-bold text-blue-600">
                          {allJobs?.filter((job: any) => job.status === 'in_progress').length || 0}
                        </p>
                      </div>
                      <Truck className="h-8 w-8 text-blue-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Completed</p>
                        <p className="text-2xl font-bold text-green-600">
                          {allJobs?.filter((job: any) => job.status === 'completed').length || 0}
                        </p>
                      </div>
                      <CheckCircle className="h-8 w-8 text-green-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Cancelled</p>
                        <p className="text-2xl font-bold text-red-600">
                          {allJobs?.filter((job: any) => job.status === 'cancelled').length || 0}
                        </p>
                      </div>
                      <XCircle className="h-8 w-8 text-red-600" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Job Management Table */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Job Management
                    <div className="flex space-x-2">
                      {selectedJobs.length > 0 && (
                        <Button 
                          variant="outline"
                          onClick={() => setShowCreateRouteModal(true)}
                          className="mr-2"
                        >
                          <RouteIcon className="mr-2 h-4 w-4" />
                          Create Route ({selectedJobs.length} jobs)
                        </Button>
                      )}
                      <Button 
                        className="bg-eco-green-500 text-white hover:bg-eco-green-600"
                        onClick={() => setShowCreateJobModal(true)}
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Create Job
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-gray-200">
                          <th className="text-left py-3 text-sm font-medium text-gray-700 w-10">
                            <Checkbox
                              checked={selectedJobs.length === allJobs?.length && allJobs?.length > 0}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setSelectedJobs(allJobs?.map((job: any) => job.id) || []);
                                } else {
                                  setSelectedJobs([]);
                                }
                              }}
                            />
                          </th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Job ID</th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Customer</th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Address</th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Driver</th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Service Type</th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Status</th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Scheduled</th>
                          <th className="text-left py-3 text-sm font-medium text-gray-700">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {allJobs && allJobs.length > 0 ? (
                          allJobs.map((job: any) => (
                            <tr key={job.id} className="border-b border-gray-100">
                              <td className="py-3 text-sm text-gray-900 w-10">
                                <Checkbox
                                  checked={selectedJobs.includes(job.id)}
                                  onCheckedChange={(checked) => {
                                    if (checked) {
                                      setSelectedJobs(prev => [...prev, job.id]);
                                    } else {
                                      setSelectedJobs(prev => prev.filter(id => id !== job.id));
                                    }
                                  }}
                                />
                              </td>
                              <td className="py-3 text-sm text-gray-900 font-mono">
                                {job.id.slice(0, 8)}...
                              </td>
                              <td className="py-3 text-sm text-gray-900">
                                {job.customer?.firstName} {job.customer?.lastName}
                              </td>
                              <td className="py-3 text-sm text-gray-600 max-w-40 truncate">
                                {job.address}
                              </td>
                              <td className="py-3 text-sm text-gray-600">
                                {job.driver ? (
                                  `${job.driver.firstName} ${job.driver.lastName}`
                                ) : (
                                  <span className="text-orange-600">Unassigned</span>
                                )}
                              </td>
                              <td className="py-3 text-sm text-gray-600 capitalize">{job.serviceType}</td>
                              <td className="py-3">
                                <Badge 
                                  variant="secondary"
                                  className={
                                    job.status === 'completed' ? 'bg-green-100 text-green-800' :
                                    job.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                                    job.status === 'pending' ? 'bg-orange-100 text-orange-800' :
                                    'bg-red-100 text-red-800'
                                  }
                                >
                                  {job.status.replace('_', ' ')}
                                </Badge>
                              </td>
                              <td className="py-3 text-sm text-gray-600">
                                {job.scheduledDate ? new Date(job.scheduledDate).toLocaleDateString() : 'Not scheduled'}
                              </td>
                              <td className="py-3">
                                <div className="flex items-center space-x-2">
                                  <Select
                                    value={job.status}
                                    onValueChange={(status) => updateJobStatus.mutate({ jobId: job.id, status })}
                                  >
                                    <SelectTrigger className="w-32">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="pending">Pending</SelectItem>
                                      <SelectItem value="assigned">Assigned</SelectItem>
                                      <SelectItem value="in_progress">In Progress</SelectItem>
                                      <SelectItem value="completed">Completed</SelectItem>
                                      <SelectItem value="cancelled">Cancelled</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  
                                  {!job.driverId && (
                                    <Select
                                      value=""
                                      onValueChange={(driverId) => assignJob.mutate({ jobId: job.id, driverId })}
                                    >
                                      <SelectTrigger className="w-32">
                                        <SelectValue placeholder="Assign driver" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {usersByRole.driver.map((driver: any) => (
                                          <SelectItem key={driver.id} value={driver.id}>
                                            {driver.firstName} {driver.lastName}
                                          </SelectItem>
                                        ))}
                                      </SelectContent>
                                    </Select>
                                  )}
                                  
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      setEditingJob(job);
                                      setShowEditJobModal(true);
                                    }}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={7} className="py-8 text-center text-gray-500">
                              No jobs found
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Routes Management Tab */}
          <TabsContent value="routes">
            <RouteManagement 
              userRole={user?.role || 'admin'} 
              currentUserId={user?.id || ''} 
            />
          </TabsContent>

          {/* Contact Messages Tab */}
          <TabsContent value="messages">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Contact Messages
                  <Badge variant="secondary">
                    {contactMessages?.filter((msg: any) => msg.status === 'new').length || 0} New
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {messagesLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-eco-green-500 mx-auto"></div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {contactMessages && contactMessages.length > 0 ? (
                      contactMessages.map((message: any) => (
                        <div key={message.id} className="border border-gray-200 rounded-lg p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h4 className="font-medium text-gray-900">
                                {message.firstName} {message.lastName}
                              </h4>
                              <p className="text-sm text-gray-600">{message.email}</p>
                              {message.phone && (
                                <p className="text-sm text-gray-600">{message.phone}</p>
                              )}
                            </div>
                            <div className="text-right">
                              <Badge 
                                variant={message.status === 'new' ? 'default' : 'secondary'}
                                className={message.status === 'new' ? 'bg-eco-green-100 text-eco-green-800' : ''}
                              >
                                {message.status}
                              </Badge>
                              <p className="text-sm text-gray-500 mt-1">
                                {new Date(message.createdAt).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                          {message.serviceType && (
                            <p className="text-sm text-gray-600 mb-2">
                              Service: {message.serviceType}
                            </p>
                          )}
                          <p className="text-gray-700">{message.message}</p>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        No contact messages found
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports">
            <div className="space-y-6">
              {/* Overview Statistics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Total Users</p>
                        <p className="text-2xl font-bold text-gray-900">{allUsers?.length || 0}</p>
                      </div>
                      <Users className="h-8 w-8 text-eco-green-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Total Jobs</p>
                        <p className="text-2xl font-bold text-gray-900">{allJobs?.length || 0}</p>
                      </div>
                      <Calendar className="h-8 w-8 text-blue-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Active Drivers</p>
                        <p className="text-2xl font-bold text-gray-900">
                          {usersByRole.driver.filter((d: any) => d.isActive).length}
                        </p>
                      </div>
                      <UserCheck className="h-8 w-8 text-orange-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">New Messages</p>
                        <p className="text-2xl font-bold text-gray-900">
                          {contactMessages?.filter((msg: any) => msg.status === 'new').length || 0}
                        </p>
                      </div>
                      <MessageSquare className="h-8 w-8 text-purple-600" />
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Job Analytics */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="mr-2 h-5 w-5" />
                    Job Status Analytics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <div className="text-center p-4 bg-yellow-50 rounded-lg">
                      <p className="text-2xl font-bold text-yellow-700">
                        {allJobs?.filter((job: any) => job.status === 'pending').length || 0}
                      </p>
                      <p className="text-sm text-yellow-600">Pending</p>
                    </div>
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <p className="text-2xl font-bold text-blue-700">
                        {allJobs?.filter((job: any) => job.status === 'assigned').length || 0}
                      </p>
                      <p className="text-sm text-blue-600">Assigned</p>
                    </div>
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <p className="text-2xl font-bold text-orange-700">
                        {allJobs?.filter((job: any) => job.status === 'in_progress').length || 0}
                      </p>
                      <p className="text-sm text-orange-600">In Progress</p>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <p className="text-2xl font-bold text-green-700">
                        {allJobs?.filter((job: any) => job.status === 'completed').length || 0}
                      </p>
                      <p className="text-sm text-green-600">Completed</p>
                    </div>
                    <div className="text-center p-4 bg-red-50 rounded-lg">
                      <p className="text-2xl font-bold text-red-700">
                        {allJobs?.filter((job: any) => job.status === 'cancelled').length || 0}
                      </p>
                      <p className="text-sm text-red-600">Cancelled</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Downloadable Reports */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Download className="mr-2 h-5 w-5" />
                    Downloadable Reports
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-gray-900">User Report</h4>
                          <p className="text-sm text-gray-600">All users by role and status</p>
                        </div>
                        <FileText className="h-6 w-6 text-blue-600" />
                      </div>
                      <Button 
                        size="sm" 
                        className="w-full"
                        onClick={() => {
                          const csvData = allUsers?.map((user: any) => ({
                            Username: user.username,
                            Name: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
                            Email: user.email || '',
                            Phone: user.phone || '',
                            Role: user.role,
                            Status: user.isActive ? 'Active' : 'Inactive',
                            'Created At': new Date(user.createdAt).toLocaleDateString()
                          })) || [];
                          
                          const csv = [
                            Object.keys(csvData[0] || {}).join(','),
                            ...csvData.map(row => Object.values(row).join(','))
                          ].join('\n');
                          
                          const blob = new Blob([csv], { type: 'text/csv' });
                          const url = window.URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `users-report-${new Date().toISOString().split('T')[0]}.csv`;
                          a.click();
                          window.URL.revokeObjectURL(url);
                        }}
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Download CSV
                      </Button>
                    </div>

                    <div className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-gray-900">Jobs Report</h4>
                          <p className="text-sm text-gray-600">All jobs with details and status</p>
                        </div>
                        <Calendar className="h-6 w-6 text-green-600" />
                      </div>
                      <Button 
                        size="sm" 
                        className="w-full"
                        onClick={() => {
                          const csvData = allJobs?.map((job: any) => ({
                            'Job ID': job.id,
                            Customer: job.customerName || 'Unknown',
                            Address: job.address || '',
                            'Service Type': job.serviceType || '',
                            Status: job.status || '',
                            Priority: job.priority || '',
                            'Scheduled Date': job.scheduledDate ? new Date(job.scheduledDate).toLocaleDateString() : '',
                            'Created At': new Date(job.createdAt).toLocaleDateString(),
                            Driver: job.driverName || 'Unassigned',
                            Notes: job.notes || ''
                          })) || [];
                          
                          const csv = [
                            Object.keys(csvData[0] || {}).join(','),
                            ...csvData.map(row => Object.values(row).map(val => `"${val}"`).join(','))
                          ].join('\n');
                          
                          const blob = new Blob([csv], { type: 'text/csv' });
                          const url = window.URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `jobs-report-${new Date().toISOString().split('T')[0]}.csv`;
                          a.click();
                          window.URL.revokeObjectURL(url);
                        }}
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Download CSV
                      </Button>
                    </div>

                    <div className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-gray-900">Contact Messages</h4>
                          <p className="text-sm text-gray-600">All customer inquiries</p>
                        </div>
                        <MessageSquare className="h-6 w-6 text-purple-600" />
                      </div>
                      <Button 
                        size="sm" 
                        className="w-full"
                        onClick={() => {
                          const csvData = contactMessages?.map((msg: any) => ({
                            Name: `${msg.firstName || ''} ${msg.lastName || ''}`.trim(),
                            Email: msg.email || '',
                            Phone: msg.phone || '',
                            'Service Type': msg.serviceType || '',
                            Status: msg.status || '',
                            Message: msg.message || '',
                            'Created At': new Date(msg.createdAt).toLocaleDateString()
                          })) || [];
                          
                          const csv = [
                            Object.keys(csvData[0] || {}).join(','),
                            ...csvData.map(row => Object.values(row).map(val => `"${val}"`).join(','))
                          ].join('\n');
                          
                          const blob = new Blob([csv], { type: 'text/csv' });
                          const url = window.URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `contact-messages-${new Date().toISOString().split('T')[0]}.csv`;
                          a.click();
                          window.URL.revokeObjectURL(url);
                        }}
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Download CSV
                      </Button>
                    </div>

                    <div className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-gray-900">Driver Performance</h4>
                          <p className="text-sm text-gray-600">Jobs completed by driver</p>
                        </div>
                        <Truck className="h-6 w-6 text-orange-600" />
                      </div>
                      <Button 
                        size="sm" 
                        className="w-full"
                        onClick={() => {
                          const driverStats = usersByRole.driver.map((driver: any) => {
                            const completedJobs = allJobs?.filter((job: any) => 
                              job.driverId === driver.id && job.status === 'completed'
                            ).length || 0;
                            const totalAssigned = allJobs?.filter((job: any) => 
                              job.driverId === driver.id
                            ).length || 0;
                            
                            return {
                              'Driver Name': `${driver.firstName || ''} ${driver.lastName || ''}`.trim(),
                              Username: driver.username,
                              'Jobs Completed': completedJobs,
                              'Total Assigned': totalAssigned,
                              'Completion Rate': totalAssigned > 0 ? `${Math.round((completedJobs / totalAssigned) * 100)}%` : '0%',
                              Status: driver.isActive ? 'Active' : 'Inactive'
                            };
                          });
                          
                          const csv = [
                            Object.keys(driverStats[0] || {}).join(','),
                            ...driverStats.map(row => Object.values(row).join(','))
                          ].join('\n');
                          
                          const blob = new Blob([csv], { type: 'text/csv' });
                          const url = window.URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `driver-performance-${new Date().toISOString().split('T')[0]}.csv`;
                          a.click();
                          window.URL.revokeObjectURL(url);
                        }}
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Download CSV
                      </Button>
                    </div>

                    <div className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-gray-900">Monthly Summary</h4>
                          <p className="text-sm text-gray-600">Jobs and revenue by month</p>
                        </div>
                        <BarChart3 className="h-6 w-6 text-indigo-600" />
                      </div>
                      <Button 
                        size="sm" 
                        className="w-full"
                        onClick={() => {
                          const monthlyData: { [key: string]: { jobs: number, completed: number } } = {};
                          
                          allJobs?.forEach((job: any) => {
                            const month = new Date(job.createdAt).toLocaleDateString('en-US', { 
                              year: 'numeric', 
                              month: 'long' 
                            });
                            if (!monthlyData[month]) {
                              monthlyData[month] = { jobs: 0, completed: 0 };
                            }
                            monthlyData[month].jobs++;
                            if (job.status === 'completed') {
                              monthlyData[month].completed++;
                            }
                          });
                          
                          const csvData = Object.entries(monthlyData).map(([month, data]) => ({
                            Month: month,
                            'Total Jobs': data.jobs,
                            'Completed Jobs': data.completed,
                            'Completion Rate': `${Math.round((data.completed / data.jobs) * 100)}%`
                          }));
                          
                          const csv = [
                            Object.keys(csvData[0] || {}).join(','),
                            ...csvData.map(row => Object.values(row).join(','))
                          ].join('\n');
                          
                          const blob = new Blob([csv], { type: 'text/csv' });
                          const url = window.URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `monthly-summary-${new Date().toISOString().split('T')[0]}.csv`;
                          a.click();
                          window.URL.revokeObjectURL(url);
                        }}
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Download CSV
                      </Button>
                    </div>

                    <div className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-gray-900">Service Analysis</h4>
                          <p className="text-sm text-gray-600">Jobs by service type</p>
                        </div>
                        <Settings className="h-6 w-6 text-gray-600" />
                      </div>
                      <Button 
                        size="sm" 
                        className="w-full"
                        onClick={() => {
                          const serviceData: { [key: string]: number } = {};
                          
                          allJobs?.forEach((job: any) => {
                            const serviceType = job.serviceType || 'Unknown';
                            serviceData[serviceType] = (serviceData[serviceType] || 0) + 1;
                          });
                          
                          const csvData = Object.entries(serviceData).map(([serviceType, count]) => ({
                            'Service Type': serviceType,
                            'Job Count': count,
                            'Percentage': `${Math.round((count / (allJobs?.length || 1)) * 100)}%`
                          }));
                          
                          const csv = [
                            Object.keys(csvData[0] || {}).join(','),
                            ...csvData.map(row => Object.values(row).join(','))
                          ].join('\n');
                          
                          const blob = new Blob([csv], { type: 'text/csv' });
                          const url = window.URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `service-analysis-${new Date().toISOString().split('T')[0]}.csv`;
                          a.click();
                          window.URL.revokeObjectURL(url);
                        }}
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Download CSV
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <div className="space-y-6">
              {/* Settings Overview */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Settings className="mr-2 h-5 w-5" />
                    System Settings
                  </CardTitle>
                  <p className="text-sm text-gray-600">
                    Configure your business settings, pricing, and system preferences
                  </p>
                </CardHeader>
              </Card>

              {/* Settings Categories Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Company Information */}
                <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setShowCompanyInfoModal(true)}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center">
                      <Building className="mr-2 h-5 w-5 text-blue-600" />
                      Company Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      Update company details, contact information, and business hours
                    </p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Company:</span>
                        <span className="font-medium">{systemSettings.companyName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Phone:</span>
                        <span className="font-medium">{systemSettings.phone}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Service Radius:</span>
                        <span className="font-medium">{systemSettings.serviceRadius} miles</span>
                      </div>
                    </div>
                    <Button className="w-full mt-4" variant="outline">
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Company Info
                    </Button>
                  </CardContent>
                </Card>

                {/* Pricing Settings */}
                <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setShowPricingModal(true)}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center">
                      <DollarSign className="mr-2 h-5 w-5 text-green-600" />
                      Default Pricing
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      Set default pricing for residential, commercial, and one-time services
                    </p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Residential:</span>
                        <span className="font-medium">${systemSettings.defaultPricing.residential}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Commercial:</span>
                        <span className="font-medium">${systemSettings.defaultPricing.commercial}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">One-Time:</span>
                        <span className="font-medium">${systemSettings.defaultPricing.oneTime}</span>
                      </div>
                    </div>
                    <Button className="w-full mt-4" variant="outline">
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Pricing
                    </Button>
                  </CardContent>
                </Card>

                {/* Email Notification Settings */}
                <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setShowEmailModal(true)}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center">
                      <Bell className="mr-2 h-5 w-5 text-blue-600" />
                      Email Notifications
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      Configure email alerts and messaging
                    </p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Email Alerts:</span>
                        <Badge variant={systemSettings.notifications.emailAlerts ? "default" : "secondary"}>
                          {systemSettings.notifications.emailAlerts ? "Enabled" : "Disabled"}
                        </Badge>
                      </div>
                    </div>
                    <Button className="w-full mt-4" variant="outline">
                      <Edit className="mr-2 h-4 w-4" />
                      Configure Email
                    </Button>
                  </CardContent>
                </Card>

                {/* SMS Notification Settings */}
                {user?.role === 'super_admin' && (
                  <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setShowSMSModal(true)}>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg flex items-center">
                        <MessageSquare className="mr-2 h-5 w-5 text-green-600" />
                        SMS Notifications
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600 mb-4">
                        Configure SMS alerts and Twilio settings
                      </p>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-500">SMS Alerts:</span>
                          <Badge variant={systemSettings.notifications.smsAlerts ? "default" : "secondary"}>
                            {systemSettings.notifications.smsAlerts ? "Enabled" : "Disabled"}
                          </Badge>
                        </div>
                      </div>
                      <Button className="w-full mt-4" variant="outline">
                        <Edit className="mr-2 h-4 w-4" />
                        Configure SMS
                      </Button>
                    </CardContent>
                  </Card>
                )}

                {/* Automatic Reminders Settings */}
                <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setShowRemindersModal(true)}>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center">
                      <Clock className="mr-2 h-5 w-5 text-orange-600" />
                      Automatic Reminders
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">
                      Configure automatic service reminders
                    </p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Job Reminders:</span>
                        <Badge variant={systemSettings.notifications.jobReminders ? "default" : "secondary"}>
                          {systemSettings.notifications.jobReminders ? "Enabled" : "Disabled"}
                        </Badge>
                      </div>
                    </div>
                    <Button className="w-full mt-4" variant="outline">
                      <Edit className="mr-2 h-4 w-4" />
                      Configure Reminders
                    </Button>
                  </CardContent>
                </Card>
              </div>



              {/* System Configuration */}
              <Card>
                <CardHeader>
                  <CardTitle>System Configuration</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex flex-wrap gap-4">
                    <Button 
                      variant="outline"
                      className="border-2 border-blue-500 text-blue-600 hover:bg-blue-50"
                      onClick={() => setShowSystemUpdateModal(true)}
                    >
                      <RefreshCw className="mr-2 h-4 w-4" />
                      System Update
                    </Button>
                    <Button variant="outline">
                      <Database className="mr-2 h-4 w-4" />
                      Database Maintenance
                    </Button>
                    <Button variant="outline">
                      <FileText className="mr-2 h-4 w-4" />
                      System Logs
                    </Button>
                    {user?.role === 'super_admin' && (
                      <Button 
                        variant="outline"
                        className="border-2 border-green-500 text-green-600 hover:bg-green-50"
                        onClick={() => {
                          if (confirm('This will create 15 sample jobs and 3 routes with Central Florida locations. Continue?')) {
                            loadSampleData.mutate();
                          }
                        }}
                        disabled={loadSampleData.isPending}
                      >
                        <MapPin className="mr-2 h-4 w-4" />
                        {loadSampleData.isPending ? 'Loading...' : 'Load Sample Data'}
                      </Button>
                    )}
                  </div>
                  <div className="text-sm text-gray-600">
                    <p>Use these tools to maintain and update your system configuration, database structure, and monitoring.</p>
                  </div>
                </CardContent>
              </Card>

              {/* Stripe Configuration - Super Admin Only */}
              {user?.role === 'super_admin' && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <CreditCard className="mr-2 h-5 w-5" />
                      Stripe Setup
                    </CardTitle>
                    <p className="text-sm text-gray-600">Configure payment processing settings (Super Admin only)</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                      <p className="text-sm text-amber-800">
                        <strong>Important:</strong> You'll need to obtain your Stripe API keys from your Stripe dashboard. 
                        These keys enable secure payment processing for customer invoices.
                      </p>
                    </div>
                    
                    <div className="grid grid-cols-1 gap-4">
                      <div>
                        <Label htmlFor="stripePublishableKey">Stripe Publishable Key</Label>
                        <Input
                          id="stripePublishableKey"
                          placeholder="pk_live_... or pk_test_..."
                          value={stripeConfig.publishableKey}
                          onChange={(e) => setStripeConfig(prev => ({ ...prev, publishableKey: e.target.value }))}
                        />
                        <p className="text-xs text-gray-500 mt-1">
                          This key is safe to be public and starts with pk_
                        </p>
                      </div>
                      
                      <div>
                        <Label htmlFor="stripeSecretKey">Stripe Secret Key</Label>
                        <Input
                          id="stripeSecretKey"
                          type="password"
                          placeholder="sk_live_... or sk_test_..."
                          value={stripeConfig.secretKey}
                          onChange={(e) => setStripeConfig(prev => ({ ...prev, secretKey: e.target.value }))}
                        />
                        <p className="text-xs text-gray-500 mt-1">
                          Keep this key secret and secure. It starts with sk_
                        </p>
                      </div>
                      
                      <div>
                        <Label htmlFor="stripeWebhookSecret">Webhook Secret (Optional)</Label>
                        <Input
                          id="stripeWebhookSecret"
                          type="password"
                          placeholder="whsec_..."
                          value={stripeConfig.webhookSecret}
                          onChange={(e) => setStripeConfig(prev => ({ ...prev, webhookSecret: e.target.value }))}
                        />
                        <p className="text-xs text-gray-500 mt-1">
                          Used to verify webhook events from Stripe
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button 
                        onClick={() => {
                          toast({
                            title: "Stripe Configuration Saved",
                            description: "Payment processing settings have been updated successfully.",
                          });
                        }}
                        className="bg-eco-green-600 hover:bg-eco-green-700"
                      >
                        <Save className="mr-2 h-4 w-4" />
                        Save Stripe Settings
                      </Button>
                      <Button 
                        variant="outline"
                        onClick={() => setShowStripeConfigModal(true)}
                      >
                        <ExternalLink className="mr-2 h-4 w-4" />
                        How to Get Keys
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Database Status */}
              <Card>
                <CardHeader>
                  <CardTitle>System Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
                      <p className="text-sm font-medium text-green-800">Database</p>
                      <p className="text-xs text-green-600">Connected</p>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
                      <p className="text-sm font-medium text-green-800">API</p>
                      <p className="text-xs text-green-600">Running</p>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
                      <p className="text-sm font-medium text-green-800">Authentication</p>
                      <p className="text-xs text-green-600">Active</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Services Management Tab (Super Admin Only) */}
          {user?.role === 'super_admin' && (
            <TabsContent value="services">
              <ServicesSettings />
            </TabsContent>
          )}
        </Tabs>
      </div>

      {/* Create User Modal */}
      <Dialog open={showCreateUserModal} onOpenChange={setShowCreateUserModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  value={newUser.username}
                  onChange={(e) => setNewUser(prev => ({ ...prev, username: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={newUser.password}
                  onChange={(e) => setNewUser(prev => ({ ...prev, password: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  value={newUser.firstName}
                  onChange={(e) => setNewUser(prev => ({ ...prev, firstName: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  value={newUser.lastName}
                  onChange={(e) => setNewUser(prev => ({ ...prev, lastName: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser(prev => ({ ...prev, email: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone</Label>
                <Input
                  id="phone"
                  value={newUser.phone}
                  onChange={(e) => setNewUser(prev => ({ ...prev, phone: e.target.value }))}
                />
              </div>
            </div>
            <div>
              <Label htmlFor="role">Role</Label>
              <Select value={newUser.role} onValueChange={(role: any) => setNewUser(prev => ({ ...prev, role }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="customer">Customer</SelectItem>
                  <SelectItem value="driver">Driver</SelectItem>
                  <SelectItem value="dispatcher">Dispatcher</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowCreateUserModal(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => createUser.mutate(newUser)}
                disabled={createUser.isPending || !newUser.username || !newUser.password}
                className="bg-eco-green-500 text-white hover:bg-eco-green-600"
              >
                Create User
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit User Modal */}
      <Dialog open={showEditUserModal} onOpenChange={setShowEditUserModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
          </DialogHeader>
          {editingUser && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="editUsername">Username</Label>
                  <Input
                    id="editUsername"
                    value={editingUser.username}
                    onChange={(e) => setEditingUser(prev => ({ ...prev, username: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="editFirstName">First Name</Label>
                  <Input
                    id="editFirstName"
                    value={editingUser.firstName || ""}
                    onChange={(e) => setEditingUser(prev => ({ ...prev, firstName: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="editLastName">Last Name</Label>
                  <Input
                    id="editLastName"
                    value={editingUser.lastName || ""}
                    onChange={(e) => setEditingUser(prev => ({ ...prev, lastName: e.target.value }))}
                  />
                </div>

                <div>
                  <Label htmlFor="editPhone">Phone</Label>
                  <Input
                    id="editPhone"
                    value={editingUser.phone || ""}
                    onChange={(e) => setEditingUser(prev => ({ ...prev, phone: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="editRole">Role</Label>
                  <Select value={editingUser.role} onValueChange={(role: any) => setEditingUser(prev => ({ ...prev, role }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="customer">Customer</SelectItem>
                      <SelectItem value="driver">Driver</SelectItem>
                      <SelectItem value="dispatcher">Dispatcher</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowEditUserModal(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={() => updateUser.mutate({ userId: editingUser.id, userData: editingUser })}
                  disabled={updateUser.isPending}
                  className="bg-eco-green-500 text-white hover:bg-eco-green-600"
                >
                  Update User
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create Job Modal */}
      <Dialog open={showCreateJobModal} onOpenChange={setShowCreateJobModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Job</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="jobCustomer">Customer</Label>
              <Select value={newJob.customerId} onValueChange={(customerId) => setNewJob(prev => ({ ...prev, customerId }))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select customer" />
                </SelectTrigger>
                <SelectContent>
                  {usersByRole.customer.map((customer: any) => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.firstName} {customer.lastName} ({customer.username})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="jobServiceType">Service Type</Label>
                <Select value={newJob.serviceType} onValueChange={(serviceType: any) => setNewJob(prev => ({ ...prev, serviceType }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="residential">Residential</SelectItem>
                    <SelectItem value="commercial">Commercial</SelectItem>
                    <SelectItem value="one_time">One Time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="jobPriority">Priority</Label>
                <Select value={newJob.priority} onValueChange={(priority: any) => setNewJob(prev => ({ ...prev, priority }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Service Selection */}
            <div>
              <Label>Services</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 p-4 border rounded-lg">
                {allServices && allServices.length > 0 ? (
                  allServices.map((service: any) => (
                    <div key={service.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`service-${service.id}`}
                        checked={newJob.serviceIds.includes(service.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setNewJob(prev => ({ ...prev, serviceIds: [...prev.serviceIds, service.id] }));
                          } else {
                            setNewJob(prev => ({ ...prev, serviceIds: prev.serviceIds.filter(id => id !== service.id) }));
                          }
                        }}
                      />
                      <Label htmlFor={`service-${service.id}`} className="text-sm">
                        {service.name} - ${service.basePrice}
                      </Label>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-gray-500">No services available. Add services in Settings first.</p>
                )}
              </div>
            </div>
            <div>
              <Label htmlFor="jobAddress">Address</Label>
              <Textarea
                id="jobAddress"
                value={newJob.address}
                onChange={(e) => setNewJob(prev => ({ ...prev, address: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="jobScheduledDate">Scheduled Date</Label>
              <Input
                id="jobScheduledDate"
                type="datetime-local"
                value={newJob.scheduledDate}
                onChange={(e) => setNewJob(prev => ({ ...prev, scheduledDate: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="jobNotes">Notes</Label>
              <Textarea
                id="jobNotes"
                value={newJob.notes}
                onChange={(e) => setNewJob(prev => ({ ...prev, notes: e.target.value }))}
              />
            </div>

            {/* Create Invoice Option */}
            <div className="flex items-center space-x-2 p-4 border rounded-lg bg-blue-50">
              <Checkbox
                id="createInvoice"
                checked={newJob.createInvoice}
                onCheckedChange={(checked) => setNewJob(prev => ({ ...prev, createInvoice: !!checked }))}
              />
              <Label htmlFor="createInvoice" className="text-sm">
                Create detailed invoice for customer payment
              </Label>
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowCreateJobModal(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => createJob.mutate(newJob)}
                disabled={createJob.isPending || !newJob.customerId || !newJob.address}
                className="bg-eco-green-500 text-white hover:bg-eco-green-600"
              >
                Create Job
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* System Update Modal */}
      <Dialog open={showSystemUpdateModal} onOpenChange={setShowSystemUpdateModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <RefreshCw className="mr-2 h-5 w-5" />
              System Update
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="text-sm text-gray-600">
              <p>Use these options to update your system with new files, database schema changes, or configuration updates.</p>
            </div>

            {/* Update Options */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center">
                    <Database className="mr-2 h-5 w-5 text-blue-600" />
                    Database Update
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Apply database schema changes and run migrations
                  </p>
                  <Button 
                    onClick={() => handleSystemUpdate("database", "Database schema update")}
                    disabled={systemUpdate.isPending}
                    className="w-full"
                    variant="outline"
                  >
                    {systemUpdate.isPending ? (
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Database className="mr-2 h-4 w-4" />
                    )}
                    Update Database
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center">
                    <FileText className="mr-2 h-5 w-5 text-green-600" />
                    Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Refresh system configuration and environment settings
                  </p>
                  <Button 
                    onClick={() => handleSystemUpdate("config", "Configuration refresh")}
                    disabled={systemUpdate.isPending}
                    className="w-full"
                    variant="outline"
                  >
                    {systemUpdate.isPending ? (
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <FileText className="mr-2 h-4 w-4" />
                    )}
                    Refresh Config
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center">
                    <Upload className="mr-2 h-5 w-5 text-purple-600" />
                    File System
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Update application files and assets
                  </p>
                  <Button 
                    onClick={() => handleSystemUpdate("files", "File system update")}
                    disabled={systemUpdate.isPending}
                    className="w-full"
                    variant="outline"
                  >
                    {systemUpdate.isPending ? (
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Upload className="mr-2 h-4 w-4" />
                    )}
                    Update Files
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg flex items-center">
                    <RefreshCw className="mr-2 h-5 w-5 text-orange-600" />
                    Full Update
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    Complete system update (database, config, and files)
                  </p>
                  <Button 
                    onClick={() => handleSystemUpdate("full", "Complete system update")}
                    disabled={systemUpdate.isPending}
                    className="w-full bg-eco-green-500 text-white hover:bg-eco-green-600"
                  >
                    {systemUpdate.isPending ? (
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <RefreshCw className="mr-2 h-4 w-4" />
                    )}
                    Full Update
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Progress Log */}
            {updateProgress.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Update Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-50 rounded-lg p-4 max-h-40 overflow-y-auto">
                    <div className="space-y-1 font-mono text-sm">
                      {updateProgress.map((log, index) => (
                        <div key={index} className={log.startsWith('✓') ? 'text-green-600' : log.startsWith('✗') ? 'text-red-600' : 'text-gray-600'}>
                          {log}
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="flex justify-end space-x-2">
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowSystemUpdateModal(false);
                  setUpdateProgress([]);
                }}
              >
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Company Information Modal */}
      <Dialog open={showCompanyInfoModal} onOpenChange={setShowCompanyInfoModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Building className="mr-2 h-5 w-5" />
              Company Information
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="companyName">Company Name</Label>
                <Input
                  id="companyName"
                  value={systemSettings.companyName}
                  onChange={(e) => setSystemSettings(prev => ({ ...prev, companyName: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="phone">Phone</Label>
                <Input
                  id="phone"
                  value={systemSettings.phone}
                  onChange={(e) => setSystemSettings(prev => ({ ...prev, phone: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="address">Address</Label>
                <Input
                  id="address"
                  value={systemSettings.address}
                  onChange={(e) => setSystemSettings(prev => ({ ...prev, address: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="serviceRadius">Service Radius (miles)</Label>
                <Input
                  id="serviceRadius"
                  type="number"
                  value={systemSettings.serviceRadius}
                  onChange={(e) => setSystemSettings(prev => ({ ...prev, serviceRadius: e.target.value }))}
                />
              </div>
            </div>
            <div>
              <Label htmlFor="businessHours">Business Hours</Label>
              <Input
                id="businessHours"
                value={systemSettings.businessHours}
                onChange={(e) => setSystemSettings(prev => ({ ...prev, businessHours: e.target.value }))}
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowCompanyInfoModal(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  setShowCompanyInfoModal(false);
                  toast({
                    title: "Company Information Updated",
                    description: "Your company information has been saved successfully.",
                  });
                }}
                className="bg-eco-green-600 hover:bg-eco-green-700"
              >
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Pricing Modal */}
      <Dialog open={showPricingModal} onOpenChange={setShowPricingModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <DollarSign className="mr-2 h-5 w-5" />
              Default Pricing
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="residentialPrice">Residential Service ($)</Label>
                <Input
                  id="residentialPrice"
                  type="number"
                  step="0.01"
                  value={systemSettings.defaultPricing.residential}
                  onChange={(e) => setSystemSettings(prev => ({
                    ...prev,
                    defaultPricing: { ...prev.defaultPricing, residential: e.target.value }
                  }))}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Standard rate for residential bin cleaning
                </p>
              </div>
              <div>
                <Label htmlFor="commercialPrice">Commercial Service ($)</Label>
                <Input
                  id="commercialPrice"
                  type="number"
                  step="0.01"
                  value={systemSettings.defaultPricing.commercial}
                  onChange={(e) => setSystemSettings(prev => ({
                    ...prev,
                    defaultPricing: { ...prev.defaultPricing, commercial: e.target.value }
                  }))}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Rate for business and commercial clients
                </p>
              </div>
              <div>
                <Label htmlFor="oneTimePrice">One-Time Service ($)</Label>
                <Input
                  id="oneTimePrice"
                  type="number"
                  step="0.01"
                  value={systemSettings.defaultPricing.oneTime}
                  onChange={(e) => setSystemSettings(prev => ({
                    ...prev,
                    defaultPricing: { ...prev.defaultPricing, oneTime: e.target.value }
                  }))}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Rate for one-time cleaning services
                </p>
              </div>
            </div>
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>Note:</strong> These are default rates that can be customized for individual jobs. 
                Pricing will be automatically applied to new service requests.
              </p>
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowPricingModal(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  setShowPricingModal(false);
                  toast({
                    title: "Pricing Updated",
                    description: "Default pricing has been saved successfully.",
                  });
                }}
                className="bg-eco-green-600 hover:bg-eco-green-700"
              >
                <Save className="mr-2 h-4 w-4" />
                Save Pricing
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Email Notifications Modal */}
      <Dialog open={showEmailModal} onOpenChange={setShowEmailModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Bell className="mr-2 h-5 w-5" />
              Email Notification Settings
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <Label htmlFor="emailAlerts" className="text-base font-medium">Email Notifications</Label>
                  <p className="text-sm text-gray-600">Send email notifications for job updates and reminders</p>
                </div>
                <Switch
                  id="emailAlerts"
                  checked={systemSettings.notifications.emailAlerts}
                  onCheckedChange={(checked) => setSystemSettings(prev => ({
                    ...prev,
                    notifications: { ...prev.notifications, emailAlerts: checked }
                  }))}
                />
              </div>

              {/* Email Configuration */}
              <div className="space-y-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-medium text-blue-900">Email Configuration</h4>
                
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <Label htmlFor="sendgridKey">SendGrid API Key</Label>
                    <Input
                      id="sendgridKey"
                      type="password"
                      placeholder="SG...."
                      value={systemSettings.email?.sendgridKey || ''}
                      onChange={(e) => setSystemSettings(prev => ({
                        ...prev,
                        email: { ...prev.email, sendgridKey: e.target.value }
                      }))}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="fromEmail">From Email Address</Label>
                    <Input
                      id="fromEmail"
                      type="email"
                      placeholder="noreply@cfbincleaning.com"
                      value={systemSettings.email?.fromEmail || ''}
                      onChange={(e) => setSystemSettings(prev => ({
                        ...prev,
                        email: { ...prev.email, fromEmail: e.target.value }
                      }))}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="fromName">From Name</Label>
                    <Input
                      id="fromName"
                      placeholder="Central Florida Bin Cleaning"
                      value={systemSettings.email?.fromName || ''}
                      onChange={(e) => setSystemSettings(prev => ({
                        ...prev,
                        email: { ...prev.email, fromName: e.target.value }
                      }))}
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-sm text-amber-800">
                <strong>Note:</strong> Email notifications require a valid SendGrid API key.
              </p>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowEmailModal(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  // Save email configuration
                  const configs = [
                    { configKey: 'sendgrid_api_key', configValue: systemSettings.email?.sendgridKey || '' },
                    { configKey: 'email_from_address', configValue: systemSettings.email?.fromEmail || '' },
                    { configKey: 'email_from_name', configValue: systemSettings.email?.fromName || '' },
                    { configKey: 'notifications_email_enabled', configValue: systemSettings.notifications.emailAlerts.toString() },
                  ];
                  
                  configs.forEach(config => {
                    if (config.configValue) {
                      updateSystemConfig.mutate({ key: config.configKey, configValue: config.configValue });
                    }
                  });
                  
                  setShowEmailModal(false);
                  toast({
                    title: "Email Settings Updated",
                    description: "Email notification settings have been saved successfully.",
                  });
                }}
                disabled={updateSystemConfig.isPending}
                className="bg-eco-green-600 hover:bg-eco-green-700"
              >
                <Save className="mr-2 h-4 w-4" />
                {updateSystemConfig.isPending ? 'Saving...' : 'Save Email Settings'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* SMS Notifications Modal - Super Admin Only */}
      {user?.role === 'super_admin' && (
        <Dialog open={showSMSModal} onOpenChange={setShowSMSModal}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center">
                <MessageSquare className="mr-2 h-5 w-5" />
                SMS Notification Settings
                <Badge variant="secondary" className="ml-2 bg-red-100 text-red-800">Super Admin Only</Badge>
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <Label htmlFor="smsAlerts" className="text-base font-medium">SMS Notifications</Label>
                    <p className="text-sm text-gray-600">Send text message notifications to customers</p>
                  </div>
                  <Switch
                    id="smsAlerts"
                    checked={systemSettings.notifications.smsAlerts}
                    onCheckedChange={(checked) => setSystemSettings(prev => ({
                      ...prev,
                      notifications: { ...prev.notifications, smsAlerts: checked }
                    }))}
                  />
                </div>

                {/* SMS Configuration */}
                <div className="space-y-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <h4 className="font-medium text-green-900">Twilio SMS Configuration</h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="twilioSid">Twilio Account SID</Label>
                      <Input
                        id="twilioSid"
                        type="password"
                        placeholder="AC..."
                        value={systemSettings.sms?.twilioSid || ''}
                        onChange={(e) => setSystemSettings(prev => ({
                          ...prev,
                          sms: { ...prev.sms, twilioSid: e.target.value }
                        }))}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="twilioToken">Twilio Auth Token</Label>
                      <Input
                        id="twilioToken"
                        type="password"
                        placeholder="Auth Token"
                        value={systemSettings.sms?.twilioToken || ''}
                        onChange={(e) => setSystemSettings(prev => ({
                          ...prev,
                          sms: { ...prev.sms, twilioToken: e.target.value }
                        }))}
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <Label htmlFor="twilioPhone">Twilio Phone Number</Label>
                      <Input
                        id="twilioPhone"
                        placeholder="+1234567890"
                        value={systemSettings.sms?.twilioPhone || ''}
                        onChange={(e) => setSystemSettings(prev => ({
                          ...prev,
                          sms: { ...prev.sms, twilioPhone: e.target.value }
                        }))}
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <p className="text-sm text-amber-800">
                  <strong>Note:</strong> SMS notifications require valid Twilio credentials and may incur costs.
                  Only Super Admins can configure SMS settings.
                </p>
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowSMSModal(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={() => {
                    // Save SMS configuration
                    const configs = [
                      { configKey: 'twilio_account_sid', configValue: systemSettings.sms?.twilioSid || '' },
                      { configKey: 'twilio_auth_token', configValue: systemSettings.sms?.twilioToken || '' },
                      { configKey: 'twilio_phone_number', configValue: systemSettings.sms?.twilioPhone || '' },
                      { configKey: 'notifications_sms_enabled', configValue: systemSettings.notifications.smsAlerts.toString() },
                    ];
                    
                    configs.forEach(config => {
                      if (config.configValue) {
                        updateSystemConfig.mutate({ key: config.configKey, configValue: config.configValue });
                      }
                    });
                    
                    setShowSMSModal(false);
                    toast({
                      title: "SMS Settings Updated",
                      description: "SMS notification settings have been saved successfully.",
                    });
                  }}
                  disabled={updateSystemConfig.isPending}
                  className="bg-eco-green-600 hover:bg-eco-green-700"
                >
                  <Save className="mr-2 h-4 w-4" />
                  {updateSystemConfig.isPending ? 'Saving...' : 'Save SMS Settings'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Automatic Reminders Modal */}
      <Dialog open={showRemindersModal} onOpenChange={setShowRemindersModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Clock className="mr-2 h-5 w-5" />
              Automatic Reminder Settings
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <Label htmlFor="jobReminders" className="text-base font-medium">Automatic Job Reminders</Label>
                  <p className="text-sm text-gray-600">Send automatic reminders for scheduled services</p>
                </div>
                <Switch
                  id="jobReminders"
                  checked={systemSettings.notifications.jobReminders}
                  onCheckedChange={(checked) => setSystemSettings(prev => ({
                    ...prev,
                    notifications: { ...prev.notifications, jobReminders: checked }
                  }))}
                />
              </div>

              {/* Reminder Configuration */}
              <div className="space-y-4 p-4 bg-orange-50 border border-orange-200 rounded-lg">
                <h4 className="font-medium text-orange-900">Reminder Configuration</h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="reminderDaysBefore">Days Before Service</Label>
                    <Input
                      id="reminderDaysBefore"
                      type="number"
                      placeholder="1"
                      value={systemSettings.reminders?.daysBefore || '1'}
                      onChange={(e) => setSystemSettings(prev => ({
                        ...prev,
                        reminders: { ...prev.reminders, daysBefore: e.target.value }
                      }))}
                    />
                    <p className="text-xs text-gray-600 mt-1">How many days before service to send reminder</p>
                  </div>
                  
                  <div>
                    <Label htmlFor="reminderTime">Reminder Time</Label>
                    <Input
                      id="reminderTime"
                      type="time"
                      value={systemSettings.reminders?.timeOfDay || '09:00'}
                      onChange={(e) => setSystemSettings(prev => ({
                        ...prev,
                        reminders: { ...prev.reminders, timeOfDay: e.target.value }
                      }))}
                    />
                    <p className="text-xs text-gray-600 mt-1">What time of day to send reminders</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-sm text-amber-800">
                <strong>Note:</strong> Automatic reminders will use the configured email and SMS settings.
                Ensure those are properly configured first.
              </p>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowRemindersModal(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  // Save reminder configuration
                  const configs = [
                    { configKey: 'notifications_job_reminders', configValue: systemSettings.notifications.jobReminders.toString() },
                    { configKey: 'reminder_days_before', configValue: systemSettings.reminders?.daysBefore || '1' },
                    { configKey: 'reminder_time_of_day', configValue: systemSettings.reminders?.timeOfDay || '09:00' },
                  ];
                  
                  configs.forEach(config => {
                    if (config.configValue) {
                      updateSystemConfig.mutate({ key: config.configKey, configValue: config.configValue });
                    }
                  });
                  
                  setShowRemindersModal(false);
                  toast({
                    title: "Reminder Settings Updated",
                    description: "Automatic reminder settings have been saved successfully.",
                  });
                }}
                disabled={updateSystemConfig.isPending}
                className="bg-eco-green-600 hover:bg-eco-green-700"
              >
                <Save className="mr-2 h-4 w-4" />
                {updateSystemConfig.isPending ? 'Saving...' : 'Save Reminder Settings'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Stripe Configuration Help Modal */}
      <Dialog open={showStripeConfigModal} onOpenChange={setShowStripeConfigModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <CreditCard className="mr-2 h-5 w-5" />
              How to Get Stripe API Keys
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-800">
                Follow these steps to obtain your Stripe API keys for payment processing.
              </p>
            </div>
            
            <div className="space-y-6">
              <div>
                <h3 className="font-semibold text-lg mb-3">Step 1: Access Your Stripe Dashboard</h3>
                <ol className="list-decimal list-inside space-y-2 text-sm">
                  <li>Go to <a href="https://dashboard.stripe.com/apikeys" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">https://dashboard.stripe.com/apikeys</a></li>
                  <li>Log in to your Stripe account (create one if you don't have it)</li>
                  <li>Navigate to the "Developers" section in the left sidebar</li>
                  <li>Click on "API keys"</li>
                </ol>
              </div>
              
              <div>
                <h3 className="font-semibold text-lg mb-3">Step 2: Copy Your API Keys</h3>
                <div className="space-y-3">
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <h4 className="font-medium text-green-700">Publishable Key (VITE_STRIPE_PUBLIC_KEY)</h4>
                    <p className="text-sm text-gray-600">
                      Copy your "Publishable key" (starts with <code className="bg-gray-200 px-1 rounded">pk_</code>). 
                      This key is safe to be public and is used in your frontend.
                    </p>
                  </div>
                  
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <h4 className="font-medium text-red-700">Secret Key (STRIPE_SECRET_KEY)</h4>
                    <p className="text-sm text-gray-600">
                      Copy your "Secret key" (starts with <code className="bg-gray-200 px-1 rounded">sk_</code>). 
                      This key must be kept secret and is used on your backend server.
                    </p>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="font-semibold text-lg mb-3">Step 3: Test vs Live Mode</h3>
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-sm text-amber-800">
                    <strong>Test Mode:</strong> Use test keys (pk_test_ and sk_test_) for development and testing.
                    <br />
                    <strong>Live Mode:</strong> Use live keys (pk_live_ and sk_live_) for production payments.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button 
                variant="outline" 
                onClick={() => setShowStripeConfigModal(false)}
              >
                Close
              </Button>
              <Button 
                onClick={() => window.open('https://dashboard.stripe.com/apikeys', '_blank')}
                className="bg-eco-green-600 hover:bg-eco-green-700"
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                Open Stripe Dashboard
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Job Modal */}
      <Dialog open={showEditJobModal} onOpenChange={setShowEditJobModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Job</DialogTitle>
          </DialogHeader>
          {editingJob && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="editJobCustomer">Customer</Label>
                <Select 
                  value={editingJob.customerId} 
                  onValueChange={(customerId) => setEditingJob((prev: any) => ({ ...prev, customerId }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select customer" />
                  </SelectTrigger>
                  <SelectContent>
                    {usersByRole.customer.map((customer: any) => (
                      <SelectItem key={customer.id} value={customer.id}>
                        {customer.firstName} {customer.lastName} ({customer.username})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="editJobServiceType">Service Type</Label>
                  <Select 
                    value={editingJob.serviceType} 
                    onValueChange={(serviceType: any) => setEditingJob((prev: any) => ({ ...prev, serviceType }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="residential">Residential</SelectItem>
                      <SelectItem value="commercial">Commercial</SelectItem>
                      <SelectItem value="one-time">One-time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="editJobPriority">Priority</Label>
                  <Select 
                    value={editingJob.priority} 
                    onValueChange={(priority: any) => setEditingJob((prev: any) => ({ ...prev, priority }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="editJobAddress">Address</Label>
                <Input
                  id="editJobAddress"
                  value={editingJob.address}
                  onChange={(e) => setEditingJob((prev: any) => ({ ...prev, address: e.target.value }))}
                  placeholder="Service address"
                />
              </div>

              <div>
                <Label htmlFor="editJobScheduledDate">Scheduled Date</Label>
                <Input
                  id="editJobScheduledDate"
                  type="datetime-local"
                  value={editingJob.scheduledDate ? new Date(editingJob.scheduledDate).toISOString().slice(0, 16) : ''}
                  onChange={(e) => setEditingJob((prev: any) => ({ ...prev, scheduledDate: e.target.value }))}
                />
              </div>

              <div>
                <Label htmlFor="editJobNotes">Notes</Label>
                <Textarea
                  id="editJobNotes"
                  value={editingJob.notes || ''}
                  onChange={(e) => setEditingJob((prev: any) => ({ ...prev, notes: e.target.value }))}
                  placeholder="Additional notes or instructions"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="editJobStatus">Status</Label>
                <Select 
                  value={editingJob.status} 
                  onValueChange={(status: any) => setEditingJob((prev: any) => ({ ...prev, status }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="assigned">Assigned</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {editingJob.status !== 'pending' && (
                <div>
                  <Label htmlFor="editJobDriver">Driver</Label>
                  <Select 
                    value={editingJob.driverId || 'unassigned'} 
                    onValueChange={(driverId) => setEditingJob((prev: any) => ({ ...prev, driverId: driverId === 'unassigned' ? null : driverId }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select driver" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unassigned">Unassigned</SelectItem>
                      {usersByRole.driver.map((driver: any) => (
                        <SelectItem key={driver.id} value={driver.id}>
                          {driver.firstName} {driver.lastName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowEditJobModal(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={() => editJob.mutate(editingJob)}
                  disabled={editJob.isPending || !editingJob.customerId || !editingJob.address}
                  className="bg-eco-green-500 text-white hover:bg-eco-green-600"
                >
                  Update Job
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create Route Modal */}
      <Dialog open={showCreateRouteModal} onOpenChange={setShowCreateRouteModal}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Create Route from Selected Jobs</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="routeName">Route Name</Label>
                <Input
                  id="routeName"
                  value={newRoute.name}
                  onChange={(e) => setNewRoute(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter route name"
                />
              </div>
              <div>
                <Label htmlFor="routeDriver">Assign Driver</Label>
                <Select 
                  value={newRoute.driverId} 
                  onValueChange={(driverId) => setNewRoute(prev => ({ ...prev, driverId }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select driver" />
                  </SelectTrigger>
                  <SelectContent>
                    {usersByRole.driver.map((driver: any) => (
                      <SelectItem key={driver.id} value={driver.id}>
                        {driver.firstName} {driver.lastName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="routeDescription">Description</Label>
              <Textarea
                id="routeDescription"
                value={newRoute.description}
                onChange={(e) => setNewRoute(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Optional route description"
                rows={3}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="optimizeRoute"
                checked={newRoute.optimized}
                onCheckedChange={(checked) => setNewRoute(prev => ({ ...prev, optimized: !!checked }))}
              />
              <Label htmlFor="optimizeRoute" className="text-sm">
                Optimize route for shortest distance/time
              </Label>
            </div>

            {/* Selected Jobs Preview */}
            <div>
              <Label className="text-sm font-medium">Selected Jobs ({selectedJobs.length})</Label>
              <div className="mt-2 max-h-48 overflow-y-auto border rounded-lg">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="text-left py-2 px-3 font-medium">Job ID</th>
                      <th className="text-left py-2 px-3 font-medium">Customer</th>
                      <th className="text-left py-2 px-3 font-medium">Address</th>
                      <th className="text-left py-2 px-3 font-medium">Service Type</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedJobs.map(jobId => {
                      const job = allJobs?.find((j: any) => j.id === jobId);
                      if (!job) return null;
                      return (
                        <tr key={job.id} className="border-t">
                          <td className="py-2 px-3 font-mono text-xs">{job.id.slice(0, 8)}...</td>
                          <td className="py-2 px-3">{job.customer?.firstName} {job.customer?.lastName}</td>
                          <td className="py-2 px-3 max-w-40 truncate">{job.address}</td>
                          <td className="py-2 px-3 capitalize">{job.serviceType}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowCreateRouteModal(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => createRoute.mutate({
                  routeName: newRoute.name,
                  description: newRoute.description,
                  driverId: newRoute.driverId,
                  scheduledDate: new Date().toISOString().split('T')[0], // Today's date
                  status: 'planned',
                  startLocation: "Central Florida Bin Cleaning HQ, Orlando, FL",
                  endLocation: "Central Florida Bin Cleaning HQ, Orlando, FL",
                  jobIds: selectedJobs
                })}
                disabled={createRoute.isPending || !newRoute.name || !newRoute.driverId || selectedJobs.length === 0}
                className="bg-eco-green-500 text-white hover:bg-eco-green-600"
              >
                Create Route
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
