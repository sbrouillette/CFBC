import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/logo";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { ClipboardList, Truck, Users, Plus, UserCheck, AlertCircle } from "lucide-react";

export default function DispatcherPortal() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [selectedDriver, setSelectedDriver] = useState<string>("");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  // Fetch unassigned jobs
  const { data: unassignedJobs, isLoading: unassignedJobsLoading } = useQuery({
    queryKey: ["/api/jobs"],
    enabled: isAuthenticated,
  });

  // Fetch drivers
  const { data: drivers, isLoading: driversLoading } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/users");
      return response;
    },
    enabled: isAuthenticated,
  });

  // Fetch all jobs for status overview
  const { data: allJobs } = useQuery({
    queryKey: ["/api/jobs", "all"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/jobs");
      return response;
    },
    enabled: isAuthenticated,
  });

  // Assign job mutation
  const assignJob = useMutation({
    mutationFn: async ({ jobId, driverId }: { jobId: string; driverId: string }) => {
      await apiRequest("PATCH", `/api/jobs/${jobId}/assign`, { driverId });
    },
    onSuccess: () => {
      toast({
        title: "Job Assigned",
        description: "Job has been assigned to driver successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      setSelectedDriver("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to assign job. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAssignJob = (jobId: string) => {
    if (!selectedDriver) {
      toast({
        title: "No Driver Selected",
        description: "Please select a driver before assigning the job.",
        variant: "destructive",
      });
      return;
    }
    assignJob.mutate({ jobId, driverId: selectedDriver });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-eco-green-500"></div>
      </div>
    );
  }

  if (!isAuthenticated || (user?.role !== 'dispatcher' && user?.role !== 'admin' && user?.role !== 'super_admin')) {
    return null;
  }

  const activeDrivers = (drivers && Array.isArray(drivers)) ? drivers.filter((driver: any) => driver.isActive && driver.role === 'driver') : [];
  const jobsByStatus = {
    pending: (unassignedJobs && Array.isArray(unassignedJobs)) ? unassignedJobs.filter((job: any) => job.status === 'pending') : [],
    assigned: (allJobs && Array.isArray(allJobs)) ? allJobs.filter((job: any) => job.status === 'assigned') : [],
    inProgress: (allJobs && Array.isArray(allJobs)) ? allJobs.filter((job: any) => job.status === 'in_progress') : [],
    completed: (allJobs && Array.isArray(allJobs)) ? allJobs.filter((job: any) => job.status === 'completed') : [],
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Logo />
              <h1 className="text-xl font-bold text-gray-900">Dispatcher Portal</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-gray-600">Welcome, {user?.firstName}</span>
              <Button onClick={handleLogout} variant="outline" size="sm">
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Driver Status */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="h-5 w-5 mr-2" />
                  Driver Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                {driversLoading ? (
                  <div className="text-center py-4">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-eco-green-500 mx-auto"></div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {activeDrivers.length > 0 ? (
                      activeDrivers.map((driver: any) => {
                        const driverJobs = (allJobs && Array.isArray(allJobs)) ? allJobs.filter((job: any) => job.driverId === driver.id) : [];
                        const activeJobs = driverJobs.filter((job: any) => job.status === 'in_progress');
                        const completedToday = driverJobs.filter((job: any) => 
                          job.status === 'completed' && 
                          new Date(job.completedAt).toDateString() === new Date().toDateString()
                        );
                        
                        return (
                          <div key={driver.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                            <div className="flex items-center space-x-3">
                              <div className="w-8 h-8 bg-eco-green-100 rounded-full flex items-center justify-center">
                                <Truck className="h-4 w-4 text-eco-green-600" />
                              </div>
                              <div>
                                <p className="font-medium text-gray-900">{driver.firstName} {driver.lastName}</p>
                                <p className="text-sm text-gray-600">
                                  {completedToday.length} completed, {activeJobs.length} active
                                </p>
                              </div>
                            </div>
                            <Badge 
                              variant="secondary"
                              className={
                                activeJobs.length > 0 
                                  ? 'bg-green-100 text-green-800'
                                  : 'bg-gray-100 text-gray-800'
                              }
                            >
                              {activeJobs.length > 0 ? 'Active' : 'Available'}
                            </Badge>
                          </div>
                        );
                      })
                    ) : (
                      <div className="text-center py-4 text-gray-500">
                        No active drivers found
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Job Overview */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Job Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-yellow-50 rounded-lg">
                    <div className="text-2xl font-bold text-yellow-600">{jobsByStatus.pending.length}</div>
                    <div className="text-sm text-gray-600">Pending</div>
                  </div>
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{jobsByStatus.assigned.length}</div>
                    <div className="text-sm text-gray-600">Assigned</div>
                  </div>
                  <div className="text-center p-3 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{jobsByStatus.inProgress.length}</div>
                    <div className="text-sm text-gray-600">In Progress</div>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{jobsByStatus.completed.length}</div>
                    <div className="text-sm text-gray-600">Completed</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Pending Job Assignments */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="flex items-center">
                    <ClipboardList className="h-5 w-5 mr-2" />
                    Pending Job Assignments
                  </CardTitle>
                  <Button size="sm" className="bg-eco-green-500 text-white hover:bg-eco-green-600">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Job
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {unassignedJobsLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-eco-green-500 mx-auto"></div>
                  </div>
                ) : (
                  <>
                    {/* Driver Selection */}
                    <div className="mb-6 p-4 bg-eco-green-50 rounded-lg">
                      <Label className="text-sm font-medium text-gray-700 mb-2 block">
                        Select Driver for Assignment:
                      </Label>
                      <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Choose a driver..." />
                        </SelectTrigger>
                        <SelectContent>
                          {activeDrivers.map((driver: any) => (
                            <SelectItem key={driver.id} value={driver.id}>
                              {driver.firstName} {driver.lastName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Jobs Table */}
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-gray-200">
                            <th className="text-left py-3 text-sm font-medium text-gray-700">Customer</th>
                            <th className="text-left py-3 text-sm font-medium text-gray-700">Address</th>
                            <th className="text-left py-3 text-sm font-medium text-gray-700">Service Type</th>
                            <th className="text-left py-3 text-sm font-medium text-gray-700">Priority</th>
                            <th className="text-left py-3 text-sm font-medium text-gray-700">Created</th>
                            <th className="text-left py-3 text-sm font-medium text-gray-700">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {jobsByStatus.pending.length > 0 ? (
                            jobsByStatus.pending.map((job: any) => (
                              <tr key={job.id} className="border-b border-gray-100">
                                <td className="py-3 text-sm text-gray-900">
                                  Customer #{job.customerId.slice(-8)}
                                </td>
                                <td className="py-3 text-sm text-gray-600">{job.address}</td>
                                <td className="py-3 text-sm text-gray-600 capitalize">{job.serviceType}</td>
                                <td className="py-3">
                                  <Badge 
                                    variant="secondary"
                                    className={
                                      job.priority === 'high' || job.priority === 'urgent'
                                        ? 'bg-red-100 text-red-800'
                                        : job.priority === 'normal'
                                        ? 'bg-yellow-100 text-yellow-800'
                                        : 'bg-gray-100 text-gray-800'
                                    }
                                  >
                                    {job.priority}
                                  </Badge>
                                </td>
                                <td className="py-3 text-sm text-gray-600">
                                  {new Date(job.createdAt).toLocaleDateString()}
                                </td>
                                <td className="py-3">
                                  <Button 
                                    size="sm"
                                    onClick={() => handleAssignJob(job.id)}
                                    disabled={assignJob.isPending || !selectedDriver}
                                    className="bg-eco-green-500 text-white hover:bg-eco-green-600"
                                  >
                                    <UserCheck className="h-4 w-4 mr-1" />
                                    {assignJob.isPending ? "Assigning..." : "Assign"}
                                  </Button>
                                </td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan={6} className="py-8 text-center text-gray-500">
                                No pending jobs to assign
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
