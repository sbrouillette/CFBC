import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Logo } from "@/components/logo";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Truck, Play, Pause, Square, CheckCircle, Clock, MapPin, Route as RouteIcon, AlertTriangle } from "lucide-react";
import RouteManagement from "@/components/RouteManagement";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function DriverPortal() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [showLogHoursModal, setShowLogHoursModal] = useState(false);
  const [showReportIssueModal, setShowReportIssueModal] = useState(false);
  const [hoursData, setHoursData] = useState({
    hours: "",
    description: "",
    date: new Date().toISOString().split('T')[0]
  });
  const [issueData, setIssueData] = useState({
    title: "",
    description: "",
    priority: "normal"
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  // Fetch driver's assigned jobs
  const { data: jobs, isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/jobs"],
    enabled: isAuthenticated,
  });

  // Filter jobs for the current driver
  const driverJobs = jobs?.filter((job: any) => 
    job.driverId === user?.id || 
    (user?.role !== 'driver' && (job.status === 'assigned' || job.status === 'in_progress' || job.status === 'completed'))
  ) || [];

  // Update job status mutation
  const updateJobStatus = useMutation({
    mutationFn: async ({ jobId, status }: { jobId: string; status: string }) => {
      await apiRequest("PATCH", `/api/jobs/${jobId}/status`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Status Updated",
        description: "Job status has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update job status. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleMarkComplete = (jobId: string) => {
    updateJobStatus.mutate({ jobId, status: "completed" });
  };

  const handleStartJob = (jobId: string) => {
    updateJobStatus.mutate({ jobId, status: "in_progress" });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-eco-green-500"></div>
      </div>
    );
  }

  if (!isAuthenticated || (user?.role !== 'driver' && user?.role !== 'admin' && user?.role !== 'super_admin')) {
    return null;
  }

  const completedJobs = driverJobs.filter((job: any) => job.status === 'completed');
  const pendingJobs = driverJobs.filter((job: any) => job.status === 'assigned' || job.status === 'in_progress');
  const assignedJobs = driverJobs.filter((job: any) => job.status === 'assigned');
  const inProgressJobs = driverJobs.filter((job: any) => job.status === 'in_progress');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Logo />
              <h1 className="text-xl font-bold text-gray-900">
                {user?.role === 'driver' ? 'Driver Portal' : `${user?.role} Portal - Driver View`}
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-gray-600">Welcome, {user?.firstName}</span>
              <Button onClick={handleLogout} variant="outline" size="sm">
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="jobs" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="jobs" className="flex items-center">
              <Truck className="h-4 w-4 mr-2" />
              Jobs
            </TabsTrigger>
            <TabsTrigger value="routes" className="flex items-center">
              <RouteIcon className="h-4 w-4 mr-2" />
              Routes
            </TabsTrigger>
          </TabsList>

          {/* Jobs Tab */}
          <TabsContent value="jobs">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Today's Route */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Truck className="h-5 w-5 mr-2" />
                  Today's Route
                </CardTitle>
              </CardHeader>
              <CardContent>
                {jobsLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-eco-green-500 mx-auto"></div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingJobs.length > 0 || completedJobs.length > 0 ? (
                      [...pendingJobs, ...completedJobs]
                        .sort((a: any, b: any) => new Date(a.scheduledDate || a.createdAt).getTime() - new Date(b.scheduledDate || b.createdAt).getTime())
                        .map((job: any) => (
                        <div key={job.id} className="border border-gray-200 rounded-lg p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div className="flex-1">
                              <h4 className="font-medium text-gray-900">{job.address}</h4>
                              <p className="text-sm text-gray-600">
                                Service: {job.serviceType.charAt(0).toUpperCase() + job.serviceType.slice(1)}
                              </p>
                              {job.scheduledDate && (
                                <p className="text-sm text-gray-600">
                                  Scheduled: {new Date(job.scheduledDate).toLocaleString()}
                                </p>
                              )}
                              {job.notes && (
                                <p className="text-sm text-gray-600 mt-1">Notes: {job.notes}</p>
                              )}
                            </div>
                            <Badge 
                              variant="secondary"
                              className={
                                job.status === 'completed' 
                                  ? 'bg-green-100 text-green-800'
                                  : job.status === 'in_progress'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-yellow-100 text-yellow-800'
                              }
                            >
                              {job.status === 'in_progress' ? 'In Progress' : job.status}
                            </Badge>
                          </div>
                          
                          <div className="flex gap-2 mt-3">
                            {job.status === 'assigned' && (
                              <Button 
                                size="sm"
                                onClick={() => handleStartJob(job.id)}
                                disabled={updateJobStatus.isPending}
                                className="bg-blue-500 text-white hover:bg-blue-600"
                              >
                                <Play className="h-4 w-4 mr-1" />
                                Start
                              </Button>
                            )}
                            {job.status === 'in_progress' && (
                              <Button 
                                size="sm"
                                onClick={() => handleMarkComplete(job.id)}
                                disabled={updateJobStatus.isPending}
                                className="bg-eco-green-500 text-white hover:bg-eco-green-600"
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Complete
                              </Button>
                            )}
                            {job.status === 'completed' && job.completedAt && (
                              <p className="text-sm text-green-600 flex items-center">
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Completed at {new Date(job.completedAt).toLocaleTimeString()}
                              </p>
                            )}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        No jobs assigned for today
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          {/* Status Updates & Summary */}
          <div className="space-y-6">
            {/* Route Controls */}
            <Card>
              <CardHeader>
                <CardTitle>Route Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  className="w-full bg-eco-green-500 text-white hover:bg-eco-green-600"
                  disabled={inProgressJobs.length === 0}
                >
                  <Play className="mr-2 h-4 w-4" />
                  {inProgressJobs.length > 0 ? "Resume Route" : "Start Route"}
                </Button>
                <Button variant="outline" className="w-full">
                  <Pause className="mr-2 h-4 w-4" />
                  Take Break
                </Button>
                <Button variant="outline" className="w-full">
                  <Square className="mr-2 h-4 w-4" />
                  End Route
                </Button>
              </CardContent>
            </Card>

            {/* Today's Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Today's Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-eco-green-600 mb-1">
                      {completedJobs.length}
                    </div>
                    <div className="text-sm text-gray-600">Completed</div>
                  </div>
                  <div className="text-center p-4 bg-yellow-50 rounded-lg">
                    <div className="text-2xl font-bold text-yellow-600 mb-1">
                      {pendingJobs.length}
                    </div>
                    <div className="text-sm text-gray-600">Remaining</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600 mb-1">
                      {inProgressJobs.length}
                    </div>
                    <div className="text-sm text-gray-600">In Progress</div>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-2xl font-bold text-gray-600 mb-1">
                      {Math.round((completedJobs.length / Math.max(completedJobs.length + pendingJobs.length, 1)) * 100)}%
                    </div>
                    <div className="text-sm text-gray-600">Progress</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => {
                    // Switch to routes tab to view map
                    const routesTab = document.querySelector('[data-state="inactive"][value="routes"]') as HTMLElement;
                    if (routesTab) routesTab.click();
                  }}
                >
                  <MapPin className="mr-2 h-4 w-4" />
                  View Route Map
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => setShowLogHoursModal(true)}
                >
                  <Clock className="mr-2 h-4 w-4" />
                  Log Hours
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => setShowReportIssueModal(true)}
                >
                  <AlertTriangle className="mr-2 h-4 w-4" />
                  Report Issue
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </TabsContent>

      {/* Routes Tab */}
      <TabsContent value="routes">
            <RouteManagement 
              userRole={user?.role || 'driver'} 
              currentUserId={user?.id || ''} 
              hideCreateButton={user?.role === 'driver'}
            />
          </TabsContent>
        </Tabs>
      </div>

      {/* Log Hours Modal */}
      <Dialog open={showLogHoursModal} onOpenChange={setShowLogHoursModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Log Work Hours</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={hoursData.date}
                onChange={(e) => setHoursData(prev => ({ ...prev, date: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="hours">Hours Worked</Label>
              <Input
                id="hours"
                type="number"
                step="0.5"
                placeholder="8.0"
                value={hoursData.hours}
                onChange={(e) => setHoursData(prev => ({ ...prev, hours: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Describe your work activities..."
                value={hoursData.description}
                onChange={(e) => setHoursData(prev => ({ ...prev, description: e.target.value }))}
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowLogHoursModal(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  toast({
                    title: "Hours Logged",
                    description: `${hoursData.hours} hours logged for ${hoursData.date}`,
                  });
                  setShowLogHoursModal(false);
                  setHoursData({ hours: "", description: "", date: new Date().toISOString().split('T')[0] });
                }}
                disabled={!hoursData.hours || !hoursData.date}
                className="bg-eco-green-500 text-white hover:bg-eco-green-600"
              >
                Log Hours
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Report Issue Modal */}
      <Dialog open={showReportIssueModal} onOpenChange={setShowReportIssueModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Report an Issue</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="title">Issue Title</Label>
              <Input
                id="title"
                placeholder="Brief description of the issue"
                value={issueData.title}
                onChange={(e) => setIssueData(prev => ({ ...prev, title: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="priority">Priority</Label>
              <select
                id="priority"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                value={issueData.priority}
                onChange={(e) => setIssueData(prev => ({ ...prev, priority: e.target.value }))}
              >
                <option value="low">Low</option>
                <option value="normal">Normal</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
            <div>
              <Label htmlFor="issueDescription">Description</Label>
              <Textarea
                id="issueDescription"
                placeholder="Provide detailed information about the issue..."
                value={issueData.description}
                onChange={(e) => setIssueData(prev => ({ ...prev, description: e.target.value }))}
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowReportIssueModal(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => {
                  toast({
                    title: "Issue Reported",
                    description: "Your issue has been submitted to the support team.",
                  });
                  setShowReportIssueModal(false);
                  setIssueData({ title: "", description: "", priority: "normal" });
                }}
                disabled={!issueData.title || !issueData.description}
                className="bg-eco-green-500 text-white hover:bg-eco-green-600"
              >
                Submit Issue
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
