import { Navigation } from "@/components/navigation";
import { Footer } from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Calendar, Play, Home, Building, CalendarDays, Check } from "lucide-react";
import truckImage from "@assets/CF-Truck2_1753726085461.jpg";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-eco py-20">
        <div className="absolute inset-0 bg-cover bg-center opacity-10" 
             style={{backgroundImage: "url('https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"}}></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-6">
                Professional <span className="text-eco-green-600">Bin Cleaning</span> Services
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Keep your trash bins clean, sanitized, and odor-free with our eco-friendly cleaning services. 
                Serving residential and commercial properties across Central Florida.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/contact">
                  <Button className="bg-eco-green-500 text-white hover:bg-eco-green-600 px-8 py-4 text-lg h-auto">
                    <Calendar className="mr-2 h-5 w-5" />
                    Schedule Service
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  className="border-2 border-eco-green-500 text-eco-green-600 hover:bg-eco-green-50 px-8 py-4 text-lg h-auto"
                  onClick={() => {
                    window.open('https://www.youtube.com/watch?v=AN86OOIoOTM', '_blank', 'width=800,height=600,scrollbars=yes,resizable=yes');
                  }}
                >
                  <Play className="mr-2 h-5 w-5" />
                  Watch How It Works
                </Button>
              </div>
            </div>
            <div className="relative">
              <img 
                src={truckImage} 
                alt="Central Florida Bin Cleaning Service Truck" 
                className="rounded-2xl shadow-2xl w-full h-[400px] object-cover"
              />
              {/* Trust badges */}
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-xl shadow-lg">
                <div className="text-center">
                  <p className="text-2xl font-bold text-eco-green-600">500+</p>
                  <p className="text-sm text-gray-600">Happy Customers</p>
                </div>
              </div>
              <div className="absolute -top-6 -right-6 bg-white p-4 rounded-xl shadow-lg">
                <div className="text-center">
                  <p className="text-2xl font-bold text-eco-green-600">100%</p>
                  <p className="text-sm text-gray-600">Eco-Friendly</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Cleaning Services</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional, eco-friendly bin cleaning solutions for residential and commercial properties
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Residential Service */}
            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mb-6">
                  <Home className="h-8 w-8 text-eco-green-600" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">Residential Cleaning</h3>
                <p className="text-gray-600 mb-6">
                  Regular cleaning and sanitization of your home trash bins. Keep your property clean and odor-free.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center text-gray-600">
                    <Check className="h-4 w-4 text-eco-green-500 mr-3" />
                    Weekly or monthly service
                  </li>
                  <li className="flex items-center text-gray-600">
                    <Check className="h-4 w-4 text-eco-green-500 mr-3" />
                    Eco-friendly cleaning products
                  </li>
                  <li className="flex items-center text-gray-600">
                    <Check className="h-4 w-4 text-eco-green-500 mr-3" />
                    Deodorization included
                  </li>
                </ul>
                <Button className="w-full bg-eco-green-500 text-white hover:bg-eco-green-600">
                  Get Quote
                </Button>
              </CardContent>
            </Card>

            {/* Commercial Service */}
            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mb-6">
                  <Building className="h-8 w-8 text-eco-green-600" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">Commercial Cleaning</h3>
                <p className="text-gray-600 mb-6">
                  Professional cleaning services for businesses, restaurants, and commercial properties.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center text-gray-600">
                    <Check className="h-4 w-4 text-eco-green-500 mr-3" />
                    Flexible scheduling
                  </li>
                  <li className="flex items-center text-gray-600">
                    <Check className="h-4 w-4 text-eco-green-500 mr-3" />
                    Multiple bin sizes
                  </li>
                  <li className="flex items-center text-gray-600">
                    <Check className="h-4 w-4 text-eco-green-500 mr-3" />
                    Volume discounts available
                  </li>
                </ul>
                <Button className="w-full bg-eco-green-500 text-white hover:bg-eco-green-600">
                  Get Quote
                </Button>
              </CardContent>
            </Card>

            {/* One-Time Service */}
            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-eco-green-100 rounded-full flex items-center justify-center mb-6">
                  <CalendarDays className="h-8 w-8 text-eco-green-600" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">One-Time Cleaning</h3>
                <p className="text-gray-600 mb-6">
                  Deep cleaning service for bins that haven't been maintained or special cleaning needs.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-center text-gray-600">
                    <Check className="h-4 w-4 text-eco-green-500 mr-3" />
                    Deep sanitization
                  </li>
                  <li className="flex items-center text-gray-600">
                    <Check className="h-4 w-4 text-eco-green-500 mr-3" />
                    Same-day service available
                  </li>
                  <li className="flex items-center text-gray-600">
                    <Check className="h-4 w-4 text-eco-green-500 mr-3" />
                    No commitment required
                  </li>
                </ul>
                <Button className="w-full bg-eco-green-500 text-white hover:bg-eco-green-600">
                  Book Now
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600">Simple, efficient, and eco-friendly cleaning process</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              {
                step: "1",
                title: "Schedule Service",
                description: "Book your cleaning service online or call us directly. Choose your preferred schedule."
              },
              {
                step: "2",
                title: "We Arrive",
                description: "Our professional team arrives with specialized equipment and eco-friendly cleaning solutions."
              },
              {
                step: "3",
                title: "Deep Clean",
                description: "We thoroughly clean, sanitize, and deodorize your bins using high-pressure washing."
              },
              {
                step: "4",
                title: "Fresh & Clean",
                description: "Your bins are returned clean, sanitized, and fresh-smelling. Ready for use!"
              }
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-20 h-20 bg-eco-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-2xl font-bold text-white">{item.step}</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
