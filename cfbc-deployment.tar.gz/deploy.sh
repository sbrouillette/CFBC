#!/bin/bash

# Central Florida Bin Cleaning - Automated Ubuntu VPS Deployment Script
# This script automates the complete deployment process

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[WARNING] $1${NC}"
}

error() {
    echo -e "${RED}[ERROR] $1${NC}"
    exit 1
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
    error "This script should not be run as root. Run as a regular user with sudo privileges."
fi

# Check Ubuntu version
if ! lsb_release -d | grep -q "Ubuntu"; then
    error "This script is designed for Ubuntu. Please run on Ubuntu 20.04 or 22.04."
fi

log "Starting Central Florida Bin Cleaning deployment..."

# Get configuration from user
echo
echo "=== Configuration Setup ==="
read -p "Enter your domain name (or press Enter to use IP address): " DOMAIN_NAME
read -p "Enter database password (or press Enter for auto-generated): " DB_PASSWORD
read -p "Enter application directory [/var/www/cfbc]: " APP_DIR
read -p "Enter Git repository URL: " GIT_REPO

# Set defaults
APP_DIR=${APP_DIR:-/var/www/cfbc}
if [ -z "$DB_PASSWORD" ]; then
    DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
    log "Generated database password: $DB_PASSWORD"
fi

if [ -z "$DOMAIN_NAME" ]; then
    DOMAIN_NAME=$(curl -s ifconfig.me)
    warn "Using IP address: $DOMAIN_NAME"
fi

# Confirm settings
echo
echo "=== Deployment Configuration ==="
echo "Domain/IP: $DOMAIN_NAME"
echo "App Directory: $APP_DIR"
echo "Database Password: $DB_PASSWORD"
echo "Git Repository: $GIT_REPO"
echo
read -p "Continue with these settings? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    error "Deployment cancelled by user."
fi

# Update system
log "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install essential packages
log "Installing essential packages..."
sudo apt install -y curl wget git build-essential software-properties-common ufw htop

# Install Node.js 20
log "Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Verify Node.js installation
node_version=$(node --version)
npm_version=$(npm --version)
log "Node.js installed: $node_version"
log "NPM installed: $npm_version"

# Install PostgreSQL
log "Installing PostgreSQL..."
sudo apt install -y postgresql postgresql-contrib

# Start and enable PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Configure PostgreSQL
log "Configuring PostgreSQL database..."
sudo -u postgres psql -c "CREATE DATABASE cfbc_production;" 2>/dev/null || log "Database already exists"
sudo -u postgres psql -c "DROP USER IF EXISTS cfbc_user;"
sudo -u postgres psql -c "CREATE USER cfbc_user WITH PASSWORD '$DB_PASSWORD';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE cfbc_production TO cfbc_user;"
sudo -u postgres psql -c "ALTER USER cfbc_user CREATEDB;"

# Install Nginx
log "Installing and configuring Nginx..."
sudo apt install -y nginx
sudo systemctl start nginx
sudo systemctl enable nginx

# Configure firewall
log "Configuring firewall..."
sudo ufw --force enable
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'

# Create application directory
log "Setting up application directory..."
sudo mkdir -p $APP_DIR
sudo chown $USER:$USER $APP_DIR

# Clone repository
log "Cloning application repository..."
if [ ! -z "$GIT_REPO" ]; then
    cd $APP_DIR
    if [ -d ".git" ]; then
        log "Repository already exists, pulling latest changes..."
        git pull
    else
        git clone $GIT_REPO .
    fi
else
    warn "No Git repository provided. You'll need to upload your application files manually."
fi

# Install application dependencies
if [ -f "$APP_DIR/package.json" ]; then
    log "Installing application dependencies..."
    cd $APP_DIR
    npm install
else
    warn "package.json not found. Skipping dependency installation."
fi

# Generate session secret
SESSION_SECRET=$(openssl rand -hex 32)

# Create environment file
log "Creating production environment configuration..."
cat > $APP_DIR/.env.production << EOF
NODE_ENV=production
DATABASE_URL=postgresql://cfbc_user:$DB_PASSWORD@localhost:5432/cfbc_production
SESSION_SECRET=$SESSION_SECRET
PORT=3000

# Replit Auth Configuration (update these with your values)
REPL_ID=your-repl-id
ISSUER_URL=https://replit.com/oidc
REPLIT_DOMAINS=$DOMAIN_NAME

# Email Configuration (SendGrid)
# SENDGRID_API_KEY=your-sendgrid-api-key

# SMS Configuration (Twilio)
# TWILIO_ACCOUNT_SID=your-twilio-sid
# TWILIO_AUTH_TOKEN=your-twilio-token
# TWILIO_PHONE_NUMBER=your-twilio-phone

# Payment Configuration (Stripe)
# STRIPE_SECRET_KEY=your-stripe-secret-key
# VITE_STRIPE_PUBLIC_KEY=your-stripe-public-key
EOF

# Build application
if [ -f "$APP_DIR/package.json" ]; then
    log "Building application..."
    cd $APP_DIR
    npm run build
    
    # Run database migrations
    log "Running database migrations..."
    npm run db:push
else
    warn "Cannot build application. package.json not found."
fi

# Install PM2
log "Installing PM2 process manager..."
sudo npm install -g pm2@latest

# Create PM2 ecosystem file
log "Creating PM2 configuration..."
cat > $APP_DIR/ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'cfbc-app',
    script: 'dist/index.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'development'
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
}
EOF

# Create logs directory
mkdir -p $APP_DIR/logs

# Configure Nginx
log "Configuring Nginx reverse proxy..."
sudo tee /etc/nginx/sites-available/cfbc << EOF
server {
    listen 80;
    server_name $DOMAIN_NAME;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }

    # Static files caching
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        proxy_pass http://localhost:3000;
    }
}
EOF

# Enable site and disable default
sudo ln -sf /etc/nginx/sites-available/cfbc /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test Nginx configuration
sudo nginx -t || error "Nginx configuration test failed"

# Reload Nginx
sudo systemctl reload nginx

# Start application with PM2
if [ -f "$APP_DIR/dist/index.js" ]; then
    log "Starting application with PM2..."
    cd $APP_DIR
    pm2 start ecosystem.config.js --env production
    
    # Setup PM2 startup
    pm2 startup | grep -E '^sudo' | bash
    pm2 save
else
    warn "Application build not found. You may need to build and start manually."
fi

# Setup SSL with Let's Encrypt (optional)
if [[ "$DOMAIN_NAME" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    warn "Skipping SSL setup - using IP address instead of domain"
else
    read -p "Setup SSL certificate with Let's Encrypt? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        log "Installing Certbot and setting up SSL..."
        sudo apt install -y certbot python3-certbot-nginx
        sudo certbot --nginx -d $DOMAIN_NAME --non-interactive --agree-tos --email admin@$DOMAIN_NAME
        
        # Setup auto-renewal
        (crontab -l 2>/dev/null; echo "0 12 * * * /usr/bin/certbot renew --quiet") | crontab -
    fi
fi

# Create backup script
log "Setting up backup system..."
sudo mkdir -p /backups
cat > /home/$USER/backup.sh << 'EOF'
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
sudo -u postgres pg_dump cfbc_production > /backups/cfbc_$DATE.sql
gzip /backups/cfbc_$DATE.sql
find /backups -name "cfbc_*.sql.gz" -mtime +7 -delete
EOF

chmod +x /home/$USER/backup.sh

# Setup daily backup cron job
(crontab -l 2>/dev/null; echo "0 2 * * * /home/$USER/backup.sh") | crontab -

# Create management script
log "Creating management script..."
cat > $APP_DIR/manage.sh << 'EOF'
#!/bin/bash

case "$1" in
    start)
        pm2 start ecosystem.config.js --env production
        ;;
    stop)
        pm2 stop cfbc-app
        ;;
    restart)
        pm2 restart cfbc-app
        ;;
    logs)
        pm2 logs cfbc-app
        ;;
    status)
        pm2 status
        ;;
    backup)
        /home/$USER/backup.sh
        ;;
    update)
        git pull
        npm install
        npm run build
        npm run db:push
        pm2 restart cfbc-app
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|logs|status|backup|update}"
        exit 1
        ;;
esac
EOF

chmod +x $APP_DIR/manage.sh

# Final status check
log "Checking deployment status..."

# Check if services are running
if systemctl is-active --quiet nginx; then
    log "✓ Nginx is running"
else
    warn "✗ Nginx is not running"
fi

if systemctl is-active --quiet postgresql; then
    log "✓ PostgreSQL is running"
else
    warn "✗ PostgreSQL is not running"
fi

if pm2 list | grep -q "cfbc-app"; then
    log "✓ Application is running"
else
    warn "✗ Application is not running"
fi

# Print summary
echo
echo "=== Deployment Complete ==="
echo
log "Application URL: http://$DOMAIN_NAME"
if [[ ! "$DOMAIN_NAME" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    log "HTTPS URL: https://$DOMAIN_NAME (if SSL was configured)"
fi
echo
echo "Configuration files:"
echo "  Environment: $APP_DIR/.env.production"
echo "  PM2 Config: $APP_DIR/ecosystem.config.js"
echo "  Nginx Config: /etc/nginx/sites-available/cfbc"
echo
echo "Management commands:"
echo "  Start app: $APP_DIR/manage.sh start"
echo "  Stop app: $APP_DIR/manage.sh stop"
echo "  Restart app: $APP_DIR/manage.sh restart"
echo "  View logs: $APP_DIR/manage.sh logs"
echo "  Check status: $APP_DIR/manage.sh status"
echo "  Backup database: $APP_DIR/manage.sh backup"
echo "  Update app: $APP_DIR/manage.sh update"
echo
echo "Database credentials:"
echo "  Host: localhost"
echo "  Port: 5432"
echo "  Database: cfbc_production"
echo "  Username: cfbc_user"
echo "  Password: $DB_PASSWORD"
echo
warn "Important: Update the environment variables in $APP_DIR/.env.production with your actual API keys and configuration values!"
echo
log "Deployment completed successfully!"