#!/bin/bash

# Root User Installation Script for Central Florida Bin Cleaning
# This version is designed to run as root user

set -e  # Exit on any error

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}"
echo "==========================================="
echo "Central Florida Bin Cleaning Deployment"
echo "==========================================="
echo -e "${NC}"

echo -e "${GREEN}Welcome! This script will deploy your application as root user.${NC}"
echo

# Check Ubuntu version
if ! lsb_release -d | grep -q "Ubuntu"; then
    echo -e "${RED}Error: This script is for Ubuntu servers only.${NC}"
    exit 1
fi

echo -e "${YELLOW}This script will:${NC}"
echo "✓ Install all required software (Node.js, PostgreSQL, Nginx)"
echo "✓ Create a regular user 'cfbc' to run the application"
echo "✓ Set up the database and web server"
echo "✓ Deploy and start your application"
echo

read -p "Do you want to continue? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Installation cancelled."
    exit 0
fi

echo
echo -e "${GREEN}Starting deployment...${NC}"

# Get configuration
echo
echo "=== Configuration ==="
read -p "Enter your domain name (or press Enter to use server IP): " DOMAIN_NAME
read -p "Enter database password (or press Enter for auto-generated): " DB_PASSWORD
read -p "Enter Git repository URL (optional): " GIT_REPO

# Set defaults
if [ -z "$DB_PASSWORD" ]; then
    DB_PASSWORD=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-25)
    echo "Generated database password: $DB_PASSWORD"
fi

if [ -z "$DOMAIN_NAME" ]; then
    DOMAIN_NAME=$(curl -s ifconfig.me 2>/dev/null || echo "localhost")
    echo "Using IP/hostname: $DOMAIN_NAME"
fi

# Create application user
echo
echo "Creating application user..."
if ! id "cfbc" &>/dev/null; then
    useradd -m -s /bin/bash cfbc
    usermod -aG sudo cfbc
    echo "Created user 'cfbc'"
else
    echo "User 'cfbc' already exists"
fi

# Update system
echo "Updating system packages..."
apt update && apt upgrade -y

# Install essential packages
echo "Installing essential packages..."
apt install -y curl wget git build-essential software-properties-common ufw htop sudo

# Install Node.js 20
echo "Installing Node.js 20..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install PostgreSQL
echo "Installing PostgreSQL..."
apt install -y postgresql postgresql-contrib

# Start and enable PostgreSQL
systemctl start postgresql
systemctl enable postgresql

# Configure PostgreSQL
echo "Configuring PostgreSQL database..."
sudo -u postgres psql -c "CREATE DATABASE cfbc_production;" 2>/dev/null || echo "Database already exists"
sudo -u postgres psql -c "DROP USER IF EXISTS cfbc_user;"
sudo -u postgres psql -c "CREATE USER cfbc_user WITH PASSWORD '$DB_PASSWORD';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE cfbc_production TO cfbc_user;"
sudo -u postgres psql -c "ALTER USER cfbc_user CREATEDB;"

# Install Nginx
echo "Installing and configuring Nginx..."
apt install -y nginx
systemctl start nginx
systemctl enable nginx

# Configure firewall
echo "Configuring firewall..."
ufw --force enable
ufw allow OpenSSH
ufw allow 'Nginx Full'

# Create application directory
echo "Setting up application directory..."
mkdir -p /var/www/cfbc
chown cfbc:cfbc /var/www/cfbc

# Clone or copy application files
if [ ! -z "$GIT_REPO" ]; then
    echo "Cloning application repository..."
    sudo -u cfbc git clone $GIT_REPO /var/www/cfbc
else
    echo "Copying application files..."
    # Copy files from current directory to /var/www/cfbc
    cp -r client server shared components.json drizzle.config.ts package.json package-lock.json postcss.config.js tailwind.config.ts tsconfig.json vite.config.ts /var/www/cfbc/ 2>/dev/null || echo "Some files may not exist, continuing..."
    chown -R cfbc:cfbc /var/www/cfbc
fi

# Generate session secret
SESSION_SECRET=$(openssl rand -hex 32)

# Create environment file
echo "Creating production environment configuration..."
cat > /var/www/cfbc/.env.production << EOF
NODE_ENV=production
DATABASE_URL=postgresql://cfbc_user:$DB_PASSWORD@localhost:5432/cfbc_production
SESSION_SECRET=$SESSION_SECRET
PORT=3000

# Replit Auth Configuration (update these with your values)
REPL_ID=your-repl-id
ISSUER_URL=https://replit.com/oidc
REPLIT_DOMAINS=$DOMAIN_NAME

# Email Configuration (SendGrid)
# SENDGRID_API_KEY=your-sendgrid-api-key

# SMS Configuration (Twilio)
# TWILIO_ACCOUNT_SID=your-twilio-sid
# TWILIO_AUTH_TOKEN=your-twilio-token
# TWILIO_PHONE_NUMBER=your-twilio-phone

# Payment Configuration (Stripe)
# STRIPE_SECRET_KEY=your-stripe-secret-key
# VITE_STRIPE_PUBLIC_KEY=your-stripe-public-key
EOF

chown cfbc:cfbc /var/www/cfbc/.env.production

# Install application dependencies and build
if [ -f "/var/www/cfbc/package.json" ]; then
    echo "Installing application dependencies..."
    cd /var/www/cfbc
    sudo -u cfbc npm install
    
    echo "Building application..."
    sudo -u cfbc npm run build
    
    echo "Running database migrations..."
    sudo -u cfbc npm run db:push
else
    echo "Warning: package.json not found. Skipping build."
fi

# Install PM2
echo "Installing PM2 process manager..."
npm install -g pm2@latest

# Create PM2 ecosystem file
echo "Creating PM2 configuration..."
cat > /var/www/cfbc/ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'cfbc-app',
    script: 'dist/index.js',
    instances: 'max',
    exec_mode: 'cluster',
    user: 'cfbc',
    env: {
      NODE_ENV: 'development'
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log',
    time: true
  }]
}
EOF

# Create logs directory
sudo -u cfbc mkdir -p /var/www/cfbc/logs

# Configure Nginx
echo "Configuring Nginx reverse proxy..."
cat > /etc/nginx/sites-available/cfbc << EOF
server {
    listen 80;
    server_name $DOMAIN_NAME;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
    }
}
EOF

# Enable site and disable default
ln -sf /etc/nginx/sites-available/cfbc /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test and reload Nginx
nginx -t
systemctl reload nginx

# Start application with PM2
if [ -f "/var/www/cfbc/dist/index.js" ]; then
    echo "Starting application with PM2..."
    cd /var/www/cfbc
    sudo -u cfbc pm2 start ecosystem.config.js --env production
    
    # Setup PM2 startup (as cfbc user)
    sudo -u cfbc pm2 startup | grep -E '^sudo' | bash || echo "PM2 startup configured"
    sudo -u cfbc pm2 save
else
    echo "Warning: Application build not found. You may need to build manually."
fi

# Create management script
echo "Creating management script..."
cat > /var/www/cfbc/manage.sh << 'EOF'
#!/bin/bash

case "$1" in
    start)
        sudo -u cfbc pm2 start ecosystem.config.js --env production
        ;;
    stop)
        sudo -u cfbc pm2 stop cfbc-app
        ;;
    restart)
        sudo -u cfbc pm2 restart cfbc-app
        ;;
    logs)
        sudo -u cfbc pm2 logs cfbc-app
        ;;
    status)
        sudo -u cfbc pm2 status
        ;;
    backup)
        DATE=$(date +%Y%m%d_%H%M%S)
        sudo -u postgres pg_dump cfbc_production > /backups/cfbc_$DATE.sql
        gzip /backups/cfbc_$DATE.sql
        echo "Backup created: /backups/cfbc_$DATE.sql.gz"
        ;;
    update)
        cd /var/www/cfbc
        sudo -u cfbc git pull
        sudo -u cfbc npm install
        sudo -u cfbc npm run build
        sudo -u cfbc npm run db:push
        sudo -u cfbc pm2 restart cfbc-app
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|logs|status|backup|update}"
        exit 1
        ;;
esac
EOF

chmod +x /var/www/cfbc/manage.sh

# Setup backup directory
mkdir -p /backups
chown cfbc:cfbc /backups

# Setup SSL if domain provided
if [[ ! "$DOMAIN_NAME" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && [[ "$DOMAIN_NAME" != "localhost" ]]; then
    read -p "Setup SSL certificate with Let's Encrypt? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "Installing Certbot and setting up SSL..."
        apt install -y certbot python3-certbot-nginx
        certbot --nginx -d $DOMAIN_NAME --non-interactive --agree-tos --email admin@$DOMAIN_NAME || echo "SSL setup failed, continuing without SSL"
    fi
fi

# Final status check
echo
echo "=== Deployment Status ==="
echo

if systemctl is-active --quiet nginx; then
    echo -e "${GREEN}✓ Nginx is running${NC}"
else
    echo -e "${RED}✗ Nginx is not running${NC}"
fi

if systemctl is-active --quiet postgresql; then
    echo -e "${GREEN}✓ PostgreSQL is running${NC}"
else
    echo -e "${RED}✗ PostgreSQL is not running${NC}"
fi

if sudo -u cfbc pm2 list | grep -q "cfbc-app"; then
    echo -e "${GREEN}✓ Application is running${NC}"
else
    echo -e "${RED}✗ Application is not running${NC}"
fi

echo
echo "=== Deployment Complete ==="
echo
echo -e "${GREEN}Application URL: http://$DOMAIN_NAME${NC}"
if [[ ! "$DOMAIN_NAME" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo -e "${GREEN}HTTPS URL: https://$DOMAIN_NAME (if SSL was configured)${NC}"
fi
echo
echo "Management commands:"
echo "  /var/www/cfbc/manage.sh start|stop|restart|logs|status|backup|update"
echo
echo "Database credentials:"
echo "  Database: cfbc_production"
echo "  Username: cfbc_user"
echo "  Password: $DB_PASSWORD"
echo
echo -e "${YELLOW}Important: Update API keys in /var/www/cfbc/.env.production${NC}"
echo
echo "Default login accounts:"
echo "  Admin: admin / admin123"
echo "  Customer: customer1 / customer123"
echo "  Driver: driver1 / driver123"
echo "  Dispatcher: dispatcher1 / dispatcher123"
echo
echo -e "${GREEN}Deployment completed successfully!${NC}"