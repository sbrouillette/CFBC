#!/bin/bash

# Simple Installation Script for Central Florida Bin Cleaning
# This script helps beginners deploy the application easily

set -e  # Exit on any error

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}"
echo "==========================================="
echo "Central Florida Bin Cleaning Deployment"
echo "==========================================="
echo -e "${NC}"

echo -e "${GREEN}Welcome! This script will help you deploy your application.${NC}"
echo

# Check if running as root
if [[ $EUID -eq 0 ]]; then
    echo -e "${RED}Error: Please run this script as a regular user (not root).${NC}"
    echo "Make sure your user has sudo privileges."
    exit 1
fi

# Check Ubuntu version
if ! lsb_release -d | grep -q "Ubuntu"; then
    echo -e "${RED}Error: This script is for Ubuntu servers only.${NC}"
    exit 1
fi

echo -e "${YELLOW}Before we start, make sure you have:${NC}"
echo "✓ Ubuntu 20.04 or 22.04 VPS server"
echo "✓ Sudo privileges on this server"
echo "✓ Domain name (optional - you can use IP address)"
echo "✓ Your application source code"
echo

read -p "Do you want to continue? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Installation cancelled."
    exit 0
fi

echo
echo -e "${GREEN}Great! Let's get started.${NC}"
echo

# Show available scripts
echo -e "${BLUE}Available deployment options:${NC}"
echo
echo "1. 📁 deploy.sh - Full automated deployment (recommended)"
echo "2. 📖 SIMPLE_DEPLOYMENT.md - Step-by-step beginner guide"
echo "3. 📚 DEPLOYMENT_GUIDE.md - Detailed technical guide"
echo

echo -e "${YELLOW}Option 1 (Recommended): Run the automated deployment script${NC}"
echo "This will automatically install everything for you."
echo

read -p "Run automated deployment now? (y/N): " -n 1 -r
echo

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo
    echo -e "${GREEN}Starting automated deployment...${NC}"
    echo
    
    # Make sure deploy.sh is executable
    chmod +x deploy.sh
    
    # Run the deployment script
    ./deploy.sh
    
else
    echo
    echo -e "${BLUE}Manual deployment options:${NC}"
    echo
    echo "For step-by-step instructions, read one of these files:"
    echo "• ${GREEN}SIMPLE_DEPLOYMENT.md${NC} - Easy guide for beginners"
    echo "• ${GREEN}DEPLOYMENT_GUIDE.md${NC} - Complete technical guide"
    echo
    echo "To read a guide:"
    echo "  cat SIMPLE_DEPLOYMENT.md"
    echo "  cat DEPLOYMENT_GUIDE.md"
    echo
    echo "To run automated deployment later:"
    echo "  ./deploy.sh"
    echo
fi

echo
echo -e "${GREEN}Need help? Check these resources:${NC}"
echo "• Read SIMPLE_DEPLOYMENT.md for step-by-step instructions"
echo "• Read DEPLOYMENT_GUIDE.md for detailed technical information"
echo "• Check application logs after deployment with: pm2 logs cfbc-app"
echo
echo -e "${BLUE}Thank you for using Central Florida Bin Cleaning!${NC}"