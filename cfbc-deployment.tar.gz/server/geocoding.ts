// Simple geocoding service for Central Florida area
// This is a simplified version that estimates coordinates based on common address patterns

interface GeocodeResult {
  latitude: string;
  longitude: string;
}

// Central Florida coordinate bounds
const CENTRAL_FLORIDA_BOUNDS = {
  north: 28.8,    // North of Orlando
  south: 27.5,    // South of Orlando
  east: -80.8,    // East side
  west: -82.2,    // West side
  center: {
    lat: 28.3,    // Orlando metro area center
    lng: -81.4,
  }
};

// Common Central Florida cities with approximate coordinates
const CITY_COORDINATES: Record<string, { lat: number; lng: number }> = {
  'orlando': { lat: 28.5383, lng: -81.3792 },
  'lakeland': { lat: 28.0395, lng: -81.9498 },
  'tampa': { lat: 27.9506, lng: -82.4572 },
  'kissimmee': { lat: 28.2916, lng: -81.4077 },
  'winter haven': { lat: 28.0222, lng: -81.7327 },
  'clermont': { lat: 28.5493, lng: -81.7730 },
  'leesburg': { lat: 28.8108, lng: -81.8782 },
  'apopka': { lat: 28.6934, lng: -81.5322 },
  'sanford': { lat: 28.8028, lng: -81.2690 },
  'altamonte springs': { lat: 28.6614, lng: -81.3656 },
  'winter park': { lat: 28.6000, lng: -81.3393 },
  'oviedo': { lat: 28.6698, lng: -81.2081 },
  'casselberry': { lat: 28.6583, lng: -81.3201 },
  'longwood': { lat: 28.7028, lng: -81.3384 },
  'mount dora': { lat: 28.8014, lng: -81.6439 },
  'eustis': { lat: 28.8528, lng: -81.6848 },
  'tavares': { lat: 28.8044, lng: -81.7257 },
  'deland': { lat: 29.0286, lng: -81.3009 },
  'deltona': { lat: 28.9005, lng: -81.2637 },
  'lake mary': { lat: 28.7589, lng: -81.3176 },
  'winter springs': { lat: 28.6989, lng: -81.3081 },
  'maitland': { lat: 28.6279, lng: -81.3631 },
  'windermere': { lat: 28.4985, lng: -81.5367 },
  'groveland': { lat: 28.6022, lng: -81.8406 },
};

export function geocodeAddress(address: string): GeocodeResult {
  if (!address || address.trim() === '') {
    // Return center of Central Florida if no address
    return {
      latitude: CENTRAL_FLORIDA_BOUNDS.center.lat.toString(),
      longitude: CENTRAL_FLORIDA_BOUNDS.center.lng.toString(),
    };
  }

  const normalizedAddress = address.toLowerCase().trim();
  
  // Check if address contains a known city
  const foundCity = Object.keys(CITY_COORDINATES).find(city => 
    normalizedAddress.includes(city)
  );

  if (foundCity) {
    const cityCoords = CITY_COORDINATES[foundCity];
    // Add small random offset to simulate street-level precision
    const latOffset = (Math.random() - 0.5) * 0.02; // ~1 mile variance
    const lngOffset = (Math.random() - 0.5) * 0.02;
    
    return {
      latitude: (cityCoords.lat + latOffset).toFixed(6),
      longitude: (cityCoords.lng + lngOffset).toFixed(6),
    };
  }

  // If no city found, check for common street patterns and estimate
  const streetPatterns = [
    { pattern: /main\s*st/, coords: { lat: 28.5383, lng: -81.3792 } }, // Orlando downtown
    { pattern: /central\s*ave/, coords: { lat: 28.5450, lng: -81.3800 } },
    { pattern: /colonial\s*dr/, coords: { lat: 28.5562, lng: -81.3850 } },
    { pattern: /orange\s*ave/, coords: { lat: 28.5470, lng: -81.3780 } },
    { pattern: /pine\s*st/, coords: { lat: 28.5400, lng: -81.3750 } },
    { pattern: /oak\s*st/, coords: { lat: 28.5350, lng: -81.3720 } },
    { pattern: /park\s*ave/, coords: { lat: 28.6000, lng: -81.3393 } }, // Winter Park
  ];

  for (const { pattern, coords } of streetPatterns) {
    if (pattern.test(normalizedAddress)) {
      const latOffset = (Math.random() - 0.5) * 0.01;
      const lngOffset = (Math.random() - 0.5) * 0.01;
      
      return {
        latitude: (coords.lat + latOffset).toFixed(6),
        longitude: (coords.lng + lngOffset).toFixed(6),
      };
    }
  }

  // Check for zip codes in Central Florida area
  const zipMatch = normalizedAddress.match(/\b(32[0-9]{3}|33[0-9]{3}|34[0-9]{3})\b/);
  if (zipMatch) {
    const zip = parseInt(zipMatch[1]);
    
    // Map zip code ranges to approximate coordinates
    if (zip >= 32700 && zip <= 32799) {
      // Sanford/Deltona area
      return {
        latitude: (28.8 + (Math.random() - 0.5) * 0.05).toFixed(6),
        longitude: (-81.3 + (Math.random() - 0.5) * 0.05).toFixed(6),
      };
    } else if (zip >= 32800 && zip <= 32899) {
      // Orlando area
      return {
        latitude: (28.55 + (Math.random() - 0.5) * 0.05).toFixed(6),
        longitude: (-81.38 + (Math.random() - 0.5) * 0.05).toFixed(6),
      };
    } else if (zip >= 33800 && zip <= 33899) {
      // Lakeland area
      return {
        latitude: (28.04 + (Math.random() - 0.5) * 0.05).toFixed(6),
        longitude: (-81.95 + (Math.random() - 0.5) * 0.05).toFixed(6),
      };
    } else if (zip >= 34700 && zip <= 34799) {
      // Clermont/Groveland area
      return {
        latitude: (28.55 + (Math.random() - 0.5) * 0.05).toFixed(6),
        longitude: (-81.77 + (Math.random() - 0.5) * 0.05).toFixed(6),
      };
    }
  }

  // Default: Random location within Central Florida bounds with slight bias toward Orlando
  const latRange = CENTRAL_FLORIDA_BOUNDS.north - CENTRAL_FLORIDA_BOUNDS.south;
  const lngRange = CENTRAL_FLORIDA_BOUNDS.east - CENTRAL_FLORIDA_BOUNDS.west;
  
  // Bias toward Orlando metro area (60% chance)
  if (Math.random() < 0.6) {
    return {
      latitude: (CENTRAL_FLORIDA_BOUNDS.center.lat + (Math.random() - 0.5) * 0.3).toFixed(6),
      longitude: (CENTRAL_FLORIDA_BOUNDS.center.lng + (Math.random() - 0.5) * 0.3).toFixed(6),
    };
  }

  // Otherwise, random within full bounds
  return {
    latitude: (CENTRAL_FLORIDA_BOUNDS.south + Math.random() * latRange).toFixed(6),
    longitude: (CENTRAL_FLORIDA_BOUNDS.west + Math.random() * lngRange).toFixed(6),
  };
}

// Calculate distance between two coordinates using Haversine formula
export function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 3959; // Earth's radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

// Simple route optimization using nearest neighbor algorithm
export function optimizeRoute(jobs: Array<{ id: string; address: string; latitude?: string; longitude?: string }>, startLat?: number, startLng?: number): string[] {
  if (jobs.length <= 1) return jobs.map(job => job.id);

  // Ensure all jobs have coordinates
  const jobsWithCoords = jobs.map(job => {
    if (!job.latitude || !job.longitude) {
      const coords = geocodeAddress(job.address);
      return {
        ...job,
        latitude: coords.latitude,
        longitude: coords.longitude,
      };
    }
    return job;
  });

  const unvisited = [...jobsWithCoords];
  const optimizedOrder: string[] = [];
  
  // Start from the specified start location or first job
  let currentLat = startLat || parseFloat(jobsWithCoords[0].latitude!);
  let currentLng = startLng || parseFloat(jobsWithCoords[0].longitude!);
  
  // If we have a start location, find the nearest job first
  if (startLat && startLng) {
    let nearestIndex = 0;
    let nearestDistance = Infinity;
    
    for (let i = 0; i < unvisited.length; i++) {
      const distance = calculateDistance(
        currentLat, currentLng,
        parseFloat(unvisited[i].latitude!),
        parseFloat(unvisited[i].longitude!)
      );
      if (distance < nearestDistance) {
        nearestDistance = distance;
        nearestIndex = i;
      }
    }
    
    const nearest = unvisited.splice(nearestIndex, 1)[0];
    optimizedOrder.push(nearest.id);
    currentLat = parseFloat(nearest.latitude!);
    currentLng = parseFloat(nearest.longitude!);
  }

  // Use nearest neighbor algorithm for remaining jobs
  while (unvisited.length > 0) {
    let nearestIndex = 0;
    let nearestDistance = Infinity;
    
    for (let i = 0; i < unvisited.length; i++) {
      const distance = calculateDistance(
        currentLat, currentLng,
        parseFloat(unvisited[i].latitude!),
        parseFloat(unvisited[i].longitude!)
      );
      if (distance < nearestDistance) {
        nearestDistance = distance;
        nearestIndex = i;
      }
    }
    
    const nearest = unvisited.splice(nearestIndex, 1)[0];
    optimizedOrder.push(nearest.id);
    currentLat = parseFloat(nearest.latitude!);
    currentLng = parseFloat(nearest.longitude!);
  }

  return optimizedOrder;
}