import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupLocalAuth, isAuthenticated } from "./localAuth";
import { geocodeAddress, optimizeRoute, calculateDistance } from "./geocoding";
import { insertServiceRequestSchema, insertContactMessageSchema, insertJobSchema, insertInvoiceSchema, loginSchema, registerSchema, insertSystemConfigSchema, insertServiceSchema, insertRouteSchema } from "@shared/schema";
import { notificationService } from "./notifications";
import { z } from "zod";
import passport from "passport";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupLocalAuth(app);

  // Auth routes
  app.post('/api/auth/login', (req, res, next) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      passport.authenticate('local', (err: any, user: any, info: any) => {
        if (err) {
          return res.status(500).json({ message: "Internal server error" });
        }
        if (!user) {
          return res.status(401).json({ message: info?.message || "Invalid credentials" });
        }
        req.logIn(user, (err) => {
          if (err) {
            return res.status(500).json({ message: "Login failed" });
          }
          res.json({ message: "Login successful", user: { ...user, password: undefined } });
        });
      })(req, res, next);
    } catch (error) {
      res.status(400).json({ message: "Invalid login data" });
    }
  });

  app.post('/api/auth/register', async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const user = await storage.createUser(validatedData);
      res.json({ message: "Registration successful", user: { ...user, password: undefined } });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ message: "Registration failed" });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get('/api/logout', (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).send('Logout failed');
      }
      res.redirect('/');
    });
  });

  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      res.json({ ...req.user, password: undefined });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Contact form submission
  app.post('/api/contact', async (req, res) => {
    try {
      const validatedData = insertContactMessageSchema.parse(req.body);
      const message = await storage.createContactMessage(validatedData);
      res.json({ success: true, message: "Message sent successfully" });
    } catch (error) {
      console.error("Error creating contact message:", error);
      res.status(400).json({ message: "Invalid contact form data" });
    }
  });

  // Service request routes
  app.post('/api/service-requests', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const validatedData = insertServiceRequestSchema.parse({
        ...req.body,
        customerId: userId,
      });
      const request = await storage.createServiceRequest(validatedData);
      res.json(request);
    } catch (error) {
      console.error("Error creating service request:", error);
      res.status(400).json({ message: "Invalid service request data" });
    }
  });

  app.get('/api/service-requests', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = req.user;
      
      let requests;
      if (user.role === 'admin' || user.role === 'dispatcher' || user.role === 'super_admin') {
        requests = await storage.getPendingServiceRequests();
      } else {
        requests = await storage.getServiceRequestsByCustomer(userId);
      }
      
      res.json(requests);
    } catch (error) {
      console.error("Error fetching service requests:", error);
      res.status(500).json({ message: "Failed to fetch service requests" });
    }
  });

  app.delete('/api/service-requests/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const user = req.user;
      
      if (!user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Check if this is the user's own request or if user is admin
      const request = await storage.getServiceRequest(id);
      if (!request) {
        return res.status(404).json({ message: "Service request not found" });
      }

      if ((user.role !== 'admin' && user.role !== 'super_admin') && request.customerId !== user.id) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      await storage.deleteServiceRequest(id);
      res.json({ success: true, message: "Service request cancelled" });
    } catch (error) {
      console.error("Error deleting service request:", error);
      res.status(500).json({ message: "Failed to cancel service request" });
    }
  });

  // Job routes
  app.get('/api/jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = req.user;

      let jobs;
      if (user.role === 'customer') {
        jobs = await storage.getJobsByCustomer(userId);
      } else if (user.role === 'driver') {
        // Check if this is a request for specific driver or current user
        const driverId = req.query.driverId as string;
        if (driverId && driverId !== userId) {
          return res.status(403).json({ message: "Driver can only access their own jobs" });
        }
        jobs = await storage.getJobsByDriver(userId);
      } else if (user.role === 'dispatcher' || user.role === 'admin' || user.role === 'super_admin') {
        // Enhanced filtering for dispatchers and admins
        const status = req.query.status as string;
        const driverId = req.query.driverId as string;
        const unassigned = req.query.unassigned === 'true';

        if (driverId && status) {
          // Get jobs for specific driver with specific statuses
          const statuses = status.split(',').map(s => s.trim());
          jobs = await storage.getJobsByDriverAndStatuses(driverId, statuses);
        } else if (unassigned && status) {
          // Get unassigned jobs with specific status
          const statuses = status.split(',').map(s => s.trim());
          jobs = await storage.getUnassignedJobsByStatuses(statuses);
        } else if (status) {
          // Get jobs by status (existing functionality)
          jobs = await storage.getJobsByStatus(status);
        } else if (driverId) {
          // Get all jobs for specific driver
          jobs = await storage.getJobsByDriver(driverId);
        } else if (unassigned) {
          // Get all unassigned jobs
          jobs = await storage.getUnassignedJobs();
        } else {
          // Get all jobs
          jobs = await storage.getAllJobs();
        }
      } else {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      res.json(jobs);
    } catch (error) {
      console.error("Error fetching jobs:", error);
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.post('/api/jobs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = req.user;
      
      if (user.role !== 'dispatcher' && user.role !== 'admin' && user.role !== 'super_admin') {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const validatedData = insertJobSchema.parse(req.body);
      
      // Automatically geocode the address
      const coordinates = geocodeAddress(validatedData.address);
      const jobWithCoords = {
        ...validatedData,
        latitude: coordinates.latitude,
        longitude: coordinates.longitude,
      };
      
      const job = await storage.createJob(jobWithCoords);

      // Send notification for job scheduling if scheduled date exists
      try {
        if (validatedData.scheduledDate && validatedData.customerId) {
          await notificationService.notifyJobScheduled(
            validatedData.customerId, 
            job.id, 
            new Date(validatedData.scheduledDate)
          );
        }
      } catch (notificationError) {
        console.error("Error sending job scheduling notification:", notificationError);
      }

      // Create invoice if requested
      if (req.body.createInvoice && req.body.serviceIds?.length > 0) {
        try {
          const services = await storage.getServicesByIds(req.body.serviceIds);
          const totalAmount = services.reduce((sum: number, service: any) => sum + parseFloat(service.basePrice), 0);
          
          const invoiceNumber = await storage.generateInvoiceNumber();
          const invoice = await storage.createInvoice({
            customerId: validatedData.customerId,
            jobId: job.id,
            invoiceNumber,
            amount: totalAmount,
            status: 'pending',
            dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
          });

          // Add services to invoice
          for (const service of services) {
            await storage.createInvoiceService({
              invoiceId: invoice.id,
              serviceId: service.id,
              quantity: 1,
              unitPrice: parseFloat(service.basePrice),
              totalPrice: parseFloat(service.basePrice)
            });
          }
        } catch (invoiceError) {
          console.error("Error creating invoice:", invoiceError);
        }
      }
      
      res.json(job);
    } catch (error) {
      console.error("Error creating job:", error);
      res.status(400).json({ message: "Invalid job data" });
    }
  });

  app.patch('/api/jobs/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const userId = req.user.id;
      const user = req.user;

      const job = await storage.getJob(id);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }

      // Authorization check
      if (user.role === 'driver' && job.driverId !== userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      if (user.role === 'customer') {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const completedAt = status === 'completed' ? new Date() : undefined;
      await storage.updateJobStatus(id, status, completedAt);
      
      // Send notifications based on status change
      try {
        if (status === 'completed' && job.customerId) {
          await notificationService.notifyJobCompleted(job.customerId, id);
        } else if (status === 'in_progress' && job.customerId && job.driverId) {
          const driver = await storage.getUser(job.driverId);
          if (driver) {
            await notificationService.notifyDriverEnRoute(
              job.customerId, 
              id, 
              `${driver.firstName} ${driver.lastName}`
            );
          }
        }
      } catch (notificationError) {
        console.error("Error sending notification:", notificationError);
        // Don't fail the status update if notification fails
      }
      
      res.json({ success: true, message: "Job status updated" });
    } catch (error) {
      console.error("Error updating job status:", error);
      res.status(500).json({ message: "Failed to update job status" });
    }
  });

  app.patch('/api/jobs/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const user = req.user;
      
      if (!user || (user.role !== 'admin' && user.role !== 'super_admin')) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const job = await storage.getJob(id);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }

      const updateData = req.body;
      delete updateData.id; // Remove id from update data
      
      await storage.updateJob(id, updateData);
      
      const updatedJob = await storage.getJob(id);
      res.json(updatedJob);
    } catch (error) {
      console.error("Error updating job:", error);
      res.status(500).json({ message: "Failed to update job" });
    }
  });

  app.patch('/api/jobs/:id/assign', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { driverId } = req.body;
      const user = req.user;
      
      if (!user || (user.role !== 'dispatcher' && user.role !== 'admin' && user.role !== 'super_admin')) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      await storage.assignJobToDriver(id, driverId, user.id);
      res.json({ success: true, message: "Job assigned successfully" });
    } catch (error) {
      console.error("Error assigning job:", error);
      res.status(500).json({ message: "Failed to assign job" });
    }
  });

  // Invoice routes
  app.get('/api/invoices', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      const userId = user.id;
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.role !== 'customer' && user.role !== 'admin' && user.role !== 'super_admin') {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const invoices = await storage.getInvoicesByCustomer(
        user.role === 'admin' ? req.query.customerId as string || userId : userId
      );
      
      res.json(invoices);
    } catch (error) {
      console.error("Error fetching invoices:", error);
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  app.post('/api/invoices', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || (user.role !== 'admin' && user.role !== 'dispatcher')) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const invoiceNumber = await storage.generateInvoiceNumber();
      const validatedData = insertInvoiceSchema.parse({
        ...req.body,
        invoiceNumber,
      });
      
      const invoice = await storage.createInvoice(validatedData);
      res.json(invoice);
    } catch (error) {
      console.error("Error creating invoice:", error);
      res.status(400).json({ message: "Invalid invoice data" });
    }
  });

  app.patch('/api/invoices/:id/pay', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const user = req.user;
      const userId = user.id;
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const invoice = await storage.getInvoice(id);
      if (!invoice) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      if (user.role === 'customer' && invoice.customerId !== userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      await storage.updateInvoiceStatus(id, 'paid', new Date());
      res.json({ success: true, message: "Invoice marked as paid" });
    } catch (error) {
      console.error("Error updating invoice:", error);
      res.status(500).json({ message: "Failed to update invoice" });
    }
  });

  // User management routes (admin, super_admin, and dispatcher can view)
  app.get('/api/users', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || (user.role !== 'admin' && user.role !== 'super_admin' && user.role !== 'dispatcher')) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const role = req.query.role as string;
      const users = await storage.getAllUsers();
      
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post('/api/users', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || (user.role !== 'admin' && user.role !== 'super_admin')) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const validatedData = registerSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const newUser = await storage.createUser(validatedData);
      res.json({ ...newUser, password: undefined });
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(400).json({ message: "Failed to create user" });
    }
  });

  app.patch('/api/users/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      const { id } = req.params;
      
      if (!user || (user.role !== 'admin' && user.role !== 'super_admin')) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const updateData = req.body;
      await storage.updateUser(id, updateData);
      
      const updatedUser = await storage.getUser(id);
      res.json({ ...updatedUser, password: undefined });
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.patch('/api/users/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { isActive } = req.body;
      const user = req.user;
      
      if (!user || (user.role !== 'admin' && user.role !== 'super_admin')) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      await storage.updateUserStatus(id, isActive);
      res.json({ success: true, message: "User status updated" });
    } catch (error) {
      console.error("Error updating user status:", error);
      res.status(500).json({ message: "Failed to update user status" });
    }
  });

  // Contact messages (admin and super_admin only)
  app.get('/api/contact-messages', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || (user.role !== 'admin' && user.role !== 'super_admin')) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const messages = await storage.getContactMessages();
      res.json(messages);
    } catch (error) {
      console.error("Error fetching contact messages:", error);
      res.status(500).json({ message: "Failed to fetch contact messages" });
    }
  });

  // System configuration routes (Super Admin only)
  app.get('/api/system/config', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || user.role !== 'super_admin') {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const configs = await storage.getAllSystemConfigs();
      res.json(configs);
    } catch (error) {
      console.error("Error fetching system configs:", error);
      res.status(500).json({ message: "Failed to fetch system configurations" });
    }
  });

  app.post('/api/system/config', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || user.role !== 'super_admin') {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const validatedData = insertSystemConfigSchema.parse({
        ...req.body,
        updatedBy: user.id,
      });
      
      const config = await storage.createSystemConfig(validatedData);
      res.json(config);
    } catch (error) {
      console.error("Error creating system config:", error);
      res.status(400).json({ message: "Invalid system configuration data" });
    }
  });

  app.put('/api/system/config/:key', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || user.role !== 'super_admin') {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { key } = req.params;
      const { configValue } = req.body;
      
      await storage.updateSystemConfig(key, configValue, user.id);
      res.json({ success: true, message: "System configuration updated" });
    } catch (error) {
      console.error("Error updating system config:", error);
      res.status(500).json({ message: "Failed to update system configuration" });
    }
  });

  app.delete('/api/system/config/:key', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || user.role !== 'super_admin') {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { key } = req.params;
      await storage.deleteSystemConfig(key);
      res.json({ success: true, message: "System configuration deleted" });
    } catch (error) {
      console.error("Error deleting system config:", error);
      res.status(500).json({ message: "Failed to delete system configuration" });
    }
  });

  // Services Management API (Super Admin only)
  app.get('/api/services', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      // Allow all authenticated users to view services
      const services = await storage.getAllServices();
      res.json(services);
    } catch (error) {
      console.error("Error fetching services:", error);
      res.status(500).json({ message: "Failed to fetch services" });
    }
  });

  app.get('/api/services/active', isAuthenticated, async (req: any, res) => {
    try {
      const services = await storage.getActiveServices();
      res.json(services);
    } catch (error) {
      console.error("Error fetching active services:", error);
      res.status(500).json({ message: "Failed to fetch active services" });
    }
  });

  app.post('/api/services', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || user.role !== 'super_admin') {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const validatedData = insertServiceSchema.parse(req.body);
      const service = await storage.createService(validatedData);
      res.json(service);
    } catch (error: any) {
      console.error("Error creating service:", error);
      if (error.name === 'ZodError') {
        res.status(400).json({ message: "Invalid service data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create service" });
      }
    }
  });

  app.put('/api/services/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || user.role !== 'super_admin') {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      const validatedData = insertServiceSchema.partial().parse(req.body);
      await storage.updateService(id, validatedData);
      res.json({ success: true, message: "Service updated successfully" });
    } catch (error: any) {
      console.error("Error updating service:", error);
      if (error.name === 'ZodError') {
        res.status(400).json({ message: "Invalid service data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update service" });
      }
    }
  });

  app.put('/api/services/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || user.role !== 'super_admin') {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      const { isActive } = req.body;
      await storage.updateServiceStatus(id, isActive);
      res.json({ success: true, message: "Service status updated successfully" });
    } catch (error) {
      console.error("Error updating service status:", error);
      res.status(500).json({ message: "Failed to update service status" });
    }
  });

  app.delete('/api/services/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || user.role !== 'super_admin') {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      await storage.deleteService(id);
      res.json({ success: true, message: "Service deleted successfully" });
    } catch (error) {
      console.error("Error deleting service:", error);
      res.status(500).json({ message: "Failed to delete service" });
    }
  });

  // Route Management API
  app.get('/api/routes', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      const { driverId, date } = req.query;
      
      let routes;
      if (driverId) {
        routes = await storage.getRoutesByDriver(driverId);
      } else if (date) {
        routes = await storage.getRoutesByDate(new Date(date));
      } else {
        // For admins and dispatchers, get all routes for today
        if (user.role === 'admin' || user.role === 'super_admin' || user.role === 'dispatcher') {
          routes = await storage.getRoutesByDate(new Date());
        } else {
          // For drivers, get only their routes
          routes = await storage.getRoutesByDriver(user.id);
        }
      }
      
      res.json(routes);
    } catch (error) {
      console.error("Error fetching routes:", error);
      res.status(500).json({ message: "Failed to fetch routes" });
    }
  });

  app.get('/api/routes/:id', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const route = await storage.getRoute(id);
      
      if (!route) {
        return res.status(404).json({ message: "Route not found" });
      }
      
      // Get jobs for this route
      const jobs = await storage.getJobsByRoute(id);
      
      res.json({ ...route, jobs });
    } catch (error) {
      console.error("Error fetching route:", error);
      res.status(500).json({ message: "Failed to fetch route" });
    }
  });

  app.post('/api/routes', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || !['admin', 'super_admin', 'dispatcher'].includes(user.role)) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const routeData = {
        ...req.body,
        createdBy: user.id,
      };

      // Automatically geocode start and end locations if provided
      if (routeData.startLocation) {
        const startCoords = geocodeAddress(routeData.startLocation);
        routeData.startLatitude = startCoords.latitude;
        routeData.startLongitude = startCoords.longitude;
      }

      if (routeData.endLocation) {
        const endCoords = geocodeAddress(routeData.endLocation);
        routeData.endLatitude = endCoords.latitude;
        routeData.endLongitude = endCoords.longitude;
      }

      const validatedData = insertRouteSchema.parse(routeData);
      const route = await storage.createRoute(validatedData);
      
      // If jobIds are provided, assign them to the route and optimize
      if (req.body.jobIds && req.body.jobIds.length > 0) {
        const optimizedOrder = await storage.optimizeRoute(
          req.body.jobIds,
          validatedData.startLatitude ? parseFloat(validatedData.startLatitude) : undefined,
          validatedData.startLongitude ? parseFloat(validatedData.startLongitude) : undefined,
          validatedData.endLatitude ? parseFloat(validatedData.endLatitude) : undefined,
          validatedData.endLongitude ? parseFloat(validatedData.endLongitude) : undefined
        );
        
        await storage.assignJobsToRoute(route.id, optimizedOrder);
        
        // Update route with optimized order
        await storage.updateRoute(route.id, {
          optimizedOrder: optimizedOrder
        });
      }
      
      res.json(route);
    } catch (error: any) {
      console.error("Error creating route:", error);
      if (error.name === 'ZodError') {
        res.status(400).json({ message: "Invalid route data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create route" });
      }
    }
  });

  app.put('/api/routes/:id/optimize', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || !['admin', 'super_admin', 'dispatcher'].includes(user.role)) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      const { jobIds } = req.body;
      
      if (!jobIds || jobIds.length === 0) {
        return res.status(400).json({ message: "Job IDs are required for optimization" });
      }

      // Get route details for start/end coordinates
      const route = await storage.getRoute(id);
      if (!route) {
        return res.status(404).json({ message: "Route not found" });
      }

      // Get jobs with their coordinates
      const jobs = await Promise.all(
        jobIds.map(async (jobId: string) => {
          const job = await storage.getJob(jobId);
          if (!job) return null;
          
          // If job doesn't have coordinates, geocode it
          if (!job.latitude || !job.longitude) {
            const coords = geocodeAddress(job.address);
            await storage.updateJob(jobId, {
              latitude: coords.latitude,
              longitude: coords.longitude,
            });
            return { ...job, latitude: coords.latitude, longitude: coords.longitude };
          }
          
          return job;
        })
      );

      const validJobs = jobs.filter(Boolean);
      
      // Use geocoding service for optimization
      const startLat = route.startLatitude ? parseFloat(route.startLatitude) : undefined;
      const startLng = route.startLongitude ? parseFloat(route.startLongitude) : undefined;
      
      const optimizedOrder = optimizeRoute(validJobs, startLat, startLng);
      
      // Assign optimized jobs to route
      await storage.assignJobsToRoute(id, optimizedOrder);
      
      // Update route with optimized order
      await storage.updateRoute(id, {
        optimizedOrder: optimizedOrder
      });
      
      res.json({ success: true, optimizedOrder });
    } catch (error) {
      console.error("Error optimizing route:", error);
      res.status(500).json({ message: "Failed to optimize route" });
    }
  });

  app.put('/api/routes/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      const { id } = req.params;
      const { status } = req.body;
      
      // Check authorization - drivers can update their own routes, admins/dispatchers can update any
      if (user.role === 'driver') {
        const route = await storage.getRoute(id);
        if (!route || route.driverId !== user.id) {
          return res.status(403).json({ message: "Unauthorized" });
        }
      } else if (!['admin', 'super_admin', 'dispatcher'].includes(user.role)) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      await storage.updateRouteStatus(id, status);
      res.json({ success: true, message: "Route status updated successfully" });
    } catch (error) {
      console.error("Error updating route status:", error);
      res.status(500).json({ message: "Failed to update route status" });
    }
  });

  app.delete('/api/routes/:id', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || !['admin', 'super_admin', 'dispatcher'].includes(user.role)) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      await storage.deleteRoute(id);
      res.json({ success: true, message: "Route deleted successfully" });
    } catch (error) {
      console.error("Error deleting route:", error);
      res.status(500).json({ message: "Failed to delete route" });
    }
  });

  // Geocoding service (simple implementation using a geocoding API)
  app.post('/api/geocode', isAuthenticated, async (req: any, res) => {
    try {
      const { address } = req.body;
      
      if (!address) {
        return res.status(400).json({ message: "Address is required" });
      }
      
      // For demo purposes, return mock coordinates for Central Florida addresses
      // In a real implementation, you would use Google Maps API, OpenStreetMap, or similar
      const mockCoordinates = {
        latitude: 28.5383 + (Math.random() - 0.5) * 0.1, // Orlando area with some variation
        longitude: -81.3792 + (Math.random() - 0.5) * 0.1,
      };
      
      res.json(mockCoordinates);
    } catch (error) {
      console.error("Error geocoding address:", error);
      res.status(500).json({ message: "Failed to geocode address" });
    }
  });

  // System Update (admin and super admin only)
  app.post('/api/admin/system-update', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || (user.role !== 'admin' && user.role !== 'super_admin')) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { updateType } = req.body;
      
      // Simulate system update process
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate processing time
      
      let updateMessage = "";
      
      switch (updateType) {
        case "database":
          updateMessage = "Database schema updated and migrations applied successfully";
          break;
        case "config":
          updateMessage = "System configuration refreshed and environment settings reloaded";
          break;
        case "files":
          updateMessage = "Application files and assets updated successfully";
          break;
        case "full":
          updateMessage = "Complete system update performed: database, configuration, and files updated";
          break;
        default:
          throw new Error("Invalid update type");
      }

      console.log(`System update performed: ${updateType} by admin ${user.username}`);
      
      res.json({ 
        success: true, 
        message: updateMessage,
        updateType,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error performing system update:", error);
      res.status(500).json({ message: "Failed to perform system update" });
    }
  });

  // Geocoding endpoint
  app.post('/api/geocode', isAuthenticated, async (req, res) => {
    try {
      const { address } = req.body;
      if (!address) {
        return res.status(400).json({ message: "Address is required" });
      }
      
      const coordinates = geocodeAddress(address);
      res.json({
        latitude: parseFloat(coordinates.latitude),
        longitude: parseFloat(coordinates.longitude),
        address: address
      });
    } catch (error) {
      console.error("Error geocoding address:", error);
      res.status(500).json({ message: "Failed to geocode address" });
    }
  });

  // Sample data loading endpoint
  app.post('/api/admin/load-sample-data', isAuthenticated, async (req: any, res) => {
    try {
      const user = req.user;
      
      if (!user || user.role !== 'super_admin') {
        return res.status(403).json({ message: "Unauthorized - Super Admin only" });
      }

      // Sample Central Florida addresses for jobs
      const sampleAddresses = [
        "1234 Main St, Orlando, FL 32801",
        "5678 Orange Ave, Winter Park, FL 32789",
        "9101 University Blvd, Orlando, FL 32817",
        "2468 Colonial Dr, Orlando, FL 32803",
        "1357 Alafaya Trail, Orlando, FL 32828",
        "7890 Sand Lake Rd, Orlando, FL 32819",
        "4567 East-West Expressway, Orlando, FL 32811",
        "3210 Semoran Blvd, Orlando, FL 32822",
        "6543 International Dr, Orlando, FL 32819",
        "8765 John Young Pkwy, Orlando, FL 32837",
        "1111 Park Ave, Winter Park, FL 32789",
        "2222 Fairbanks Ave, Winter Park, FL 32789",
        "3333 Mills Ave, Orlando, FL 32803",
        "4444 Orange Blossom Trail, Orlando, FL 32805",
        "5555 Kirkman Rd, Orlando, FL 32811"
      ];

      // Get existing customers for job assignments
      const customers = await storage.getUsersByRole('customer');
      const drivers = await storage.getUsersByRole('driver');

      if (customers.length === 0) {
        return res.status(400).json({ message: "No customers found. Create customers first." });
      }

      const createdJobs = [];
      const today = new Date();
      
      // Create 15 sample jobs
      for (let i = 0; i < 15; i++) {
        const randomCustomer = customers[Math.floor(Math.random() * customers.length)];
        const address = sampleAddresses[i];
        
        // Schedule jobs randomly in the next 7 days
        const scheduledDate = new Date(today);
        scheduledDate.setDate(today.getDate() + Math.floor(Math.random() * 7));
        scheduledDate.setHours(8 + Math.floor(Math.random() * 8), 0, 0, 0); // 8 AM to 4 PM
        
        const coordinates = geocodeAddress(address);
        
        const statuses = ['pending', 'assigned', 'in_progress', 'completed'];
        const priorities = ['low', 'normal', 'high'];
        const serviceTypes = ['residential', 'commercial', 'one_time'];
        
        const job = await storage.createJob({
          customerId: randomCustomer.id,
          serviceType: serviceTypes[Math.floor(Math.random() * serviceTypes.length)] as any,
          address,
          notes: `Sample job ${i + 1} - Regular bin cleaning service`,
          priority: priorities[Math.floor(Math.random() * priorities.length)] as any,
          status: statuses[Math.floor(Math.random() * statuses.length)] as any,
          scheduledDate,
          latitude: coordinates.latitude,
          longitude: coordinates.longitude,
          assignedBy: user.id,
          driverId: Math.random() > 0.3 && drivers.length > 0 ? drivers[Math.floor(Math.random() * drivers.length)].id : null
        });
        
        createdJobs.push(job);
      }

      // Create sample routes
      const createdRoutes = [];
      if (drivers.length > 0) {
        for (let i = 0; i < 3; i++) {
          const driver = drivers[i % drivers.length];
          const routeDate = new Date(today);
          routeDate.setDate(today.getDate() + i);
          
          const route = await storage.createRoute({
            driverId: driver.id,
            routeName: `Route ${i + 1} - ${routeDate.toLocaleDateString()}`,
            scheduledDate: routeDate,
            status: 'pending',
            startLocation: "Central Florida Bin Cleaning HQ, Orlando, FL",
            endLocation: "Central Florida Bin Cleaning HQ, Orlando, FL",
            startLatitude: "28.5383",
            startLongitude: "-81.3792",
            endLatitude: "28.5383",
            endLongitude: "-81.3792",
            createdBy: user.id
          });
          
          // Assign some jobs to this route
          const routeJobs = createdJobs.filter(job => job.driverId === driver.id).slice(0, 5);
          if (routeJobs.length > 0) {
            await storage.assignJobsToRoute(route.id, routeJobs.map(job => job.id));
          }
          
          createdRoutes.push(route);
        }
      }

      res.json({
        success: true,
        message: "Sample data loaded successfully",
        data: {
          jobsCreated: createdJobs.length,
          routesCreated: createdRoutes.length,
          jobs: createdJobs,
          routes: createdRoutes
        }
      });

    } catch (error) {
      console.error("Error loading sample data:", error);
      res.status(500).json({ message: "Failed to load sample data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
